(function() {
	//#region node_modules/wxt/dist/utils/define-content-script.mjs
	function defineContentScript(definition) {
		return definition;
	}
	//#endregion
	//#region node_modules/wxt/dist/browser.mjs
	/**
	* Contains the `browser` export which you should use to access the extension
	* APIs in your project:
	*
	* ```ts
	* import { browser } from 'wxt/browser';
	*
	* browser.runtime.onInstalled.addListener(() => {
	*   // ...
	* });
	* ```
	*
	* @module wxt/browser
	*/
	var browser = globalThis.browser?.runtime?.id ? globalThis.browser : globalThis.chrome;
	//#endregion
	//#region entrypoints/content.ts
	var content_default = defineContentScript({
		matches: ["<all_urls>"],
		runAt: "document_start",
		main() {
			if (window.top !== window.self) return;
			function formatSeconds(totalSec) {
				const s = Math.max(0, totalSec);
				const seconds = s % 60;
				const minutes = Math.floor(s / 60) % 60;
				const hours = Math.floor(s / 3600);
				return `${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
			}
			const hostname = window.location.hostname.replace(/^www\./, "");
			const distBar = document.createElement("div");
			const warning = document.createElement("h1");
			const timer = document.createElement("p");
			const totalTimer = document.createElement("p");
			distBar.appendChild(warning);
			distBar.appendChild(timer);
			distBar.appendChild(totalTimer);
			distBar.style.position = "fixed";
			distBar.style.top = "0";
			distBar.style.left = "0";
			distBar.style.width = "100%";
			distBar.style.height = "50px";
			distBar.style.backgroundColor = "#be123c";
			distBar.style.color = "white";
			distBar.style.display = "none";
			distBar.style.alignItems = "center";
			distBar.style.justifyContent = "space-between";
			distBar.style.gap = "16px";
			distBar.style.padding = "0 24px";
			distBar.style.boxSizing = "border-box";
			distBar.style.zIndex = "2147483647";
			distBar.style.fontFamily = "system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif";
			warning.textContent = "You've been distracted";
			warning.style.fontSize = "16px";
			warning.style.fontWeight = "600";
			warning.style.margin = "0";
			warning.style.padding = "0";
			warning.style.whiteSpace = "nowrap";
			warning.style.flex = "1";
			warning.style.textAlign = "left";
			timer.textContent = "00:00:00";
			timer.style.fontSize = "18px";
			timer.style.fontWeight = "bold";
			timer.style.margin = "0";
			timer.style.padding = "0";
			timer.style.textAlign = "center";
			timer.style.whiteSpace = "nowrap";
			timer.style.letterSpacing = "0.5px";
			timer.style.fontVariantNumeric = "tabular-nums";
			timer.style.minWidth = "110px";
			timer.style.flex = "1";
			totalTimer.textContent = "(This session: 00:00:00)";
			totalTimer.style.fontSize = "13px";
			totalTimer.style.margin = "0";
			totalTimer.style.padding = "0";
			totalTimer.style.whiteSpace = "nowrap";
			totalTimer.style.opacity = "0.9";
			totalTimer.style.fontVariantNumeric = "tabular-nums";
			totalTimer.style.minWidth = "170px";
			totalTimer.style.flex = "1";
			totalTimer.style.textAlign = "right";
			const widgetContainer = document.createElement("div");
			widgetContainer.style.position = "fixed";
			widgetContainer.style.bottom = "20px";
			widgetContainer.style.right = "20px";
			widgetContainer.style.zIndex = "2147483647";
			widgetContainer.style.fontFamily = "system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif";
			widgetContainer.style.userSelect = "none";
			const flyoutCard = document.createElement("div");
			flyoutCard.style.position = "absolute";
			flyoutCard.style.bottom = "58px";
			flyoutCard.style.right = "0";
			flyoutCard.style.width = "220px";
			flyoutCard.style.background = "rgba(18, 18, 24, 0.94)";
			flyoutCard.style.backdropFilter = "blur(20px)";
			flyoutCard.style.webkitBackdropFilter = "blur(20px)";
			flyoutCard.style.color = "white";
			flyoutCard.style.borderRadius = "18px";
			flyoutCard.style.padding = "16px";
			flyoutCard.style.border = "1px solid rgba(255, 255, 255, 0.12)";
			flyoutCard.style.boxShadow = "0 20px 40px -8px rgba(0, 0, 0, 0.7), 0 0 1px 1px rgba(255, 255, 255, 0.08)";
			flyoutCard.style.boxSizing = "border-box";
			flyoutCard.style.opacity = "0";
			flyoutCard.style.transform = "translateY(10px) scale(0.96)";
			flyoutCard.style.pointerEvents = "none";
			flyoutCard.style.transition = "opacity 0.22s cubic-bezier(0.16, 1, 0.3, 1), transform 0.22s cubic-bezier(0.16, 1, 0.3, 1)";
			const cardHeader = document.createElement("div");
			cardHeader.style.display = "flex";
			cardHeader.style.alignItems = "center";
			cardHeader.style.justifyContent = "space-between";
			cardHeader.style.marginBottom = "10px";
			const brandTitle = document.createElement("span");
			brandTitle.textContent = "NUDGE FOCUS";
			brandTitle.style.fontSize = "11px";
			brandTitle.style.fontWeight = "800";
			brandTitle.style.letterSpacing = "0.06em";
			brandTitle.style.color = "#a1a1aa";
			const p2 = document.createElement("span");
			p2.textContent = "Idle";
			p2.style.fontSize = "10px";
			p2.style.fontWeight = "600";
			p2.style.padding = "2px 8px";
			p2.style.borderRadius = "999px";
			p2.style.background = "rgba(255, 255, 255, 0.08)";
			p2.style.color = "#a1a1aa";
			p2.style.border = "1px solid rgba(255, 255, 255, 0.08)";
			p2.style.textTransform = "capitalize";
			cardHeader.appendChild(brandTitle);
			cardHeader.appendChild(p2);
			const timerLabel = document.createElement("div");
			timerLabel.textContent = "SESSION TIME";
			timerLabel.style.fontSize = "9px";
			timerLabel.style.fontWeight = "700";
			timerLabel.style.letterSpacing = "0.08em";
			timerLabel.style.color = "#71717a";
			timerLabel.style.marginBottom = "2px";
			const p1 = document.createElement("div");
			p1.textContent = "00:00:00";
			p1.style.fontSize = "24px";
			p1.style.fontFamily = "system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif";
			p1.style.fontVariantNumeric = "tabular-nums";
			p1.style.color = "#ffffff";
			p1.style.letterSpacing = "-0.02em";
			p1.style.marginBottom = "12px";
			const divider = document.createElement("div");
			divider.style.height = "1px";
			divider.style.background = "rgba(255, 255, 255, 0.08)";
			divider.style.margin = "8px 0 12px 0";
			const dashBtn = document.createElement("button");
			dashBtn.innerHTML = `
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="margin-right: 6px;">
        <rect x="3" y="3" width="18" height="18" rx="2"></rect>
        <path d="M7 16h2"></path>
        <path d="M11 12h2"></path>
        <path d="M15 8h2"></path>
      </svg>
      <span>View Dashboard</span>
    `;
			dashBtn.style.width = "100%";
			dashBtn.style.padding = "9px 12px";
			dashBtn.style.display = "flex";
			dashBtn.style.alignItems = "center";
			dashBtn.style.justifyContent = "center";
			dashBtn.style.background = "linear-gradient(135deg, #4f46e5 0%, #6366f1 100%)";
			dashBtn.style.color = "#ffffff";
			dashBtn.style.fontSize = "12px";
			dashBtn.style.fontWeight = "600";
			dashBtn.style.borderRadius = "10px";
			dashBtn.style.border = "none";
			dashBtn.style.cursor = "pointer";
			dashBtn.style.boxShadow = "0 4px 14px rgba(79, 70, 229, 0.4)";
			dashBtn.style.transition = "all 0.2s cubic-bezier(0.16, 1, 0.3, 1)";
			dashBtn.style.outline = "none";
			dashBtn.addEventListener("mouseenter", () => {
				dashBtn.style.transform = "translateY(-1px)";
				dashBtn.style.filter = "brightness(1.1)";
				dashBtn.style.boxShadow = "0 6px 20px rgba(79, 70, 229, 0.55)";
			});
			dashBtn.addEventListener("mouseleave", () => {
				dashBtn.style.transform = "translateY(0)";
				dashBtn.style.filter = "brightness(1)";
				dashBtn.style.boxShadow = "0 4px 14px rgba(79, 70, 229, 0.4)";
			});
			dashBtn.addEventListener("click", async (e) => {
				e.stopPropagation();
				try {
					await browser.runtime.sendMessage({ message: "open_dashboard" });
				} catch (err) {
					console.error("Could not open dashboard:", err);
				}
			});
			flyoutCard.appendChild(cardHeader);
			flyoutCard.appendChild(timerLabel);
			flyoutCard.appendChild(p1);
			flyoutCard.appendChild(divider);
			flyoutCard.appendChild(dashBtn);
			const iconBtn = document.createElement("div");
			iconBtn.style.position = "relative";
			iconBtn.style.width = "48px";
			iconBtn.style.height = "48px";
			iconBtn.style.borderRadius = "50%";
			iconBtn.style.background = "linear-gradient(135deg, #18181b 0%, #09090b 100%)";
			iconBtn.style.border = "1px solid rgba(255, 255, 255, 0.16)";
			iconBtn.style.boxShadow = "0 6px 18px -4px rgba(0, 0, 0, 0.7)";
			iconBtn.style.display = "flex";
			iconBtn.style.alignItems = "center";
			iconBtn.style.justifyContent = "center";
			iconBtn.style.cursor = "pointer";
			iconBtn.style.transition = "all 0.25s cubic-bezier(0.16, 1, 0.3, 1)";
			const iconText = document.createElement("span");
			iconText.textContent = "N";
			iconText.style.fontSize = "18px";
			iconText.style.fontWeight = "700";
			iconText.style.color = "#f4f4f5";
			const statusDot = document.createElement("div");
			statusDot.style.position = "absolute";
			statusDot.style.top = "1px";
			statusDot.style.right = "1px";
			statusDot.style.width = "10px";
			statusDot.style.height = "10px";
			statusDot.style.borderRadius = "50%";
			statusDot.style.background = "#71717a";
			statusDot.style.border = "2px solid #09090b";
			statusDot.style.boxShadow = "0 0 6px rgba(0, 0, 0, 0.5)";
			statusDot.style.transition = "all 0.3s ease";
			iconBtn.appendChild(iconText);
			iconBtn.appendChild(statusDot);
			widgetContainer.appendChild(flyoutCard);
			widgetContainer.appendChild(iconBtn);
			let isMenuOpen = false;
			let hideTimeout = null;
			const openMenu = () => {
				if (hideTimeout) clearTimeout(hideTimeout);
				isMenuOpen = true;
				flyoutCard.style.opacity = "1";
				flyoutCard.style.transform = "translateY(0) scale(1)";
				flyoutCard.style.pointerEvents = "auto";
				iconBtn.style.transform = "scale(1.05)";
				iconBtn.style.boxShadow = "0 10px 24px -4px rgba(0, 0, 0, 0.8)";
			};
			const closeMenu = () => {
				isMenuOpen = false;
				flyoutCard.style.opacity = "0";
				flyoutCard.style.transform = "translateY(10px) scale(0.96)";
				flyoutCard.style.pointerEvents = "none";
				iconBtn.style.transform = "scale(1)";
				iconBtn.style.boxShadow = "0 6px 18px -4px rgba(0, 0, 0, 0.7)";
			};
			widgetContainer.addEventListener("mouseenter", () => {
				openMenu();
			});
			widgetContainer.addEventListener("mouseleave", () => {
				hideTimeout = setTimeout(() => {
					closeMenu();
				}, 150);
			});
			iconBtn.addEventListener("click", (e) => {
				e.stopPropagation();
				if (isMenuOpen) closeMenu();
				else openMenu();
			});
			const pageLoadTime = Date.now();
			const isPageReload = (typeof performance !== "undefined" && typeof performance.getEntriesByType === "function" ? performance.getEntriesByType("navigation") : [])[0]?.type === "reload";
			const visitStorageKey = `nudge_tab_visit_start_${hostname}`;
			const instanceStorageKey = `nudge_tab_instance_${hostname}`;
			const domainSpanStorageKey = `nudge_tab_domain_span_start_${hostname}`;
			const baseUsageStorageKey = `nudge_tab_base_usage_${hostname}`;
			const lastTickStorageKey = `nudge_tab_last_tick_${hostname}`;
			const tabIdStorageKey = `nudge_tab_id_${hostname}`;
			const tabActiveStorageKey = `nudge_tab_active_ms_${hostname}`;
			const persistTabActiveMs = (ms) => {
				try {
					if (ms >= 0) sessionStorage.setItem(tabActiveStorageKey, String(ms));
					else sessionStorage.removeItem(tabActiveStorageKey);
				} catch {}
			};
			const updateLastTick = () => {
				try {
					sessionStorage.setItem(lastTickStorageKey, String(Date.now()));
				} catch {}
			};
			const getStoredVisitStart = () => {
				try {
					const val = sessionStorage.getItem(visitStorageKey);
					if (val) {
						const num = parseInt(val, 10);
						if (!isNaN(num) && num > 0) return num;
					}
				} catch {}
				return 0;
			};
			const persistVisitStart = (start) => {
				try {
					if (start > 0) sessionStorage.setItem(visitStorageKey, String(start));
					else sessionStorage.removeItem(visitStorageKey);
				} catch {}
			};
			const getStoredDomainSpanStart = () => {
				try {
					const val = sessionStorage.getItem(domainSpanStorageKey);
					if (val) {
						const num = parseInt(val, 10);
						if (!isNaN(num) && num > 0) return num;
					}
				} catch {}
				return 0;
			};
			const persistDomainSpanStart = (start) => {
				try {
					if (start > 0) sessionStorage.setItem(domainSpanStorageKey, String(start));
					else sessionStorage.removeItem(domainSpanStorageKey);
				} catch {}
			};
			const getStoredBaseUsage = () => {
				try {
					const val = sessionStorage.getItem(baseUsageStorageKey);
					if (val) {
						const num = parseInt(val, 10);
						if (!isNaN(num) && num >= 0) return num;
					}
				} catch {}
				return 0;
			};
			const persistBaseUsage = (usage) => {
				try {
					if (usage >= 0) sessionStorage.setItem(baseUsageStorageKey, String(usage));
					else sessionStorage.removeItem(baseUsageStorageKey);
				} catch {}
			};
			const generateUniqueInstanceId = () => {
				return "tab_" + Date.now() + "_" + Math.random().toString(36).slice(2, 9);
			};
			const getStoredTabInstanceId = () => {
				try {
					const val = sessionStorage.getItem(instanceStorageKey);
					if (val) return val;
				} catch {}
				return "";
			};
			let tabInstanceId = "";
			let visitStartedAt = 0;
			let domainSpanStartedAt = 0;
			let baseSiteUsageMs = 0;
			let usageSnapshotAt = 0;
			const storedVisit = getStoredVisitStart();
			const storedInstance = getStoredTabInstanceId();
			const isContinuingVisit = isPageReload && storedVisit > 0;
			if (isContinuingVisit) {
				tabInstanceId = storedInstance || generateUniqueInstanceId();
				visitStartedAt = storedVisit > 0 ? storedVisit : pageLoadTime;
				domainSpanStartedAt = getStoredDomainSpanStart();
				baseSiteUsageMs = getStoredBaseUsage();
				usageSnapshotAt = 0;
			} else {
				tabInstanceId = generateUniqueInstanceId();
				visitStartedAt = pageLoadTime;
				domainSpanStartedAt = 0;
				baseSiteUsageMs = 0;
				usageSnapshotAt = 0;
				persistVisitStart(visitStartedAt);
				persistDomainSpanStart(0);
				persistBaseUsage(0);
				persistTabActiveMs(0);
			}
			try {
				sessionStorage.setItem(instanceStorageKey, tabInstanceId);
			} catch {}
			let sessionStartedAt = 0;
			let isRestrictedPage = false;
			let pageBlocked = false;
			let isSyncing = false;
			let latestSyncSeq = 0;
			const blockStorageKey = `nudge_tab_blocked_${hostname}`;
			const getSavedBlockedState = () => {
				try {
					return sessionStorage.getItem(blockStorageKey) === "true";
				} catch {
					return false;
				}
			};
			const persistBlockedState = (isBlocked) => {
				try {
					if (isBlocked) sessionStorage.setItem(blockStorageKey, "true");
					else sessionStorage.removeItem(blockStorageKey);
				} catch {}
			};
			let lastVisitSec = -1;
			let lastTotalSec = -1;
			let lastSessionSec = -1;
			function isHostBlocked(host, sites) {
				if (!host) return false;
				const cleanHost = host.trim().toLowerCase().replace(/^www\./, "");
				const cleanSites = sites.map((s) => s.trim().toLowerCase().replace(/^https?:\/\//, "").replace(/^www\./, "").replace(/[/?#].*$/, "")).filter(Boolean);
				if (cleanSites.includes("twitter.com") && !cleanSites.includes("x.com")) cleanSites.push("x.com");
				if (cleanSites.includes("x.com") && !cleanSites.includes("twitter.com")) cleanSites.push("twitter.com");
				for (const site of cleanSites) if (cleanHost === site || cleanHost.endsWith(`.${site}`)) return true;
				return false;
			}
			function getMatchingSite(host, sites) {
				if (!host) return null;
				const cleanHost = host.trim().toLowerCase().replace(/^www\./, "");
				const cleanSites = sites.map((s) => s.trim().toLowerCase().replace(/^https?:\/\//, "").replace(/^www\./, "").replace(/[/?#].*$/, "")).filter(Boolean);
				if (cleanSites.includes("twitter.com") && !cleanSites.includes("x.com")) cleanSites.push("x.com");
				if (cleanSites.includes("x.com") && !cleanSites.includes("twitter.com")) cleanSites.push("twitter.com");
				for (const site of cleanSites) if (cleanHost === site || cleanHost.endsWith(`.${site}`)) return site;
				return null;
			}
			const ensureDomInjected = () => {
				if (pageBlocked) return;
				const target = document.body;
				if (!target) {
					if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", () => {
						ensureDomInjected();
					}, { once: true });
					return;
				}
				if (!target.contains(distBar)) target.appendChild(distBar);
				if (!target.contains(widgetContainer)) target.appendChild(widgetContainer);
			};
			let blockObserver = null;
			const removeBlockedPage = () => {
				persistBlockedState(false);
				if (blockObserver) {
					blockObserver.disconnect();
					blockObserver = null;
				}
			};
			const renderBlockedPage = (blockedHost) => {
				pageBlocked = true;
				isRestrictedPage = false;
				persistBlockedState(true);
				try {
					window.stop();
				} catch {}
				try {
					document.querySelectorAll("video, audio").forEach((media) => {
						try {
							const m = media;
							m.pause();
							m.muted = true;
							m.removeAttribute("src");
							m.load();
						} catch {}
					});
				} catch {}
				distBar.style.display = "none";
				widgetContainer.style.display = "none";
				document.title = `Blocked • Nudge Focus (${blockedHost})`;
				const blockedHtml = `
        <div id="nudge-blocked-container" style="
          position: fixed !important;
          inset: 0 !important;
          top: 0 !important;
          left: 0 !important;
          width: 100vw !important;
          height: 100vh !important;
          background: #09090b !important;
          display: flex !important;
          align-items: center !important;
          justify-content: center !important;
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif !important;
          color: #f4f4f5 !important;
          box-sizing: border-box !important;
          padding: 24px !important;
          user-select: none !important;
          z-index: 2147483647 !important;
        ">
          <div style="
            max-width: 380px;
            width: 100%;
            text-align: center;
            box-sizing: border-box;
          ">
            <!-- Subtle status mark -->
            <div style="
              display: inline-flex;
              align-items: center;
              gap: 6px;
              font-size: 11px;
              font-weight: 600;
              letter-spacing: 0.06em;
              text-transform: uppercase;
              color: #71717a;
              margin-bottom: 20px;
            ">
              <span style="
                width: 6px;
                height: 6px;
                border-radius: 50%;
                background: #a1a1aa;
                display: inline-block;
              "></span>
              Nudge Focus
            </div>

            <!-- Clean Direct Title -->
            <h1 style="
              font-size: 22px;
              font-weight: 600;
              color: #fafafa;
              letter-spacing: -0.02em;
              margin: 0 0 8px 0;
              line-height: 1.3;
            ">${blockedHost} is blocked</h1>

            <!-- Understated Subtitle -->
            <p style="
              font-size: 13px;
              color: #71717a;
              line-height: 1.5;
              margin: 0 0 24px 0;
            ">
              This site is blocked during your active focus sprint.
            </p>

            <!-- Quiet Session Duration -->
            <div style="
              display: flex;
              align-items: center;
              justify-content: space-between;
              padding: 12px 16px;
              background: rgba(255, 255, 255, 0.03);
              border: 1px solid rgba(255, 255, 255, 0.08);
              border-radius: 12px;
              margin-bottom: 24px;
            ">
              <span style="font-size: 12px; color: #71717a;">Focus elapsed</span>
              <span id="nudge-blocked-timer" style="
                font-size: 14px;
                font-weight: 600;
                color: #e4e4e7;
                font-variant-numeric: tabular-nums;
                font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
              ">${sessionStartedAt > 0 ? formatSeconds(Math.max(0, Math.floor((Date.now() - sessionStartedAt) / 1e3))) : "00:00:00"}</span>
            </div>

            <!-- Clean Action Buttons -->
            <div style="
              display: flex;
              gap: 10px;
              justify-content: center;
            ">
              <button id="nudge-block-back-btn" style="
                flex: 1;
                background: #27272a;
                color: #f4f4f5;
                border: 1px solid rgba(255, 255, 255, 0.1);
                border-radius: 10px;
                padding: 9px 16px;
                font-size: 13px;
                font-weight: 500;
                cursor: pointer;
                transition: background 0.15s ease, border-color 0.15s ease;
                outline: none;
              ">Go back</button>

              <button id="nudge-block-dash-btn" style="
                background: transparent;
                color: #a1a1aa;
                border: 1px solid rgba(255, 255, 255, 0.08);
                border-radius: 10px;
                padding: 9px 16px;
                font-size: 13px;
                font-weight: 500;
                cursor: pointer;
                transition: background 0.15s ease, color 0.15s ease;
                outline: none;
              ">Dashboard</button>
            </div>

            <!-- Quiet Hint -->
            <div style="
              margin-top: 24px;
              font-size: 11px;
              color: #52525b;
              letter-spacing: 0.02em;
            ">Alt + ← to return</div>
          </div>
        </div>
      `;
				if (document.documentElement) document.documentElement.innerHTML = `
          <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Blocked • Nudge Focus (${blockedHost})</title>
            <style>
              html, body {
                margin: 0 !important;
                padding: 0 !important;
                background: #09090b !important;
                overflow: hidden !important;
                width: 100vw !important;
                height: 100vh !important;
              }
            </style>
          </head>
          <body>${blockedHtml}</body>
        `;
				else if (document.body) {
					document.body.innerHTML = blockedHtml;
					document.body.style.cssText = "margin:0!important;padding:0!important;background:#09090b!important;overflow:hidden!important;";
				}
				const backBtn = document.getElementById("nudge-block-back-btn");
				if (backBtn) {
					backBtn.onmouseenter = () => {
						backBtn.style.background = "#3f3f46";
						backBtn.style.borderColor = "rgba(255, 255, 255, 0.18)";
					};
					backBtn.onmouseleave = () => {
						backBtn.style.background = "#27272a";
						backBtn.style.borderColor = "rgba(255, 255, 255, 0.1)";
					};
					backBtn.onclick = async () => {
						if (window.history.length > 1) window.history.back();
						else try {
							await browser.runtime.sendMessage({ message: "close_current_tab" });
						} catch {
							window.close();
						}
					};
				}
				const dashBtn = document.getElementById("nudge-block-dash-btn");
				if (dashBtn) {
					dashBtn.onmouseenter = () => {
						dashBtn.style.background = "rgba(255, 255, 255, 0.05)";
						dashBtn.style.color = "#f4f4f5";
					};
					dashBtn.onmouseleave = () => {
						dashBtn.style.background = "transparent";
						dashBtn.style.color = "#a1a1aa";
					};
					dashBtn.onclick = async () => {
						try {
							await browser.runtime.sendMessage({ message: "open_dashboard" });
						} catch (e) {
							console.error("Dashboard error:", e);
						}
					};
				}
				if (!blockObserver && document.documentElement) {
					blockObserver = new MutationObserver(() => {
						if (!pageBlocked) return;
						if (!document.getElementById("nudge-blocked-container")) renderBlockedPage(blockedHost);
					});
					blockObserver.observe(document.documentElement, {
						childList: true,
						subtree: true
					});
				}
				if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", () => {
					if (pageBlocked && !document.getElementById("nudge-blocked-container")) renderBlockedPage(blockedHost);
				}, { once: true });
			};
			if (getSavedBlockedState()) {
				pageBlocked = true;
				renderBlockedPage(hostname);
			}
			const checkImmediateBlock = async () => {
				try {
					const data = await browser.storage.local.get([
						"isActive",
						"mode",
						"blockedSites",
						"startedAt"
					]);
					if (data.isActive && data.mode === "block") {
						const sites = Array.isArray(data.blockedSites) ? data.blockedSites : [];
						if (isHostBlocked(hostname, sites)) {
							if (typeof data.startedAt === "number" && data.startedAt > 0) sessionStartedAt = data.startedAt;
							pageBlocked = true;
							isRestrictedPage = false;
							persistBlockedState(true);
							renderBlockedPage(hostname);
							return true;
						} else if (pageBlocked) {
							pageBlocked = false;
							removeBlockedPage();
							window.location.reload();
							return false;
						}
					} else if (pageBlocked) {
						pageBlocked = false;
						removeBlockedPage();
						window.location.reload();
						return false;
					}
				} catch (err) {
					console.warn("Immediate block check:", err);
				}
				return false;
			};
			const checkImmediateRestricted = async () => {
				try {
					const data = await browser.storage.local.get([
						"isActive",
						"mode",
						"restrictedSites",
						"startedAt",
						"sessionSiteUsage",
						"domainSpans",
						"activeVisits"
					]);
					if (data.isActive && (data.mode === "restrict" || data.mode === "block")) {
						const sites = Array.isArray(data.restrictedSites) ? data.restrictedSites : [];
						if (isHostBlocked(hostname, sites)) {
							const sStart = typeof data.startedAt === "number" && data.startedAt > 0 ? data.startedAt : 0;
							sessionStartedAt = sStart;
							isRestrictedPage = true;
							const matched = getMatchingSite(hostname, sites) || hostname;
							const usage = data.sessionSiteUsage ?? {};
							if (typeof usage[matched] === "number") {
								baseSiteUsageMs = usage[matched];
								persistBaseUsage(baseSiteUsageMs);
							}
							const activeDomainSpan = data.domainSpans?.[matched];
							if (activeDomainSpan?.startedAt && (sStart === 0 || activeDomainSpan.startedAt >= sStart)) domainSpanStartedAt = activeDomainSpan.startedAt;
							else domainSpanStartedAt = 0;
							persistDomainSpanStart(domainSpanStartedAt);
							const checkNow = Date.now();
							const liveSpanStart = domainSpanStartedAt > 0 ? domainSpanStartedAt : visitStartedAt;
							const effectiveSpanStart = liveSpanStart > 0 && sStart > 0 ? Math.max(liveSpanStart, sStart) : liveSpanStart;
							const liveAnchor = domainSpanStartedAt === 0 && baseSiteUsageMs > 0 ? Math.max(effectiveSpanStart, pageLoadTime) : effectiveSpanStart;
							const liveMs = liveAnchor > 0 ? Math.max(0, checkNow - liveAnchor) : 0;
							const totalDurationMs = baseSiteUsageMs + liveMs;
							Math.floor(totalDurationMs / 1e3);
							usageSnapshotAt = checkNow - totalDurationMs % 1e3;
							if (isContinuingVisit) {
								const storedStart = getStoredVisitStart();
								if (storedStart > 0 && (sStart === 0 || storedStart >= sStart)) visitStartedAt = storedStart;
							} else if (!visitStartedAt || visitStartedAt === 0) {
								visitStartedAt = pageLoadTime;
								persistVisitStart(visitStartedAt);
							}
							if (data.mode === "block") {
								warning.textContent = "Focus Sprint Active (Block Mode)";
								distBar.style.backgroundColor = "#e11d48";
							} else {
								warning.textContent = "You've been distracted";
								distBar.style.backgroundColor = "#be123c";
							}
							ensureDomInjected();
							distBar.style.display = "flex";
							updateDisplayTimers();
						} else {
							isRestrictedPage = false;
							distBar.style.display = "none";
						}
					} else {
						isRestrictedPage = false;
						distBar.style.display = "none";
					}
				} catch (err) {
					console.warn("Immediate restricted check:", err);
				}
			};
			const updateDisplayTimers = () => {
				const now = Date.now();
				if (sessionStartedAt > 0) {
					const sessionElapsedSec = Math.max(0, Math.floor((now - sessionStartedAt) / 1e3));
					if (sessionElapsedSec !== lastSessionSec) {
						lastSessionSec = sessionElapsedSec;
						p1.textContent = formatSeconds(sessionElapsedSec);
						if (pageBlocked) {
							const blockTimerEl = document.getElementById("nudge-blocked-timer");
							if (blockTimerEl) blockTimerEl.textContent = formatSeconds(sessionElapsedSec);
							else renderBlockedPage(hostname);
						}
					}
				}
				if (isRestrictedPage && visitStartedAt > 0) {
					const liveSpanStart = domainSpanStartedAt > 0 ? domainSpanStartedAt : visitStartedAt;
					const effectiveSpanStart = sessionStartedAt > 0 ? Math.max(liveSpanStart, sessionStartedAt) : liveSpanStart;
					const liveAnchor = domainSpanStartedAt === 0 && baseSiteUsageMs > 0 ? Math.max(effectiveSpanStart, pageLoadTime) : effectiveSpanStart;
					const liveMs = liveAnchor > 0 ? Math.max(0, now - liveAnchor) : 0;
					let totalDurationMs = baseSiteUsageMs + liveMs;
					if (sessionStartedAt > 0) {
						const maxSessionMs = Math.max(0, now - sessionStartedAt);
						if (totalDurationMs > maxSessionMs) totalDurationMs = maxSessionMs;
					}
					let totalSiteSec = Math.floor(totalDurationMs / 1e3);
					if (lastTotalSec >= 0 && totalSiteSec < lastTotalSec) totalSiteSec = lastTotalSec;
					let currentVisitSec = Math.max(0, Math.floor((now - (sessionStartedAt > 0 ? Math.max(visitStartedAt, sessionStartedAt) : visitStartedAt)) / 1e3));
					if (lastVisitSec >= 0 && currentVisitSec < lastVisitSec) currentVisitSec = lastVisitSec;
					if (currentVisitSec !== lastVisitSec) {
						lastVisitSec = currentVisitSec;
						timer.textContent = formatSeconds(currentVisitSec);
					}
					if (totalSiteSec !== lastTotalSec) {
						lastTotalSec = totalSiteSec;
						totalTimer.textContent = `(This session: ${formatSeconds(totalSiteSec)})`;
					}
					updateLastTick();
				}
			};
			const syncSite = async () => {
				if (isSyncing) return;
				isSyncing = true;
				const syncSeq = ++latestSyncSeq;
				try {
					const isVisible = document.visibilityState === "visible";
					const response = await browser.runtime.sendMessage({
						message: "check_site",
						hostname,
						tabInstanceId,
						tabVisitStartedAt: visitStartedAt,
						isVisible
					});
					if (!response || syncSeq !== latestSyncSeq) return;
					if (!response.isActive) {
						persistBlockedState(false);
						if (pageBlocked) {
							pageBlocked = false;
							removeBlockedPage();
							window.location.reload();
							return;
						}
						persistVisitStart(0);
						persistDomainSpanStart(0);
						persistBaseUsage(0);
						persistTabActiveMs(0);
						isRestrictedPage = false;
						visitStartedAt = 0;
						domainSpanStartedAt = 0;
						baseSiteUsageMs = 0;
						usageSnapshotAt = 0;
						sessionStartedAt = 0;
						lastVisitSec = -1;
						lastTotalSec = -1;
						lastSessionSec = -1;
						distBar.style.display = "none";
						p1.textContent = "00:00:00";
						p2.textContent = "Idle";
						p2.style.background = "rgba(255, 255, 255, 0.08)";
						p2.style.color = "#a1a1aa";
						p2.style.border = "1px solid rgba(255, 255, 255, 0.08)";
						statusDot.style.background = "#71717a";
						statusDot.style.boxShadow = "none";
						return;
					}
					sessionStartedAt = response.sessionStartedAt ?? 0;
					if (response.tabId !== void 0) try {
						const storedTabId = sessionStorage.getItem(tabIdStorageKey);
						if (storedTabId && storedTabId !== String(response.tabId)) {
							tabInstanceId = generateUniqueInstanceId();
							sessionStorage.setItem(instanceStorageKey, tabInstanceId);
							persistVisitStart(response.visitStartedAt || pageLoadTime);
						}
						sessionStorage.setItem(tabIdStorageKey, String(response.tabId));
					} catch {}
					statusDot.style.background = "#22c55e";
					statusDot.style.boxShadow = "0 0 8px #22c55e";
					const modeStr = response.mode || "";
					p2.textContent = modeStr ? modeStr.charAt(0).toUpperCase() + modeStr.slice(1) : "Active";
					if (modeStr === "restrict") {
						p2.style.background = "rgba(168, 85, 247, 0.15)";
						p2.style.color = "#c084fc";
						p2.style.border = "1px solid rgba(168, 85, 247, 0.3)";
					} else if (modeStr === "block") {
						p2.style.background = "rgba(244, 63, 94, 0.15)";
						p2.style.color = "#fb7185";
						p2.style.border = "1px solid rgba(244, 63, 94, 0.3)";
					}
					if (response.isBlocked) {
						pageBlocked = true;
						isRestrictedPage = false;
						if (response.sessionStartedAt) sessionStartedAt = response.sessionStartedAt;
						distBar.style.display = "none";
						widgetContainer.style.display = "none";
						renderBlockedPage(hostname);
						return;
					} else if (pageBlocked && (!response.isActive || response.mode !== "block")) {
						pageBlocked = false;
						removeBlockedPage();
						window.location.reload();
						return;
					} else if (pageBlocked) {
						renderBlockedPage(hostname);
						return;
					}
					if (response.isRestricted) {
						isRestrictedPage = true;
						const sStart = response.sessionStartedAt ?? sessionStartedAt;
						sessionStartedAt = sStart;
						if (typeof response.visitStartedAt === "number" && response.visitStartedAt > 0) {
							if (visitStartedAt === 0 || response.visitStartedAt <= visitStartedAt) {
								visitStartedAt = response.visitStartedAt;
								persistVisitStart(visitStartedAt);
							}
						}
						if (typeof response.domainSpanStartedAt === "number" && response.domainSpanStartedAt > 0) domainSpanStartedAt = response.domainSpanStartedAt;
						else if (typeof response.domainStartedAt === "number" && response.domainStartedAt > 0) domainSpanStartedAt = response.domainStartedAt;
						else domainSpanStartedAt = 0;
						persistDomainSpanStart(domainSpanStartedAt);
						baseSiteUsageMs = typeof response.baseSiteUsageMs === "number" ? response.baseSiteUsageMs : typeof response.baseSiteUsage === "number" ? response.baseSiteUsage : 0;
						persistBaseUsage(baseSiteUsageMs);
						const snapshotAt = typeof response.usageSnapshotAt === "number" && response.usageSnapshotAt > 0 ? response.usageSnapshotAt : Date.now();
						if (typeof response.totalSiteUsageSec === "number" && response.totalSiteUsageSec >= 0) {
							if (snapshotAt >= usageSnapshotAt) {
								response.totalSiteUsageSec;
								usageSnapshotAt = snapshotAt;
							}
						} else {
							const effectiveSpanStart = domainSpanStartedAt > 0 && sStart > 0 ? Math.max(domainSpanStartedAt, sStart) : domainSpanStartedAt;
							const liveMs = effectiveSpanStart > 0 ? Math.max(0, snapshotAt - effectiveSpanStart) : 0;
							const totalMs = baseSiteUsageMs + liveMs;
							Math.floor(totalMs / 1e3);
							usageSnapshotAt = snapshotAt - totalMs % 1e3;
						}
						if (response.mode === "block") {
							warning.textContent = "Focus Sprint Active (Block Mode)";
							distBar.style.backgroundColor = "#e11d48";
						} else {
							warning.textContent = "You've been distracted";
							distBar.style.backgroundColor = "#be123c";
						}
						ensureDomInjected();
						distBar.style.display = "flex";
						updateDisplayTimers();
					} else {
						isRestrictedPage = false;
						visitStartedAt = 0;
						domainSpanStartedAt = 0;
						baseSiteUsageMs = 0;
						usageSnapshotAt = 0;
						persistVisitStart(0);
						persistDomainSpanStart(0);
						persistBaseUsage(0);
						persistTabActiveMs(0);
						lastVisitSec = -1;
						lastTotalSec = -1;
						distBar.style.display = "none";
						updateDisplayTimers();
					}
				} catch (error) {
					console.error("Nudge sync error:", error);
				} finally {
					isSyncing = false;
				}
			};
			checkImmediateBlock();
			checkImmediateRestricted();
			syncSite();
			setInterval(updateDisplayTimers, 250);
			setInterval(() => {
				syncSite();
			}, 3e3);
			document.addEventListener("visibilitychange", () => {
				syncSite();
			});
			const onLocationChange = () => {
				syncSite();
			};
			window.addEventListener("popstate", onLocationChange);
			window.addEventListener("pageshow", (event) => {
				hasNotifiedLeaving = false;
				if (event.persisted) {
					checkImmediateBlock();
					checkImmediateRestricted();
					syncSite();
				}
			});
			try {
				const origPush = history.pushState;
				history.pushState = function(...args) {
					const ret = origPush.apply(this, args);
					window.dispatchEvent(new Event("nudge_location_change"));
					return ret;
				};
				const origReplace = history.replaceState;
				history.replaceState = function(...args) {
					const ret = origReplace.apply(this, args);
					window.dispatchEvent(new Event("nudge_location_change"));
					return ret;
				};
				window.addEventListener("nudge_location_change", onLocationChange);
			} catch {}
			let hasNotifiedLeaving = false;
			const notifyTabLeaving = () => {
				if (!isRestrictedPage || hasNotifiedLeaving) return;
				hasNotifiedLeaving = true;
				try {
					browser.runtime.sendMessage({
						message: "tab_leaving",
						tabInstanceId,
						hostname
					});
				} catch {}
			};
			window.addEventListener("pagehide", notifyTabLeaving);
			window.addEventListener("beforeunload", notifyTabLeaving);
			browser.storage.onChanged.addListener((changes, area) => {
				if (area !== "local") return;
				if (changes.isActive || changes.mode || changes.blockedSites || changes.restrictedSites || changes.startedAt || changes.domainSpans || changes.sessionSiteUsage) {
					if (pageBlocked && (changes.isActive?.newValue === false || changes.mode?.newValue !== "block")) {
						pageBlocked = false;
						removeBlockedPage();
						window.location.reload();
						return;
					}
					if (changes.startedAt && typeof changes.startedAt.newValue === "number") {
						const newStart = changes.startedAt.newValue > 0 ? changes.startedAt.newValue : 0;
						if (newStart !== sessionStartedAt) {
							sessionStartedAt = newStart;
							if (newStart > 0) {
								baseSiteUsageMs = 0;
								persistBaseUsage(0);
								persistTabActiveMs(0);
								visitStartedAt = pageLoadTime >= newStart ? pageLoadTime : newStart;
								persistVisitStart(visitStartedAt);
								domainSpanStartedAt = 0;
								persistDomainSpanStart(0);
								usageSnapshotAt = 0;
								lastVisitSec = -1;
								lastTotalSec = -1;
								lastSessionSec = -1;
							}
						}
					}
					if (changes.restrictedSites && Array.isArray(changes.restrictedSites.newValue)) {
						const newSites = changes.restrictedSites.newValue;
						if (!isHostBlocked(hostname, newSites)) {
							isRestrictedPage = false;
							visitStartedAt = 0;
							domainSpanStartedAt = 0;
							baseSiteUsageMs = 0;
							usageSnapshotAt = 0;
							persistVisitStart(0);
							persistDomainSpanStart(0);
							persistBaseUsage(0);
							persistTabActiveMs(0);
							lastVisitSec = -1;
							lastTotalSec = -1;
							distBar.style.display = "none";
						}
					}
					checkImmediateBlock();
					checkImmediateRestricted();
					if (changes.isActive?.newValue === false) {
						persistVisitStart(0);
						persistDomainSpanStart(0);
						persistBaseUsage(0);
						persistTabActiveMs(0);
						isRestrictedPage = false;
						visitStartedAt = 0;
						domainSpanStartedAt = 0;
						baseSiteUsageMs = 0;
						usageSnapshotAt = 0;
						sessionStartedAt = 0;
						lastVisitSec = -1;
						lastTotalSec = -1;
						lastSessionSec = -1;
						distBar.style.display = "none";
					}
					syncSite();
				}
			});
		}
	});
	//#endregion
	//#region node_modules/wxt/dist/utils/internal/logger.mjs
	function print$1(method, ...args) {
		if (typeof args[0] === "string") method(`[wxt] ${args.shift()}`, ...args);
		else method("[wxt]", ...args);
	}
	/** Wrapper around `console` with a "[wxt]" prefix */
	var logger$1 = {
		debug: (...args) => print$1(console.debug, ...args),
		log: (...args) => print$1(console.log, ...args),
		warn: (...args) => print$1(console.warn, ...args),
		error: (...args) => print$1(console.error, ...args)
	};
	//#endregion
	//#region node_modules/wxt/dist/utils/internal/custom-events.mjs
	var WxtLocationChangeEvent = class WxtLocationChangeEvent extends Event {
		static EVENT_NAME = getUniqueEventName("wxt:locationchange");
		constructor(newUrl, oldUrl) {
			super(WxtLocationChangeEvent.EVENT_NAME, {});
			this.newUrl = newUrl;
			this.oldUrl = oldUrl;
		}
	};
	/**
	* Returns an event name unique to the extension and content script that's
	* running.
	*/
	function getUniqueEventName(eventName) {
		return `${browser?.runtime?.id}:content:${eventName}`;
	}
	//#endregion
	//#region node_modules/wxt/dist/utils/internal/location-watcher.mjs
	var supportsNavigationApi = typeof globalThis.navigation?.addEventListener === "function";
	/**
	* Create a util that watches for URL changes, dispatching the custom event when
	* detected. Stops watching when content script is invalidated. Uses Navigation
	* API when available, otherwise falls back to polling.
	*/
	function createLocationWatcher(ctx) {
		let lastUrl;
		let watching = false;
		return { run() {
			if (watching) return;
			watching = true;
			lastUrl = new URL(location.href);
			if (supportsNavigationApi) globalThis.navigation.addEventListener("navigate", (event) => {
				const newUrl = new URL(event.destination.url);
				if (newUrl.href === lastUrl.href) return;
				window.dispatchEvent(new WxtLocationChangeEvent(newUrl, lastUrl));
				lastUrl = newUrl;
			}, { signal: ctx.signal });
			else ctx.setInterval(() => {
				const newUrl = new URL(location.href);
				if (newUrl.href !== lastUrl.href) {
					window.dispatchEvent(new WxtLocationChangeEvent(newUrl, lastUrl));
					lastUrl = newUrl;
				}
			}, 1e3);
		} };
	}
	//#endregion
	//#region node_modules/wxt/dist/utils/content-script-context.mjs
	/**
	* Implements
	* [`AbortController`](https://developer.mozilla.org/en-US/docs/Web/API/AbortController).
	* Used to detect and stop content script code when the script is invalidated.
	*
	* It also provides several utilities like `ctx.setTimeout` and
	* `ctx.setInterval` that should be used in content scripts instead of
	* `window.setTimeout` or `window.setInterval`.
	*
	* To create context for testing, you can use the class's constructor:
	*
	* ```ts
	* import { ContentScriptContext } from 'wxt/utils/content-scripts-context';
	*
	* test('storage listener should be removed when context is invalidated', () => {
	*   const ctx = new ContentScriptContext('test');
	*   const item = storage.defineItem('local:count', { defaultValue: 0 });
	*   const watcher = vi.fn();
	*
	*   const unwatch = item.watch(watcher);
	*   ctx.onInvalidated(unwatch); // Listen for invalidate here
	*
	*   await item.setValue(1);
	*   expect(watcher).toBeCalledTimes(1);
	*   expect(watcher).toBeCalledWith(1, 0);
	*
	*   ctx.notifyInvalidated(); // Use this function to invalidate the context
	*   await item.setValue(2);
	*   expect(watcher).toBeCalledTimes(1);
	* });
	* ```
	*/
	var ContentScriptContext = class ContentScriptContext {
		static SCRIPT_STARTED_MESSAGE_TYPE = getUniqueEventName("wxt:content-script-started");
		id;
		abortController;
		locationWatcher = createLocationWatcher(this);
		constructor(contentScriptName, options) {
			this.contentScriptName = contentScriptName;
			this.options = options;
			this.id = Math.random().toString(36).slice(2);
			this.abortController = new AbortController();
			this.stopOldScripts();
			this.listenForNewerScripts();
		}
		get signal() {
			return this.abortController.signal;
		}
		abort(reason) {
			return this.abortController.abort(reason);
		}
		get isInvalid() {
			if (browser.runtime?.id == null) this.notifyInvalidated();
			return this.signal.aborted;
		}
		get isValid() {
			return !this.isInvalid;
		}
		/**
		* Add a listener that is called when the content script's context is
		* invalidated.
		*
		* @example
		*   browser.runtime.onMessage.addListener(cb);
		*   const removeInvalidatedListener = ctx.onInvalidated(() => {
		*     browser.runtime.onMessage.removeListener(cb);
		*   });
		*   // ...
		*   removeInvalidatedListener();
		*
		* @returns A function to remove the listener.
		*/
		onInvalidated(cb) {
			this.signal.addEventListener("abort", cb);
			return () => this.signal.removeEventListener("abort", cb);
		}
		/**
		* Return a promise that never resolves. Useful if you have an async function
		* that shouldn't run after the context is expired.
		*
		* @example
		*   const getValueFromStorage = async () => {
		*     if (ctx.isInvalid) return ctx.block();
		*
		*     // ...
		*   };
		*/
		block() {
			return new Promise(() => {});
		}
		/**
		* Wrapper around `window.setInterval` that automatically clears the interval
		* when invalidated.
		*
		* Intervals can be cleared by calling the normal `clearInterval` function.
		*/
		setInterval(handler, timeout) {
			const id = setInterval(() => {
				if (this.isValid) handler();
			}, timeout);
			this.onInvalidated(() => clearInterval(id));
			return id;
		}
		/**
		* Wrapper around `window.setTimeout` that automatically clears the interval
		* when invalidated.
		*
		* Timeouts can be cleared by calling the normal `setTimeout` function.
		*/
		setTimeout(handler, timeout) {
			const id = setTimeout(() => {
				if (this.isValid) handler();
			}, timeout);
			this.onInvalidated(() => clearTimeout(id));
			return id;
		}
		/**
		* Wrapper around `window.requestAnimationFrame` that automatically cancels
		* the request when invalidated.
		*
		* Callbacks can be canceled by calling the normal `cancelAnimationFrame`
		* function.
		*/
		requestAnimationFrame(callback) {
			const id = requestAnimationFrame((...args) => {
				if (this.isValid) callback(...args);
			});
			this.onInvalidated(() => cancelAnimationFrame(id));
			return id;
		}
		/**
		* Wrapper around `window.requestIdleCallback` that automatically cancels the
		* request when invalidated.
		*
		* Callbacks can be canceled by calling the normal `cancelIdleCallback`
		* function.
		*/
		requestIdleCallback(callback, options) {
			const id = requestIdleCallback((...args) => {
				if (!this.signal.aborted) callback(...args);
			}, options);
			this.onInvalidated(() => cancelIdleCallback(id));
			return id;
		}
		addEventListener(target, type, handler, options) {
			if (type === "wxt:locationchange") {
				if (this.isValid) this.locationWatcher.run();
			}
			target.addEventListener?.(type.startsWith("wxt:") ? getUniqueEventName(type) : type, handler, {
				...options,
				signal: this.signal
			});
		}
		/**
		* @internal
		* Abort the abort controller and execute all `onInvalidated` listeners.
		*/
		notifyInvalidated() {
			this.abort("Content script context invalidated");
			logger$1.debug(`Content script "${this.contentScriptName}" context invalidated`);
		}
		stopOldScripts() {
			document.dispatchEvent(new CustomEvent(ContentScriptContext.SCRIPT_STARTED_MESSAGE_TYPE, { detail: {
				contentScriptName: this.contentScriptName,
				messageId: this.id
			} }));
			if (!this.options?.noScriptStartedPostMessage) window.postMessage({
				type: ContentScriptContext.SCRIPT_STARTED_MESSAGE_TYPE,
				contentScriptName: this.contentScriptName,
				messageId: this.id
			}, "*");
		}
		verifyScriptStartedEvent(event) {
			const isSameContentScript = event.detail?.contentScriptName === this.contentScriptName;
			const isFromSelf = event.detail?.messageId === this.id;
			return isSameContentScript && !isFromSelf;
		}
		listenForNewerScripts() {
			const cb = (event) => {
				if (!(event instanceof CustomEvent) || !this.verifyScriptStartedEvent(event)) return;
				this.notifyInvalidated();
			};
			document.addEventListener(ContentScriptContext.SCRIPT_STARTED_MESSAGE_TYPE, cb);
			this.onInvalidated(() => document.removeEventListener(ContentScriptContext.SCRIPT_STARTED_MESSAGE_TYPE, cb));
		}
	};
	//#endregion
	//#region \0virtual:wxt-content-script-isolated-world-entrypoint?C:/Users/Deepti/Downloads/Projects/Nudge/entrypoints/content.ts
	function print(method, ...args) {
		if (typeof args[0] === "string") method(`[wxt] ${args.shift()}`, ...args);
		else method("[wxt]", ...args);
	}
	/** Wrapper around `console` with a "[wxt]" prefix */
	var logger = {
		debug: (...args) => print(console.debug, ...args),
		log: (...args) => print(console.log, ...args),
		warn: (...args) => print(console.warn, ...args),
		error: (...args) => print(console.error, ...args)
	};
	//#endregion
	return (async () => {
		try {
			const { main, ...options } = content_default;
			return await main(new ContentScriptContext("content", options));
		} catch (err) {
			logger.error(`The content script "content" crashed on startup!`, err);
			throw err;
		}
	})();
})();

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29udGVudC5qcyIsIm5hbWVzIjpbImJyb3dzZXIiLCJwcmludCIsImxvZ2dlciJdLCJzb3VyY2VzIjpbIi4uLy4uLy4uL25vZGVfbW9kdWxlcy93eHQvZGlzdC91dGlscy9kZWZpbmUtY29udGVudC1zY3JpcHQubWpzIiwiLi4vLi4vLi4vbm9kZV9tb2R1bGVzL0B3eHQtZGV2L2Jyb3dzZXIvc3JjL2luZGV4Lm1qcyIsIi4uLy4uLy4uL25vZGVfbW9kdWxlcy93eHQvZGlzdC9icm93c2VyLm1qcyIsIi4uLy4uLy4uL2VudHJ5cG9pbnRzL2NvbnRlbnQudHMiLCIuLi8uLi8uLi9ub2RlX21vZHVsZXMvd3h0L2Rpc3QvdXRpbHMvaW50ZXJuYWwvbG9nZ2VyLm1qcyIsIi4uLy4uLy4uL25vZGVfbW9kdWxlcy93eHQvZGlzdC91dGlscy9pbnRlcm5hbC9jdXN0b20tZXZlbnRzLm1qcyIsIi4uLy4uLy4uL25vZGVfbW9kdWxlcy93eHQvZGlzdC91dGlscy9pbnRlcm5hbC9sb2NhdGlvbi13YXRjaGVyLm1qcyIsIi4uLy4uLy4uL25vZGVfbW9kdWxlcy93eHQvZGlzdC91dGlscy9jb250ZW50LXNjcmlwdC1jb250ZXh0Lm1qcyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyNyZWdpb24gc3JjL3V0aWxzL2RlZmluZS1jb250ZW50LXNjcmlwdC50c1xuZnVuY3Rpb24gZGVmaW5lQ29udGVudFNjcmlwdChkZWZpbml0aW9uKSB7XG5cdHJldHVybiBkZWZpbml0aW9uO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBkZWZpbmVDb250ZW50U2NyaXB0IH07XG4iLCIvLyAjcmVnaW9uIHNuaXBwZXRcbmV4cG9ydCBjb25zdCBicm93c2VyID0gZ2xvYmFsVGhpcy5icm93c2VyPy5ydW50aW1lPy5pZFxuICA/IGdsb2JhbFRoaXMuYnJvd3NlclxuICA6IGdsb2JhbFRoaXMuY2hyb21lO1xuLy8gI2VuZHJlZ2lvbiBzbmlwcGV0XG4iLCJpbXBvcnQgeyBicm93c2VyIGFzIGJyb3dzZXIkMSB9IGZyb20gXCJAd3h0LWRldi9icm93c2VyXCI7XG4vLyNyZWdpb24gc3JjL2Jyb3dzZXIudHNcbi8qKlxuKiBDb250YWlucyB0aGUgYGJyb3dzZXJgIGV4cG9ydCB3aGljaCB5b3Ugc2hvdWxkIHVzZSB0byBhY2Nlc3MgdGhlIGV4dGVuc2lvblxuKiBBUElzIGluIHlvdXIgcHJvamVjdDpcbipcbiogYGBgdHNcbiogaW1wb3J0IHsgYnJvd3NlciB9IGZyb20gJ3d4dC9icm93c2VyJztcbipcbiogYnJvd3Nlci5ydW50aW1lLm9uSW5zdGFsbGVkLmFkZExpc3RlbmVyKCgpID0+IHtcbiogICAvLyAuLi5cbiogfSk7XG4qIGBgYFxuKlxuKiBAbW9kdWxlIHd4dC9icm93c2VyXG4qL1xuY29uc3QgYnJvd3NlciA9IGJyb3dzZXIkMTtcbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgYnJvd3NlciB9O1xuIiwiZXhwb3J0IGRlZmF1bHQgZGVmaW5lQ29udGVudFNjcmlwdCh7XG4gIG1hdGNoZXM6IFtcIjxhbGxfdXJscz5cIl0sXG4gIHJ1bkF0OiBcImRvY3VtZW50X3N0YXJ0XCIsXG5cbiAgbWFpbigpIHtcbiAgICAvLyBPbmx5IHJ1biBvbiB0b3AtbGV2ZWwgcGFnZXMsIG5ldmVyIGluIGlmcmFtZXNcbiAgICBpZiAod2luZG93LnRvcCAhPT0gd2luZG93LnNlbGYpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBmdW5jdGlvbiBmb3JtYXRTZWNvbmRzKHRvdGFsU2VjOiBudW1iZXIpIHtcbiAgICAgIGNvbnN0IHMgPSBNYXRoLm1heCgwLCB0b3RhbFNlYyk7XG4gICAgICBjb25zdCBzZWNvbmRzID0gcyAlIDYwO1xuICAgICAgY29uc3QgbWludXRlcyA9IE1hdGguZmxvb3IocyAvIDYwKSAlIDYwO1xuICAgICAgY29uc3QgaG91cnMgPSBNYXRoLmZsb29yKHMgLyAzNjAwKTtcblxuICAgICAgcmV0dXJuIGAke1N0cmluZyhob3VycykucGFkU3RhcnQoMiwgXCIwXCIpfToke1N0cmluZyhtaW51dGVzKS5wYWRTdGFydChcbiAgICAgICAgMixcbiAgICAgICAgXCIwXCIsXG4gICAgICApfToke1N0cmluZyhzZWNvbmRzKS5wYWRTdGFydCgyLCBcIjBcIil9YDtcbiAgICB9XG5cbiAgICBjb25zdCBob3N0bmFtZSA9IHdpbmRvdy5sb2NhdGlvbi5ob3N0bmFtZS5yZXBsYWNlKC9ed3d3XFwuLywgXCJcIik7XG5cbiAgICAvLyAxLiBESVNUUkFDVElPTiBCQVJcbiAgICBjb25zdCBkaXN0QmFyID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImRpdlwiKTtcbiAgICBjb25zdCB3YXJuaW5nID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImgxXCIpO1xuICAgIGNvbnN0IHRpbWVyID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcInBcIik7XG4gICAgY29uc3QgdG90YWxUaW1lciA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJwXCIpO1xuXG4gICAgZGlzdEJhci5hcHBlbmRDaGlsZCh3YXJuaW5nKTtcbiAgICBkaXN0QmFyLmFwcGVuZENoaWxkKHRpbWVyKTtcbiAgICBkaXN0QmFyLmFwcGVuZENoaWxkKHRvdGFsVGltZXIpO1xuXG4gICAgZGlzdEJhci5zdHlsZS5wb3NpdGlvbiA9IFwiZml4ZWRcIjtcbiAgICBkaXN0QmFyLnN0eWxlLnRvcCA9IFwiMFwiO1xuICAgIGRpc3RCYXIuc3R5bGUubGVmdCA9IFwiMFwiO1xuICAgIGRpc3RCYXIuc3R5bGUud2lkdGggPSBcIjEwMCVcIjtcbiAgICBkaXN0QmFyLnN0eWxlLmhlaWdodCA9IFwiNTBweFwiO1xuICAgIGRpc3RCYXIuc3R5bGUuYmFja2dyb3VuZENvbG9yID0gXCIjYmUxMjNjXCI7XG4gICAgZGlzdEJhci5zdHlsZS5jb2xvciA9IFwid2hpdGVcIjtcbiAgICBkaXN0QmFyLnN0eWxlLmRpc3BsYXkgPSBcIm5vbmVcIjtcbiAgICBkaXN0QmFyLnN0eWxlLmFsaWduSXRlbXMgPSBcImNlbnRlclwiO1xuICAgIGRpc3RCYXIuc3R5bGUuanVzdGlmeUNvbnRlbnQgPSBcInNwYWNlLWJldHdlZW5cIjtcbiAgICBkaXN0QmFyLnN0eWxlLmdhcCA9IFwiMTZweFwiO1xuICAgIGRpc3RCYXIuc3R5bGUucGFkZGluZyA9IFwiMCAyNHB4XCI7XG4gICAgZGlzdEJhci5zdHlsZS5ib3hTaXppbmcgPSBcImJvcmRlci1ib3hcIjtcbiAgICBkaXN0QmFyLnN0eWxlLnpJbmRleCA9IFwiMjE0NzQ4MzY0N1wiO1xuICAgIGRpc3RCYXIuc3R5bGUuZm9udEZhbWlseSA9IFwic3lzdGVtLXVpLCAtYXBwbGUtc3lzdGVtLCBCbGlua01hY1N5c3RlbUZvbnQsICdTZWdvZSBVSScsIFJvYm90bywgc2Fucy1zZXJpZlwiO1xuXG4gICAgd2FybmluZy50ZXh0Q29udGVudCA9IFwiWW91J3ZlIGJlZW4gZGlzdHJhY3RlZFwiO1xuICAgIHdhcm5pbmcuc3R5bGUuZm9udFNpemUgPSBcIjE2cHhcIjtcbiAgICB3YXJuaW5nLnN0eWxlLmZvbnRXZWlnaHQgPSBcIjYwMFwiO1xuICAgIHdhcm5pbmcuc3R5bGUubWFyZ2luID0gXCIwXCI7XG4gICAgd2FybmluZy5zdHlsZS5wYWRkaW5nID0gXCIwXCI7XG4gICAgd2FybmluZy5zdHlsZS53aGl0ZVNwYWNlID0gXCJub3dyYXBcIjtcbiAgICB3YXJuaW5nLnN0eWxlLmZsZXggPSBcIjFcIjtcbiAgICB3YXJuaW5nLnN0eWxlLnRleHRBbGlnbiA9IFwibGVmdFwiO1xuXG4gICAgdGltZXIudGV4dENvbnRlbnQgPSBcIjAwOjAwOjAwXCI7XG4gICAgdGltZXIuc3R5bGUuZm9udFNpemUgPSBcIjE4cHhcIjtcbiAgICB0aW1lci5zdHlsZS5mb250V2VpZ2h0ID0gXCJib2xkXCI7XG4gICAgdGltZXIuc3R5bGUubWFyZ2luID0gXCIwXCI7XG4gICAgdGltZXIuc3R5bGUucGFkZGluZyA9IFwiMFwiO1xuICAgIHRpbWVyLnN0eWxlLnRleHRBbGlnbiA9IFwiY2VudGVyXCI7XG4gICAgdGltZXIuc3R5bGUud2hpdGVTcGFjZSA9IFwibm93cmFwXCI7XG4gICAgdGltZXIuc3R5bGUubGV0dGVyU3BhY2luZyA9IFwiMC41cHhcIjtcbiAgICB0aW1lci5zdHlsZS5mb250VmFyaWFudE51bWVyaWMgPSBcInRhYnVsYXItbnVtc1wiO1xuICAgIHRpbWVyLnN0eWxlLm1pbldpZHRoID0gXCIxMTBweFwiO1xuICAgIHRpbWVyLnN0eWxlLmZsZXggPSBcIjFcIjtcblxuICAgIHRvdGFsVGltZXIudGV4dENvbnRlbnQgPSBcIihUaGlzIHNlc3Npb246IDAwOjAwOjAwKVwiO1xuICAgIHRvdGFsVGltZXIuc3R5bGUuZm9udFNpemUgPSBcIjEzcHhcIjtcbiAgICB0b3RhbFRpbWVyLnN0eWxlLm1hcmdpbiA9IFwiMFwiO1xuICAgIHRvdGFsVGltZXIuc3R5bGUucGFkZGluZyA9IFwiMFwiO1xuICAgIHRvdGFsVGltZXIuc3R5bGUud2hpdGVTcGFjZSA9IFwibm93cmFwXCI7XG4gICAgdG90YWxUaW1lci5zdHlsZS5vcGFjaXR5ID0gXCIwLjlcIjtcbiAgICB0b3RhbFRpbWVyLnN0eWxlLmZvbnRWYXJpYW50TnVtZXJpYyA9IFwidGFidWxhci1udW1zXCI7XG4gICAgdG90YWxUaW1lci5zdHlsZS5taW5XaWR0aCA9IFwiMTcwcHhcIjtcbiAgICB0b3RhbFRpbWVyLnN0eWxlLmZsZXggPSBcIjFcIjtcbiAgICB0b3RhbFRpbWVyLnN0eWxlLnRleHRBbGlnbiA9IFwicmlnaHRcIjtcblxuICAgIC8vIDIuIFVMVFJBLUFUVFJBQ1RJVkUgRkxPQVRJTkcgTlVER0UgV0lER0VUXG4gICAgY29uc3Qgd2lkZ2V0Q29udGFpbmVyID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImRpdlwiKTtcbiAgICB3aWRnZXRDb250YWluZXIuc3R5bGUucG9zaXRpb24gPSBcImZpeGVkXCI7XG4gICAgd2lkZ2V0Q29udGFpbmVyLnN0eWxlLmJvdHRvbSA9IFwiMjBweFwiO1xuICAgIHdpZGdldENvbnRhaW5lci5zdHlsZS5yaWdodCA9IFwiMjBweFwiO1xuICAgIHdpZGdldENvbnRhaW5lci5zdHlsZS56SW5kZXggPSBcIjIxNDc0ODM2NDdcIjtcbiAgICB3aWRnZXRDb250YWluZXIuc3R5bGUuZm9udEZhbWlseSA9IFwic3lzdGVtLXVpLCAtYXBwbGUtc3lzdGVtLCBCbGlua01hY1N5c3RlbUZvbnQsICdTZWdvZSBVSScsIFJvYm90bywgc2Fucy1zZXJpZlwiO1xuICAgIHdpZGdldENvbnRhaW5lci5zdHlsZS51c2VyU2VsZWN0ID0gXCJub25lXCI7XG5cbiAgICAvLyBGbHlvdXQgQ2FyZCAoUGFuZWwpXG4gICAgY29uc3QgZmx5b3V0Q2FyZCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIik7XG4gICAgZmx5b3V0Q2FyZC5zdHlsZS5wb3NpdGlvbiA9IFwiYWJzb2x1dGVcIjtcbiAgICBmbHlvdXRDYXJkLnN0eWxlLmJvdHRvbSA9IFwiNThweFwiO1xuICAgIGZseW91dENhcmQuc3R5bGUucmlnaHQgPSBcIjBcIjtcbiAgICBmbHlvdXRDYXJkLnN0eWxlLndpZHRoID0gXCIyMjBweFwiO1xuICAgIGZseW91dENhcmQuc3R5bGUuYmFja2dyb3VuZCA9IFwicmdiYSgxOCwgMTgsIDI0LCAwLjk0KVwiO1xuICAgIGZseW91dENhcmQuc3R5bGUuYmFja2Ryb3BGaWx0ZXIgPSBcImJsdXIoMjBweClcIjtcbiAgICAoZmx5b3V0Q2FyZC5zdHlsZSBhcyBhbnkpLndlYmtpdEJhY2tkcm9wRmlsdGVyID0gXCJibHVyKDIwcHgpXCI7XG4gICAgZmx5b3V0Q2FyZC5zdHlsZS5jb2xvciA9IFwid2hpdGVcIjtcbiAgICBmbHlvdXRDYXJkLnN0eWxlLmJvcmRlclJhZGl1cyA9IFwiMThweFwiO1xuICAgIGZseW91dENhcmQuc3R5bGUucGFkZGluZyA9IFwiMTZweFwiO1xuICAgIGZseW91dENhcmQuc3R5bGUuYm9yZGVyID0gXCIxcHggc29saWQgcmdiYSgyNTUsIDI1NSwgMjU1LCAwLjEyKVwiO1xuICAgIGZseW91dENhcmQuc3R5bGUuYm94U2hhZG93ID0gXCIwIDIwcHggNDBweCAtOHB4IHJnYmEoMCwgMCwgMCwgMC43KSwgMCAwIDFweCAxcHggcmdiYSgyNTUsIDI1NSwgMjU1LCAwLjA4KVwiO1xuICAgIGZseW91dENhcmQuc3R5bGUuYm94U2l6aW5nID0gXCJib3JkZXItYm94XCI7XG4gICAgZmx5b3V0Q2FyZC5zdHlsZS5vcGFjaXR5ID0gXCIwXCI7XG4gICAgZmx5b3V0Q2FyZC5zdHlsZS50cmFuc2Zvcm0gPSBcInRyYW5zbGF0ZVkoMTBweCkgc2NhbGUoMC45NilcIjtcbiAgICBmbHlvdXRDYXJkLnN0eWxlLnBvaW50ZXJFdmVudHMgPSBcIm5vbmVcIjtcbiAgICBmbHlvdXRDYXJkLnN0eWxlLnRyYW5zaXRpb24gPSBcIm9wYWNpdHkgMC4yMnMgY3ViaWMtYmV6aWVyKDAuMTYsIDEsIDAuMywgMSksIHRyYW5zZm9ybSAwLjIycyBjdWJpYy1iZXppZXIoMC4xNiwgMSwgMC4zLCAxKVwiO1xuXG4gICAgLy8gRmx5b3V0IENhcmQgSGVhZGVyXG4gICAgY29uc3QgY2FyZEhlYWRlciA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIik7XG4gICAgY2FyZEhlYWRlci5zdHlsZS5kaXNwbGF5ID0gXCJmbGV4XCI7XG4gICAgY2FyZEhlYWRlci5zdHlsZS5hbGlnbkl0ZW1zID0gXCJjZW50ZXJcIjtcbiAgICBjYXJkSGVhZGVyLnN0eWxlLmp1c3RpZnlDb250ZW50ID0gXCJzcGFjZS1iZXR3ZWVuXCI7XG4gICAgY2FyZEhlYWRlci5zdHlsZS5tYXJnaW5Cb3R0b20gPSBcIjEwcHhcIjtcblxuICAgIGNvbnN0IGJyYW5kVGl0bGUgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwic3BhblwiKTtcbiAgICBicmFuZFRpdGxlLnRleHRDb250ZW50ID0gXCJOVURHRSBGT0NVU1wiO1xuICAgIGJyYW5kVGl0bGUuc3R5bGUuZm9udFNpemUgPSBcIjExcHhcIjtcbiAgICBicmFuZFRpdGxlLnN0eWxlLmZvbnRXZWlnaHQgPSBcIjgwMFwiO1xuICAgIGJyYW5kVGl0bGUuc3R5bGUubGV0dGVyU3BhY2luZyA9IFwiMC4wNmVtXCI7XG4gICAgYnJhbmRUaXRsZS5zdHlsZS5jb2xvciA9IFwiI2ExYTFhYVwiO1xuXG4gICAgY29uc3QgcDIgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwic3BhblwiKTtcbiAgICBwMi50ZXh0Q29udGVudCA9IFwiSWRsZVwiO1xuICAgIHAyLnN0eWxlLmZvbnRTaXplID0gXCIxMHB4XCI7XG4gICAgcDIuc3R5bGUuZm9udFdlaWdodCA9IFwiNjAwXCI7XG4gICAgcDIuc3R5bGUucGFkZGluZyA9IFwiMnB4IDhweFwiO1xuICAgIHAyLnN0eWxlLmJvcmRlclJhZGl1cyA9IFwiOTk5cHhcIjtcbiAgICBwMi5zdHlsZS5iYWNrZ3JvdW5kID0gXCJyZ2JhKDI1NSwgMjU1LCAyNTUsIDAuMDgpXCI7XG4gICAgcDIuc3R5bGUuY29sb3IgPSBcIiNhMWExYWFcIjtcbiAgICBwMi5zdHlsZS5ib3JkZXIgPSBcIjFweCBzb2xpZCByZ2JhKDI1NSwgMjU1LCAyNTUsIDAuMDgpXCI7XG4gICAgcDIuc3R5bGUudGV4dFRyYW5zZm9ybSA9IFwiY2FwaXRhbGl6ZVwiO1xuXG4gICAgY2FyZEhlYWRlci5hcHBlbmRDaGlsZChicmFuZFRpdGxlKTtcbiAgICBjYXJkSGVhZGVyLmFwcGVuZENoaWxkKHAyKTtcblxuICAgIC8vIFRpbWVyIFNlY3Rpb25cbiAgICBjb25zdCB0aW1lckxhYmVsID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImRpdlwiKTtcbiAgICB0aW1lckxhYmVsLnRleHRDb250ZW50ID0gXCJTRVNTSU9OIFRJTUVcIjtcbiAgICB0aW1lckxhYmVsLnN0eWxlLmZvbnRTaXplID0gXCI5cHhcIjtcbiAgICB0aW1lckxhYmVsLnN0eWxlLmZvbnRXZWlnaHQgPSBcIjcwMFwiO1xuICAgIHRpbWVyTGFiZWwuc3R5bGUubGV0dGVyU3BhY2luZyA9IFwiMC4wOGVtXCI7XG4gICAgdGltZXJMYWJlbC5zdHlsZS5jb2xvciA9IFwiIzcxNzE3YVwiO1xuICAgIHRpbWVyTGFiZWwuc3R5bGUubWFyZ2luQm90dG9tID0gXCIycHhcIjtcblxuICAgIGNvbnN0IHAxID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImRpdlwiKTtcbiAgICBwMS50ZXh0Q29udGVudCA9IFwiMDA6MDA6MDBcIjtcbiAgICBwMS5zdHlsZS5mb250U2l6ZSA9IFwiMjRweFwiO1xuICAgIHAxLnN0eWxlLmZvbnRGYW1pbHkgPSBcInN5c3RlbS11aSwgLWFwcGxlLXN5c3RlbSwgQmxpbmtNYWNTeXN0ZW1Gb250LCAnU2Vnb2UgVUknLCBSb2JvdG8sIHNhbnMtc2VyaWZcIjtcbiAgICBwMS5zdHlsZS5mb250VmFyaWFudE51bWVyaWMgPSBcInRhYnVsYXItbnVtc1wiO1xuICAgIHAxLnN0eWxlLmNvbG9yID0gXCIjZmZmZmZmXCI7XG4gICAgcDEuc3R5bGUubGV0dGVyU3BhY2luZyA9IFwiLTAuMDJlbVwiO1xuICAgIHAxLnN0eWxlLm1hcmdpbkJvdHRvbSA9IFwiMTJweFwiO1xuXG4gICAgLy8gRGl2aWRlclxuICAgIGNvbnN0IGRpdmlkZXIgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpO1xuICAgIGRpdmlkZXIuc3R5bGUuaGVpZ2h0ID0gXCIxcHhcIjtcbiAgICBkaXZpZGVyLnN0eWxlLmJhY2tncm91bmQgPSBcInJnYmEoMjU1LCAyNTUsIDI1NSwgMC4wOClcIjtcbiAgICBkaXZpZGVyLnN0eWxlLm1hcmdpbiA9IFwiOHB4IDAgMTJweCAwXCI7XG5cbiAgICAvLyBWaWV3IERhc2hib2FyZCBCdXR0b25cbiAgICBjb25zdCBkYXNoQnRuID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImJ1dHRvblwiKTtcbiAgICBkYXNoQnRuLmlubmVySFRNTCA9IGBcbiAgICAgIDxzdmcgd2lkdGg9XCIxNFwiIGhlaWdodD1cIjE0XCIgdmlld0JveD1cIjAgMCAyNCAyNFwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgc3Ryb2tlLXdpZHRoPVwiMi41XCIgc3Ryb2tlLWxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZS1saW5lam9pbj1cInJvdW5kXCIgc3R5bGU9XCJtYXJnaW4tcmlnaHQ6IDZweDtcIj5cbiAgICAgICAgPHJlY3QgeD1cIjNcIiB5PVwiM1wiIHdpZHRoPVwiMThcIiBoZWlnaHQ9XCIxOFwiIHJ4PVwiMlwiPjwvcmVjdD5cbiAgICAgICAgPHBhdGggZD1cIk03IDE2aDJcIj48L3BhdGg+XG4gICAgICAgIDxwYXRoIGQ9XCJNMTEgMTJoMlwiPjwvcGF0aD5cbiAgICAgICAgPHBhdGggZD1cIk0xNSA4aDJcIj48L3BhdGg+XG4gICAgICA8L3N2Zz5cbiAgICAgIDxzcGFuPlZpZXcgRGFzaGJvYXJkPC9zcGFuPlxuICAgIGA7XG4gICAgZGFzaEJ0bi5zdHlsZS53aWR0aCA9IFwiMTAwJVwiO1xuICAgIGRhc2hCdG4uc3R5bGUucGFkZGluZyA9IFwiOXB4IDEycHhcIjtcbiAgICBkYXNoQnRuLnN0eWxlLmRpc3BsYXkgPSBcImZsZXhcIjtcbiAgICBkYXNoQnRuLnN0eWxlLmFsaWduSXRlbXMgPSBcImNlbnRlclwiO1xuICAgIGRhc2hCdG4uc3R5bGUuanVzdGlmeUNvbnRlbnQgPSBcImNlbnRlclwiO1xuICAgIGRhc2hCdG4uc3R5bGUuYmFja2dyb3VuZCA9IFwibGluZWFyLWdyYWRpZW50KDEzNWRlZywgIzRmNDZlNSAwJSwgIzYzNjZmMSAxMDAlKVwiO1xuICAgIGRhc2hCdG4uc3R5bGUuY29sb3IgPSBcIiNmZmZmZmZcIjtcbiAgICBkYXNoQnRuLnN0eWxlLmZvbnRTaXplID0gXCIxMnB4XCI7XG4gICAgZGFzaEJ0bi5zdHlsZS5mb250V2VpZ2h0ID0gXCI2MDBcIjtcbiAgICBkYXNoQnRuLnN0eWxlLmJvcmRlclJhZGl1cyA9IFwiMTBweFwiO1xuICAgIGRhc2hCdG4uc3R5bGUuYm9yZGVyID0gXCJub25lXCI7XG4gICAgZGFzaEJ0bi5zdHlsZS5jdXJzb3IgPSBcInBvaW50ZXJcIjtcbiAgICBkYXNoQnRuLnN0eWxlLmJveFNoYWRvdyA9IFwiMCA0cHggMTRweCByZ2JhKDc5LCA3MCwgMjI5LCAwLjQpXCI7XG4gICAgZGFzaEJ0bi5zdHlsZS50cmFuc2l0aW9uID0gXCJhbGwgMC4ycyBjdWJpYy1iZXppZXIoMC4xNiwgMSwgMC4zLCAxKVwiO1xuICAgIGRhc2hCdG4uc3R5bGUub3V0bGluZSA9IFwibm9uZVwiO1xuXG4gICAgZGFzaEJ0bi5hZGRFdmVudExpc3RlbmVyKFwibW91c2VlbnRlclwiLCAoKSA9PiB7XG4gICAgICBkYXNoQnRuLnN0eWxlLnRyYW5zZm9ybSA9IFwidHJhbnNsYXRlWSgtMXB4KVwiO1xuICAgICAgZGFzaEJ0bi5zdHlsZS5maWx0ZXIgPSBcImJyaWdodG5lc3MoMS4xKVwiO1xuICAgICAgZGFzaEJ0bi5zdHlsZS5ib3hTaGFkb3cgPSBcIjAgNnB4IDIwcHggcmdiYSg3OSwgNzAsIDIyOSwgMC41NSlcIjtcbiAgICB9KTtcblxuICAgIGRhc2hCdG4uYWRkRXZlbnRMaXN0ZW5lcihcIm1vdXNlbGVhdmVcIiwgKCkgPT4ge1xuICAgICAgZGFzaEJ0bi5zdHlsZS50cmFuc2Zvcm0gPSBcInRyYW5zbGF0ZVkoMClcIjtcbiAgICAgIGRhc2hCdG4uc3R5bGUuZmlsdGVyID0gXCJicmlnaHRuZXNzKDEpXCI7XG4gICAgICBkYXNoQnRuLnN0eWxlLmJveFNoYWRvdyA9IFwiMCA0cHggMTRweCByZ2JhKDc5LCA3MCwgMjI5LCAwLjQpXCI7XG4gICAgfSk7XG5cbiAgICBkYXNoQnRuLmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCBhc3luYyAoZSkgPT4ge1xuICAgICAgZS5zdG9wUHJvcGFnYXRpb24oKTtcbiAgICAgIHRyeSB7XG4gICAgICAgIGF3YWl0IGJyb3dzZXIucnVudGltZS5zZW5kTWVzc2FnZSh7IG1lc3NhZ2U6IFwib3Blbl9kYXNoYm9hcmRcIiB9KTtcbiAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICBjb25zb2xlLmVycm9yKFwiQ291bGQgbm90IG9wZW4gZGFzaGJvYXJkOlwiLCBlcnIpO1xuICAgICAgfVxuICAgIH0pO1xuXG4gICAgZmx5b3V0Q2FyZC5hcHBlbmRDaGlsZChjYXJkSGVhZGVyKTtcbiAgICBmbHlvdXRDYXJkLmFwcGVuZENoaWxkKHRpbWVyTGFiZWwpO1xuICAgIGZseW91dENhcmQuYXBwZW5kQ2hpbGQocDEpO1xuICAgIGZseW91dENhcmQuYXBwZW5kQ2hpbGQoZGl2aWRlcik7XG4gICAgZmx5b3V0Q2FyZC5hcHBlbmRDaGlsZChkYXNoQnRuKTtcblxuICAgIC8vIEZsb2F0aW5nIEljb24gQnV0dG9uXG4gICAgY29uc3QgaWNvbkJ0biA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIik7XG4gICAgaWNvbkJ0bi5zdHlsZS5wb3NpdGlvbiA9IFwicmVsYXRpdmVcIjtcbiAgICBpY29uQnRuLnN0eWxlLndpZHRoID0gXCI0OHB4XCI7XG4gICAgaWNvbkJ0bi5zdHlsZS5oZWlnaHQgPSBcIjQ4cHhcIjtcbiAgICBpY29uQnRuLnN0eWxlLmJvcmRlclJhZGl1cyA9IFwiNTAlXCI7XG4gICAgaWNvbkJ0bi5zdHlsZS5iYWNrZ3JvdW5kID0gXCJsaW5lYXItZ3JhZGllbnQoMTM1ZGVnLCAjMTgxODFiIDAlLCAjMDkwOTBiIDEwMCUpXCI7XG4gICAgaWNvbkJ0bi5zdHlsZS5ib3JkZXIgPSBcIjFweCBzb2xpZCByZ2JhKDI1NSwgMjU1LCAyNTUsIDAuMTYpXCI7XG4gICAgaWNvbkJ0bi5zdHlsZS5ib3hTaGFkb3cgPSBcIjAgNnB4IDE4cHggLTRweCByZ2JhKDAsIDAsIDAsIDAuNylcIjtcbiAgICBpY29uQnRuLnN0eWxlLmRpc3BsYXkgPSBcImZsZXhcIjtcbiAgICBpY29uQnRuLnN0eWxlLmFsaWduSXRlbXMgPSBcImNlbnRlclwiO1xuICAgIGljb25CdG4uc3R5bGUuanVzdGlmeUNvbnRlbnQgPSBcImNlbnRlclwiO1xuICAgIGljb25CdG4uc3R5bGUuY3Vyc29yID0gXCJwb2ludGVyXCI7XG4gICAgaWNvbkJ0bi5zdHlsZS50cmFuc2l0aW9uID0gXCJhbGwgMC4yNXMgY3ViaWMtYmV6aWVyKDAuMTYsIDEsIDAuMywgMSlcIjtcblxuICAgIC8vIFN0eWxpemVkIFwiTlwiIExldHRlciAoTWF0dGUgd2hpdGUvemluYylcbiAgICBjb25zdCBpY29uVGV4dCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJzcGFuXCIpO1xuICAgIGljb25UZXh0LnRleHRDb250ZW50ID0gXCJOXCI7XG4gICAgaWNvblRleHQuc3R5bGUuZm9udFNpemUgPSBcIjE4cHhcIjtcbiAgICBpY29uVGV4dC5zdHlsZS5mb250V2VpZ2h0ID0gXCI3MDBcIjtcbiAgICBpY29uVGV4dC5zdHlsZS5jb2xvciA9IFwiI2Y0ZjRmNVwiO1xuXG4gICAgLy8gU3RhdHVzIERvdCAoR3JlZW4gcHVsc2UgZm9yIGFjdGl2ZSBmb2N1cylcbiAgICBjb25zdCBzdGF0dXNEb3QgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpO1xuICAgIHN0YXR1c0RvdC5zdHlsZS5wb3NpdGlvbiA9IFwiYWJzb2x1dGVcIjtcbiAgICBzdGF0dXNEb3Quc3R5bGUudG9wID0gXCIxcHhcIjtcbiAgICBzdGF0dXNEb3Quc3R5bGUucmlnaHQgPSBcIjFweFwiO1xuICAgIHN0YXR1c0RvdC5zdHlsZS53aWR0aCA9IFwiMTBweFwiO1xuICAgIHN0YXR1c0RvdC5zdHlsZS5oZWlnaHQgPSBcIjEwcHhcIjtcbiAgICBzdGF0dXNEb3Quc3R5bGUuYm9yZGVyUmFkaXVzID0gXCI1MCVcIjtcbiAgICBzdGF0dXNEb3Quc3R5bGUuYmFja2dyb3VuZCA9IFwiIzcxNzE3YVwiO1xuICAgIHN0YXR1c0RvdC5zdHlsZS5ib3JkZXIgPSBcIjJweCBzb2xpZCAjMDkwOTBiXCI7XG4gICAgc3RhdHVzRG90LnN0eWxlLmJveFNoYWRvdyA9IFwiMCAwIDZweCByZ2JhKDAsIDAsIDAsIDAuNSlcIjtcbiAgICBzdGF0dXNEb3Quc3R5bGUudHJhbnNpdGlvbiA9IFwiYWxsIDAuM3MgZWFzZVwiO1xuXG4gICAgaWNvbkJ0bi5hcHBlbmRDaGlsZChpY29uVGV4dCk7XG4gICAgaWNvbkJ0bi5hcHBlbmRDaGlsZChzdGF0dXNEb3QpO1xuXG4gICAgd2lkZ2V0Q29udGFpbmVyLmFwcGVuZENoaWxkKGZseW91dENhcmQpO1xuICAgIHdpZGdldENvbnRhaW5lci5hcHBlbmRDaGlsZChpY29uQnRuKTtcblxuICAgIC8vIEludGVyYWN0aXZlIE9wZW4vQ2xvc2UgTG9naWNcbiAgICBsZXQgaXNNZW51T3BlbiA9IGZhbHNlO1xuICAgIGxldCBoaWRlVGltZW91dDogYW55ID0gbnVsbDtcblxuICAgIGNvbnN0IG9wZW5NZW51ID0gKCkgPT4ge1xuICAgICAgaWYgKGhpZGVUaW1lb3V0KSBjbGVhclRpbWVvdXQoaGlkZVRpbWVvdXQpO1xuICAgICAgaXNNZW51T3BlbiA9IHRydWU7XG4gICAgICBmbHlvdXRDYXJkLnN0eWxlLm9wYWNpdHkgPSBcIjFcIjtcbiAgICAgIGZseW91dENhcmQuc3R5bGUudHJhbnNmb3JtID0gXCJ0cmFuc2xhdGVZKDApIHNjYWxlKDEpXCI7XG4gICAgICBmbHlvdXRDYXJkLnN0eWxlLnBvaW50ZXJFdmVudHMgPSBcImF1dG9cIjtcbiAgICAgIGljb25CdG4uc3R5bGUudHJhbnNmb3JtID0gXCJzY2FsZSgxLjA1KVwiO1xuICAgICAgaWNvbkJ0bi5zdHlsZS5ib3hTaGFkb3cgPSBcIjAgMTBweCAyNHB4IC00cHggcmdiYSgwLCAwLCAwLCAwLjgpXCI7XG4gICAgfTtcblxuICAgIGNvbnN0IGNsb3NlTWVudSA9ICgpID0+IHtcbiAgICAgIGlzTWVudU9wZW4gPSBmYWxzZTtcbiAgICAgIGZseW91dENhcmQuc3R5bGUub3BhY2l0eSA9IFwiMFwiO1xuICAgICAgZmx5b3V0Q2FyZC5zdHlsZS50cmFuc2Zvcm0gPSBcInRyYW5zbGF0ZVkoMTBweCkgc2NhbGUoMC45NilcIjtcbiAgICAgIGZseW91dENhcmQuc3R5bGUucG9pbnRlckV2ZW50cyA9IFwibm9uZVwiO1xuICAgICAgaWNvbkJ0bi5zdHlsZS50cmFuc2Zvcm0gPSBcInNjYWxlKDEpXCI7XG4gICAgICBpY29uQnRuLnN0eWxlLmJveFNoYWRvdyA9IFwiMCA2cHggMThweCAtNHB4IHJnYmEoMCwgMCwgMCwgMC43KVwiO1xuICAgIH07XG5cbiAgICB3aWRnZXRDb250YWluZXIuYWRkRXZlbnRMaXN0ZW5lcihcIm1vdXNlZW50ZXJcIiwgKCkgPT4ge1xuICAgICAgb3Blbk1lbnUoKTtcbiAgICB9KTtcblxuICAgIHdpZGdldENvbnRhaW5lci5hZGRFdmVudExpc3RlbmVyKFwibW91c2VsZWF2ZVwiLCAoKSA9PiB7XG4gICAgICBoaWRlVGltZW91dCA9IHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICBjbG9zZU1lbnUoKTtcbiAgICAgIH0sIDE1MCk7XG4gICAgfSk7XG5cbiAgICBpY29uQnRuLmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCAoZSkgPT4ge1xuICAgICAgZS5zdG9wUHJvcGFnYXRpb24oKTtcbiAgICAgIGlmIChpc01lbnVPcGVuKSB7XG4gICAgICAgIGNsb3NlTWVudSgpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgb3Blbk1lbnUoKTtcbiAgICAgIH1cbiAgICB9KTtcblxuICAgIC8vIDMuIFNUQVRFIFZBUklBQkxFUyAoQW5jaG9yZWQgdG8gYmFja2VuZCBzdGFydCB0aW1lc3RhbXBzKVxuICAgIGNvbnN0IHBhZ2VMb2FkVGltZSA9IERhdGUubm93KCk7XG5cbiAgICAvLyBEZXRlY3QgaWYgdGhpcyBwYWdlIGxvYWQgaXMgYSByZWxvYWQgKEY1IC8gQ3RybCtSIC8gbG9jYXRpb24ucmVsb2FkKCkpXG4gICAgY29uc3QgbmF2RW50cmllcyA9XG4gICAgICB0eXBlb2YgcGVyZm9ybWFuY2UgIT09IFwidW5kZWZpbmVkXCIgJiYgdHlwZW9mIHBlcmZvcm1hbmNlLmdldEVudHJpZXNCeVR5cGUgPT09IFwiZnVuY3Rpb25cIlxuICAgICAgICA/IChwZXJmb3JtYW5jZS5nZXRFbnRyaWVzQnlUeXBlKFwibmF2aWdhdGlvblwiKSBhcyBQZXJmb3JtYW5jZU5hdmlnYXRpb25UaW1pbmdbXSlcbiAgICAgICAgOiBbXTtcbiAgICBjb25zdCBpc1BhZ2VSZWxvYWQgPSBuYXZFbnRyaWVzWzBdPy50eXBlID09PSBcInJlbG9hZFwiO1xuXG4gICAgLy8gU3RvcmFnZSBrZXlzIGZvciBwZXItdGFiIHNlc3Npb24gc3RhdGVcbiAgICBjb25zdCB2aXNpdFN0b3JhZ2VLZXkgPSBgbnVkZ2VfdGFiX3Zpc2l0X3N0YXJ0XyR7aG9zdG5hbWV9YDtcbiAgICBjb25zdCBpbnN0YW5jZVN0b3JhZ2VLZXkgPSBgbnVkZ2VfdGFiX2luc3RhbmNlXyR7aG9zdG5hbWV9YDtcbiAgICBjb25zdCBkb21haW5TcGFuU3RvcmFnZUtleSA9IGBudWRnZV90YWJfZG9tYWluX3NwYW5fc3RhcnRfJHtob3N0bmFtZX1gO1xuICAgIGNvbnN0IGJhc2VVc2FnZVN0b3JhZ2VLZXkgPSBgbnVkZ2VfdGFiX2Jhc2VfdXNhZ2VfJHtob3N0bmFtZX1gO1xuICAgIGNvbnN0IGxhc3RUaWNrU3RvcmFnZUtleSA9IGBudWRnZV90YWJfbGFzdF90aWNrXyR7aG9zdG5hbWV9YDtcbiAgICBjb25zdCB0YWJJZFN0b3JhZ2VLZXkgPSBgbnVkZ2VfdGFiX2lkXyR7aG9zdG5hbWV9YDtcbiAgICBjb25zdCB0YWJBY3RpdmVTdG9yYWdlS2V5ID0gYG51ZGdlX3RhYl9hY3RpdmVfbXNfJHtob3N0bmFtZX1gO1xuXG4gICAgY29uc3QgZ2V0U3RvcmVkVGFiQWN0aXZlTXMgPSAoKTogbnVtYmVyID0+IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHZhbCA9IHNlc3Npb25TdG9yYWdlLmdldEl0ZW0odGFiQWN0aXZlU3RvcmFnZUtleSk7XG4gICAgICAgIGlmICh2YWwpIHtcbiAgICAgICAgICBjb25zdCBudW0gPSBwYXJzZUludCh2YWwsIDEwKTtcbiAgICAgICAgICBpZiAoIWlzTmFOKG51bSkgJiYgbnVtID49IDApIHJldHVybiBudW07XG4gICAgICAgIH1cbiAgICAgIH0gY2F0Y2gge31cbiAgICAgIHJldHVybiAwO1xuICAgIH07XG5cbiAgICBjb25zdCBwZXJzaXN0VGFiQWN0aXZlTXMgPSAobXM6IG51bWJlcikgPT4ge1xuICAgICAgdHJ5IHtcbiAgICAgICAgaWYgKG1zID49IDApIHtcbiAgICAgICAgICBzZXNzaW9uU3RvcmFnZS5zZXRJdGVtKHRhYkFjdGl2ZVN0b3JhZ2VLZXksIFN0cmluZyhtcykpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHNlc3Npb25TdG9yYWdlLnJlbW92ZUl0ZW0odGFiQWN0aXZlU3RvcmFnZUtleSk7XG4gICAgICAgIH1cbiAgICAgIH0gY2F0Y2gge31cbiAgICB9O1xuXG4gICAgY29uc3QgZ2V0TGFzdFRpY2sgPSAoKTogbnVtYmVyID0+IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHZhbCA9IHNlc3Npb25TdG9yYWdlLmdldEl0ZW0obGFzdFRpY2tTdG9yYWdlS2V5KTtcbiAgICAgICAgaWYgKHZhbCkge1xuICAgICAgICAgIGNvbnN0IG51bSA9IHBhcnNlSW50KHZhbCwgMTApO1xuICAgICAgICAgIGlmICghaXNOYU4obnVtKSAmJiBudW0gPiAwKSByZXR1cm4gbnVtO1xuICAgICAgICB9XG4gICAgICB9IGNhdGNoIHt9XG4gICAgICByZXR1cm4gMDtcbiAgICB9O1xuXG4gICAgY29uc3QgdXBkYXRlTGFzdFRpY2sgPSAoKSA9PiB7XG4gICAgICB0cnkge1xuICAgICAgICBzZXNzaW9uU3RvcmFnZS5zZXRJdGVtKGxhc3RUaWNrU3RvcmFnZUtleSwgU3RyaW5nKERhdGUubm93KCkpKTtcbiAgICAgIH0gY2F0Y2gge31cbiAgICB9O1xuXG4gICAgY29uc3QgZ2V0U3RvcmVkVmlzaXRTdGFydCA9ICgpOiBudW1iZXIgPT4ge1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgdmFsID0gc2Vzc2lvblN0b3JhZ2UuZ2V0SXRlbSh2aXNpdFN0b3JhZ2VLZXkpO1xuICAgICAgICBpZiAodmFsKSB7XG4gICAgICAgICAgY29uc3QgbnVtID0gcGFyc2VJbnQodmFsLCAxMCk7XG4gICAgICAgICAgaWYgKCFpc05hTihudW0pICYmIG51bSA+IDApIHJldHVybiBudW07XG4gICAgICAgIH1cbiAgICAgIH0gY2F0Y2gge31cbiAgICAgIHJldHVybiAwO1xuICAgIH07XG5cbiAgICBjb25zdCBwZXJzaXN0VmlzaXRTdGFydCA9IChzdGFydDogbnVtYmVyKSA9PiB7XG4gICAgICB0cnkge1xuICAgICAgICBpZiAoc3RhcnQgPiAwKSB7XG4gICAgICAgICAgc2Vzc2lvblN0b3JhZ2Uuc2V0SXRlbSh2aXNpdFN0b3JhZ2VLZXksIFN0cmluZyhzdGFydCkpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHNlc3Npb25TdG9yYWdlLnJlbW92ZUl0ZW0odmlzaXRTdG9yYWdlS2V5KTtcbiAgICAgICAgfVxuICAgICAgfSBjYXRjaCB7fVxuICAgIH07XG5cbiAgICBjb25zdCBnZXRTdG9yZWREb21haW5TcGFuU3RhcnQgPSAoKTogbnVtYmVyID0+IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHZhbCA9IHNlc3Npb25TdG9yYWdlLmdldEl0ZW0oZG9tYWluU3BhblN0b3JhZ2VLZXkpO1xuICAgICAgICBpZiAodmFsKSB7XG4gICAgICAgICAgY29uc3QgbnVtID0gcGFyc2VJbnQodmFsLCAxMCk7XG4gICAgICAgICAgaWYgKCFpc05hTihudW0pICYmIG51bSA+IDApIHJldHVybiBudW07XG4gICAgICAgIH1cbiAgICAgIH0gY2F0Y2gge31cbiAgICAgIHJldHVybiAwO1xuICAgIH07XG5cbiAgICBjb25zdCBwZXJzaXN0RG9tYWluU3BhblN0YXJ0ID0gKHN0YXJ0OiBudW1iZXIpID0+IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGlmIChzdGFydCA+IDApIHtcbiAgICAgICAgICBzZXNzaW9uU3RvcmFnZS5zZXRJdGVtKGRvbWFpblNwYW5TdG9yYWdlS2V5LCBTdHJpbmcoc3RhcnQpKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBzZXNzaW9uU3RvcmFnZS5yZW1vdmVJdGVtKGRvbWFpblNwYW5TdG9yYWdlS2V5KTtcbiAgICAgICAgfVxuICAgICAgfSBjYXRjaCB7fVxuICAgIH07XG5cbiAgICBjb25zdCBnZXRTdG9yZWRCYXNlVXNhZ2UgPSAoKTogbnVtYmVyID0+IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHZhbCA9IHNlc3Npb25TdG9yYWdlLmdldEl0ZW0oYmFzZVVzYWdlU3RvcmFnZUtleSk7XG4gICAgICAgIGlmICh2YWwpIHtcbiAgICAgICAgICBjb25zdCBudW0gPSBwYXJzZUludCh2YWwsIDEwKTtcbiAgICAgICAgICBpZiAoIWlzTmFOKG51bSkgJiYgbnVtID49IDApIHJldHVybiBudW07XG4gICAgICAgIH1cbiAgICAgIH0gY2F0Y2gge31cbiAgICAgIHJldHVybiAwO1xuICAgIH07XG5cbiAgICBjb25zdCBwZXJzaXN0QmFzZVVzYWdlID0gKHVzYWdlOiBudW1iZXIpID0+IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGlmICh1c2FnZSA+PSAwKSB7XG4gICAgICAgICAgc2Vzc2lvblN0b3JhZ2Uuc2V0SXRlbShiYXNlVXNhZ2VTdG9yYWdlS2V5LCBTdHJpbmcodXNhZ2UpKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBzZXNzaW9uU3RvcmFnZS5yZW1vdmVJdGVtKGJhc2VVc2FnZVN0b3JhZ2VLZXkpO1xuICAgICAgICB9XG4gICAgICB9IGNhdGNoIHt9XG4gICAgfTtcblxuICAgIGNvbnN0IGdlbmVyYXRlVW5pcXVlSW5zdGFuY2VJZCA9ICgpOiBzdHJpbmcgPT4ge1xuICAgICAgcmV0dXJuIFwidGFiX1wiICsgRGF0ZS5ub3coKSArIFwiX1wiICsgTWF0aC5yYW5kb20oKS50b1N0cmluZygzNikuc2xpY2UoMiwgOSk7XG4gICAgfTtcblxuICAgIGNvbnN0IGdldFN0b3JlZFRhYkluc3RhbmNlSWQgPSAoKTogc3RyaW5nID0+IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHZhbCA9IHNlc3Npb25TdG9yYWdlLmdldEl0ZW0oaW5zdGFuY2VTdG9yYWdlS2V5KTtcbiAgICAgICAgaWYgKHZhbCkgcmV0dXJuIHZhbDtcbiAgICAgIH0gY2F0Y2gge31cbiAgICAgIHJldHVybiBcIlwiO1xuICAgIH07XG5cbiAgICAvLyBJZiByZWxvYWRpbmcgYW4gZXhpc3RpbmcgdGFiIE9SIG5hdmlnYXRpbmcgd2l0aGluIHRoZSBzYW1lIGRvbWFpbiBvbiB0aGUgc2FtZSB0YWIsXG4gICAgLy8gcHJlc2VydmUgaXRzIHZpc2l0IGFuY2hvciBmcm9tIHNlc3Npb25TdG9yYWdlLlxuICAgIC8vIElmIG9wZW5pbmcgYSBuZXcgdGFiIG9yIGR1cGxpY2F0ZWQgdGFiLCBzdGFydCBmcmVzaCBzbyBpdCBkb2VzIE5PVCBpbmhlcml0IGEgc2libGluZydzIHZpc2l0LlxuICAgIGxldCB0YWJJbnN0YW5jZUlkID0gXCJcIjtcbiAgICBsZXQgdmlzaXRTdGFydGVkQXQgPSAwO1xuICAgIGxldCBkb21haW5TcGFuU3RhcnRlZEF0ID0gMDtcbiAgICBsZXQgYmFzZVNpdGVVc2FnZU1zID0gMDtcbiAgICAvLyBDYW5vbmljYWwgZG9tYWluLXRvdGFsIHNuYXBzaG90IGZyb20gYmFja2dyb3VuZCAoc2Vjb25kcykgKyB3aGVuIGl0IHdhcyB0YWtlblxuICAgIGxldCB1c2FnZVNuYXBzaG90U2VjID0gMDtcbiAgICBsZXQgdXNhZ2VTbmFwc2hvdEF0ID0gMDtcblxuICAgIGNvbnN0IHN0b3JlZFZpc2l0ID0gZ2V0U3RvcmVkVmlzaXRTdGFydCgpO1xuICAgIGNvbnN0IHN0b3JlZEluc3RhbmNlID0gZ2V0U3RvcmVkVGFiSW5zdGFuY2VJZCgpO1xuICAgIC8vIE9ubHkgYWN0dWFsIHBhZ2UgcmVsb2FkcyBwcmVzZXJ2ZSBzdG9yZWQgdmlzaXQgc3RhcnQgZnJvbSBzZXNzaW9uU3RvcmFnZS5cbiAgICAvLyBEdXBsaWNhdGVkIHRhYnMgKHdoZXJlIGlzUGFnZVJlbG9hZCBpcyBmYWxzZSkgbXVzdCBzdGFydCBmcmVzaCBhbmQgbm90IGluaGVyaXQgdGltZXJzLlxuICAgIGNvbnN0IGlzQ29udGludWluZ1Zpc2l0ID0gaXNQYWdlUmVsb2FkICYmIHN0b3JlZFZpc2l0ID4gMDtcblxuICAgIGlmIChpc0NvbnRpbnVpbmdWaXNpdCkge1xuICAgICAgdGFiSW5zdGFuY2VJZCA9IHN0b3JlZEluc3RhbmNlIHx8IGdlbmVyYXRlVW5pcXVlSW5zdGFuY2VJZCgpO1xuICAgICAgdmlzaXRTdGFydGVkQXQgPSBzdG9yZWRWaXNpdCA+IDAgPyBzdG9yZWRWaXNpdCA6IHBhZ2VMb2FkVGltZTtcbiAgICAgIC8vIE5ldmVyIGludmVudCBhIHNoYXJlZCBkb21haW4gc3RhcnQgZnJvbSB0aGUgcGVyLXRhYiB2aXNpdCBzdGFydFxuICAgICAgZG9tYWluU3BhblN0YXJ0ZWRBdCA9IGdldFN0b3JlZERvbWFpblNwYW5TdGFydCgpO1xuICAgICAgYmFzZVNpdGVVc2FnZU1zID0gZ2V0U3RvcmVkQmFzZVVzYWdlKCk7XG4gICAgICAvLyBXYWl0IGZvciBzdG9yYWdlL3N5bmMgc25hcHNob3Qgc28gd2UgZG8gbm90IHVuZGVyL292ZXItY291bnQgdGhlIGxpdmUgc3BhblxuICAgICAgdXNhZ2VTbmFwc2hvdFNlYyA9IDA7XG4gICAgICB1c2FnZVNuYXBzaG90QXQgPSAwO1xuICAgIH0gZWxzZSB7XG4gICAgICAvLyBOZXcgbmF2aWdhdGlvbiBvciBkdXBsaWNhdGVkIHRhYjogZ2VuZXJhdGUgYSBmcmVzaCB1bmlxdWUgSURcbiAgICAgIHRhYkluc3RhbmNlSWQgPSBnZW5lcmF0ZVVuaXF1ZUluc3RhbmNlSWQoKTtcbiAgICAgIHZpc2l0U3RhcnRlZEF0ID0gcGFnZUxvYWRUaW1lO1xuICAgICAgZG9tYWluU3BhblN0YXJ0ZWRBdCA9IDA7XG4gICAgICBiYXNlU2l0ZVVzYWdlTXMgPSAwO1xuICAgICAgdXNhZ2VTbmFwc2hvdFNlYyA9IDA7XG4gICAgICB1c2FnZVNuYXBzaG90QXQgPSAwO1xuICAgICAgcGVyc2lzdFZpc2l0U3RhcnQodmlzaXRTdGFydGVkQXQpO1xuICAgICAgcGVyc2lzdERvbWFpblNwYW5TdGFydCgwKTtcbiAgICAgIHBlcnNpc3RCYXNlVXNhZ2UoMCk7XG4gICAgICBwZXJzaXN0VGFiQWN0aXZlTXMoMCk7XG4gICAgfVxuICAgIHRyeSB7XG4gICAgICBzZXNzaW9uU3RvcmFnZS5zZXRJdGVtKGluc3RhbmNlU3RvcmFnZUtleSwgdGFiSW5zdGFuY2VJZCk7XG4gICAgfSBjYXRjaCB7fVxuXG4gICAgbGV0IHNlc3Npb25TdGFydGVkQXQgPSAwOyAgICAgLy8gQW5jaG9yZWQgdGltZXN0YW1wIHdoZW4gdGhlIGZvY3VzIHNlc3Npb24gc3RhcnRlZFxuICAgIGxldCBpc1Jlc3RyaWN0ZWRQYWdlID0gZmFsc2U7XG4gICAgbGV0IHBhZ2VCbG9ja2VkID0gZmFsc2U7XG4gICAgbGV0IGlzU3luY2luZyA9IGZhbHNlO1xuICAgIGxldCBsYXRlc3RTeW5jU2VxID0gMDtcblxuICAgIC8vIFBlci10YWIgcGVyc2lzdGVudCBibG9ja2VkIHN0YXRlIGFuY2hvciAoc3Vydml2ZXMgcGFnZSByZWZyZXNoIHdpdGggMG1zIGZsaWNrZXIpXG4gICAgY29uc3QgYmxvY2tTdG9yYWdlS2V5ID0gYG51ZGdlX3RhYl9ibG9ja2VkXyR7aG9zdG5hbWV9YDtcbiAgICBjb25zdCBnZXRTYXZlZEJsb2NrZWRTdGF0ZSA9ICgpOiBib29sZWFuID0+IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIHJldHVybiBzZXNzaW9uU3RvcmFnZS5nZXRJdGVtKGJsb2NrU3RvcmFnZUtleSkgPT09IFwidHJ1ZVwiO1xuICAgICAgfSBjYXRjaCB7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgIH1cbiAgICB9O1xuXG4gICAgY29uc3QgcGVyc2lzdEJsb2NrZWRTdGF0ZSA9IChpc0Jsb2NrZWQ6IGJvb2xlYW4pID0+IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGlmIChpc0Jsb2NrZWQpIHtcbiAgICAgICAgICBzZXNzaW9uU3RvcmFnZS5zZXRJdGVtKGJsb2NrU3RvcmFnZUtleSwgXCJ0cnVlXCIpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHNlc3Npb25TdG9yYWdlLnJlbW92ZUl0ZW0oYmxvY2tTdG9yYWdlS2V5KTtcbiAgICAgICAgfVxuICAgICAgfSBjYXRjaCB7fVxuICAgIH07XG5cbiAgICAvLyBDYWNoZSBsYXN0IGRpc3BsYXllZCB3aG9sZSBzZWNvbmRzIHNvIERPTSBvbmx5IHVwZGF0ZXMgd2hlbiB3aG9sZSBzZWNvbmQgY2hhbmdlc1xuICAgIGxldCBsYXN0VmlzaXRTZWMgPSAtMTtcbiAgICBsZXQgbGFzdFRvdGFsU2VjID0gLTE7XG4gICAgbGV0IGxhc3RTZXNzaW9uU2VjID0gLTE7XG5cbiAgICAvLyBSb2J1c3QgbWF0Y2hlciBmb3IgYmxvY2tlZCBkb21haW5zIChpbmNsdWRpbmcgeC5jb20gPC0+IHR3aXR0ZXIuY29tIGFsaWFzZXMpXG4gICAgZnVuY3Rpb24gaXNIb3N0QmxvY2tlZChob3N0OiBzdHJpbmcsIHNpdGVzOiBzdHJpbmdbXSk6IGJvb2xlYW4ge1xuICAgICAgaWYgKCFob3N0KSByZXR1cm4gZmFsc2U7XG4gICAgICBjb25zdCBjbGVhbkhvc3QgPSBob3N0LnRyaW0oKS50b0xvd2VyQ2FzZSgpLnJlcGxhY2UoL153d3dcXC4vLCBcIlwiKTtcbiAgICAgIGNvbnN0IGNsZWFuU2l0ZXMgPSBzaXRlc1xuICAgICAgICAubWFwKChzKSA9PlxuICAgICAgICAgIHNcbiAgICAgICAgICAgIC50cmltKClcbiAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXG4gICAgICAgICAgICAucmVwbGFjZSgvXmh0dHBzPzpcXC9cXC8vLCBcIlwiKVxuICAgICAgICAgICAgLnJlcGxhY2UoL153d3dcXC4vLCBcIlwiKVxuICAgICAgICAgICAgLnJlcGxhY2UoL1svPyNdLiokLywgXCJcIilcbiAgICAgICAgKVxuICAgICAgICAuZmlsdGVyKEJvb2xlYW4pO1xuXG4gICAgICBpZiAoY2xlYW5TaXRlcy5pbmNsdWRlcyhcInR3aXR0ZXIuY29tXCIpICYmICFjbGVhblNpdGVzLmluY2x1ZGVzKFwieC5jb21cIikpIHtcbiAgICAgICAgY2xlYW5TaXRlcy5wdXNoKFwieC5jb21cIik7XG4gICAgICB9XG4gICAgICBpZiAoY2xlYW5TaXRlcy5pbmNsdWRlcyhcInguY29tXCIpICYmICFjbGVhblNpdGVzLmluY2x1ZGVzKFwidHdpdHRlci5jb21cIikpIHtcbiAgICAgICAgY2xlYW5TaXRlcy5wdXNoKFwidHdpdHRlci5jb21cIik7XG4gICAgICB9XG5cbiAgICAgIGZvciAoY29uc3Qgc2l0ZSBvZiBjbGVhblNpdGVzKSB7XG4gICAgICAgIGlmIChjbGVhbkhvc3QgPT09IHNpdGUgfHwgY2xlYW5Ib3N0LmVuZHNXaXRoKGAuJHtzaXRlfWApKSB7XG4gICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG5cbiAgICBmdW5jdGlvbiBnZXRNYXRjaGluZ1NpdGUoaG9zdDogc3RyaW5nLCBzaXRlczogc3RyaW5nW10pOiBzdHJpbmcgfCBudWxsIHtcbiAgICAgIGlmICghaG9zdCkgcmV0dXJuIG51bGw7XG4gICAgICBjb25zdCBjbGVhbkhvc3QgPSBob3N0LnRyaW0oKS50b0xvd2VyQ2FzZSgpLnJlcGxhY2UoL153d3dcXC4vLCBcIlwiKTtcbiAgICAgIGNvbnN0IGNsZWFuU2l0ZXMgPSBzaXRlc1xuICAgICAgICAubWFwKChzKSA9PlxuICAgICAgICAgIHNcbiAgICAgICAgICAgIC50cmltKClcbiAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXG4gICAgICAgICAgICAucmVwbGFjZSgvXmh0dHBzPzpcXC9cXC8vLCBcIlwiKVxuICAgICAgICAgICAgLnJlcGxhY2UoL153d3dcXC4vLCBcIlwiKVxuICAgICAgICAgICAgLnJlcGxhY2UoL1svPyNdLiokLywgXCJcIilcbiAgICAgICAgKVxuICAgICAgICAuZmlsdGVyKEJvb2xlYW4pO1xuXG4gICAgICBpZiAoY2xlYW5TaXRlcy5pbmNsdWRlcyhcInR3aXR0ZXIuY29tXCIpICYmICFjbGVhblNpdGVzLmluY2x1ZGVzKFwieC5jb21cIikpIHtcbiAgICAgICAgY2xlYW5TaXRlcy5wdXNoKFwieC5jb21cIik7XG4gICAgICB9XG4gICAgICBpZiAoY2xlYW5TaXRlcy5pbmNsdWRlcyhcInguY29tXCIpICYmICFjbGVhblNpdGVzLmluY2x1ZGVzKFwidHdpdHRlci5jb21cIikpIHtcbiAgICAgICAgY2xlYW5TaXRlcy5wdXNoKFwidHdpdHRlci5jb21cIik7XG4gICAgICB9XG5cbiAgICAgIGZvciAoY29uc3Qgc2l0ZSBvZiBjbGVhblNpdGVzKSB7XG4gICAgICAgIGlmIChjbGVhbkhvc3QgPT09IHNpdGUgfHwgY2xlYW5Ib3N0LmVuZHNXaXRoKGAuJHtzaXRlfWApKSB7XG4gICAgICAgICAgcmV0dXJuIHNpdGU7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHJldHVybiBudWxsO1xuICAgIH1cblxuICAgIGNvbnN0IGVuc3VyZURvbUluamVjdGVkID0gKCkgPT4ge1xuICAgICAgaWYgKHBhZ2VCbG9ja2VkKSByZXR1cm47XG4gICAgICBjb25zdCB0YXJnZXQgPSBkb2N1bWVudC5ib2R5O1xuICAgICAgaWYgKCF0YXJnZXQpIHtcbiAgICAgICAgaWYgKGRvY3VtZW50LnJlYWR5U3RhdGUgPT09IFwibG9hZGluZ1wiKSB7XG4gICAgICAgICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcihcbiAgICAgICAgICAgIFwiRE9NQ29udGVudExvYWRlZFwiLFxuICAgICAgICAgICAgKCkgPT4ge1xuICAgICAgICAgICAgICBlbnN1cmVEb21JbmplY3RlZCgpO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHsgb25jZTogdHJ1ZSB9XG4gICAgICAgICAgKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBpZiAoIXRhcmdldC5jb250YWlucyhkaXN0QmFyKSkge1xuICAgICAgICB0YXJnZXQuYXBwZW5kQ2hpbGQoZGlzdEJhcik7XG4gICAgICB9XG4gICAgICBpZiAoIXRhcmdldC5jb250YWlucyh3aWRnZXRDb250YWluZXIpKSB7XG4gICAgICAgIHRhcmdldC5hcHBlbmRDaGlsZCh3aWRnZXRDb250YWluZXIpO1xuICAgICAgfVxuICAgIH07XG5cbiAgICBsZXQgYmxvY2tPYnNlcnZlcjogTXV0YXRpb25PYnNlcnZlciB8IG51bGwgPSBudWxsO1xuXG4gICAgY29uc3QgcmVtb3ZlQmxvY2tlZFBhZ2UgPSAoKSA9PiB7XG4gICAgICBwZXJzaXN0QmxvY2tlZFN0YXRlKGZhbHNlKTtcbiAgICAgIGlmIChibG9ja09ic2VydmVyKSB7XG4gICAgICAgIGJsb2NrT2JzZXJ2ZXIuZGlzY29ubmVjdCgpO1xuICAgICAgICBibG9ja09ic2VydmVyID0gbnVsbDtcbiAgICAgIH1cbiAgICB9O1xuXG4gICAgLy8gRGVkaWNhdGVkIGZ1bmN0aW9uIHRvIHJlbmRlciBhbiB1bi1ieXBhc3NhYmxlLCBhZXN0aGV0aWMgZnVsbC1wYWdlIGJsb2NrIHNjcmVlbiB2aWEgaW5uZXJIVE1MXG4gICAgY29uc3QgcmVuZGVyQmxvY2tlZFBhZ2UgPSAoYmxvY2tlZEhvc3Q6IHN0cmluZykgPT4ge1xuICAgICAgcGFnZUJsb2NrZWQgPSB0cnVlO1xuICAgICAgaXNSZXN0cmljdGVkUGFnZSA9IGZhbHNlO1xuICAgICAgcGVyc2lzdEJsb2NrZWRTdGF0ZSh0cnVlKTtcblxuICAgICAgLy8gMS4gSW1tZWRpYXRlbHkgYWJvcnQgcGVuZGluZyBuZXR3b3JrIGxvYWRzLCBzY3JpcHRzLCBhbmQgbWVkaWEgb24gdGhpcyBibG9ja2VkIHNpdGVcbiAgICAgIHRyeSB7XG4gICAgICAgIHdpbmRvdy5zdG9wKCk7XG4gICAgICB9IGNhdGNoIHt9XG5cbiAgICAgIC8vIElzc3VlIDMgRml4OiBNdXRlLCBwYXVzZSwgYW5kIGRldGFjaCBhbGwgcHJlLWJ1ZmZlcmVkIG1lZGlhIGVsZW1lbnRzIHRvIHByZXZlbnQgYXVkaW8gbGVhayBpbiBiYWNrZ3JvdW5kXG4gICAgICB0cnkge1xuICAgICAgICBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKFwidmlkZW8sIGF1ZGlvXCIpLmZvckVhY2goKG1lZGlhKSA9PiB7XG4gICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnN0IG0gPSBtZWRpYSBhcyBIVE1MTWVkaWFFbGVtZW50O1xuICAgICAgICAgICAgbS5wYXVzZSgpO1xuICAgICAgICAgICAgbS5tdXRlZCA9IHRydWU7XG4gICAgICAgICAgICBtLnJlbW92ZUF0dHJpYnV0ZShcInNyY1wiKTtcbiAgICAgICAgICAgIG0ubG9hZCgpO1xuICAgICAgICAgIH0gY2F0Y2gge31cbiAgICAgICAgfSk7XG4gICAgICB9IGNhdGNoIHt9XG5cbiAgICAgIC8vIDIuIEhpZGUgZGlzdHJhY3Rpb24gYmFyIGFuZCB3aWRnZXQgaWYgcHJlc2VudFxuICAgICAgZGlzdEJhci5zdHlsZS5kaXNwbGF5ID0gXCJub25lXCI7XG4gICAgICB3aWRnZXRDb250YWluZXIuc3R5bGUuZGlzcGxheSA9IFwibm9uZVwiO1xuXG4gICAgICAvLyAzLiBEb2N1bWVudCBsZXZlbCBsb2Nrc1xuICAgICAgZG9jdW1lbnQudGl0bGUgPSBgQmxvY2tlZCDigKIgTnVkZ2UgRm9jdXMgKCR7YmxvY2tlZEhvc3R9KWA7XG5cbiAgICAgIC8vIDQuIENvbnN0cnVjdCBzdWJ0bGUsIG1pbmltYWwgYmxvY2tlZCBwYWdlIEhUTUxcbiAgICAgIGNvbnN0IGJsb2NrZWRIdG1sID0gYFxuICAgICAgICA8ZGl2IGlkPVwibnVkZ2UtYmxvY2tlZC1jb250YWluZXJcIiBzdHlsZT1cIlxuICAgICAgICAgIHBvc2l0aW9uOiBmaXhlZCAhaW1wb3J0YW50O1xuICAgICAgICAgIGluc2V0OiAwICFpbXBvcnRhbnQ7XG4gICAgICAgICAgdG9wOiAwICFpbXBvcnRhbnQ7XG4gICAgICAgICAgbGVmdDogMCAhaW1wb3J0YW50O1xuICAgICAgICAgIHdpZHRoOiAxMDB2dyAhaW1wb3J0YW50O1xuICAgICAgICAgIGhlaWdodDogMTAwdmggIWltcG9ydGFudDtcbiAgICAgICAgICBiYWNrZ3JvdW5kOiAjMDkwOTBiICFpbXBvcnRhbnQ7XG4gICAgICAgICAgZGlzcGxheTogZmxleCAhaW1wb3J0YW50O1xuICAgICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXIgIWltcG9ydGFudDtcbiAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlciAhaW1wb3J0YW50O1xuICAgICAgICAgIGZvbnQtZmFtaWx5OiAtYXBwbGUtc3lzdGVtLCBCbGlua01hY1N5c3RlbUZvbnQsICdTZWdvZSBVSScsIFJvYm90bywgSGVsdmV0aWNhLCBBcmlhbCwgc2Fucy1zZXJpZiAhaW1wb3J0YW50O1xuICAgICAgICAgIGNvbG9yOiAjZjRmNGY1ICFpbXBvcnRhbnQ7XG4gICAgICAgICAgYm94LXNpemluZzogYm9yZGVyLWJveCAhaW1wb3J0YW50O1xuICAgICAgICAgIHBhZGRpbmc6IDI0cHggIWltcG9ydGFudDtcbiAgICAgICAgICB1c2VyLXNlbGVjdDogbm9uZSAhaW1wb3J0YW50O1xuICAgICAgICAgIHotaW5kZXg6IDIxNDc0ODM2NDcgIWltcG9ydGFudDtcbiAgICAgICAgXCI+XG4gICAgICAgICAgPGRpdiBzdHlsZT1cIlxuICAgICAgICAgICAgbWF4LXdpZHRoOiAzODBweDtcbiAgICAgICAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgICAgICAgICAgYm94LXNpemluZzogYm9yZGVyLWJveDtcbiAgICAgICAgICBcIj5cbiAgICAgICAgICAgIDwhLS0gU3VidGxlIHN0YXR1cyBtYXJrIC0tPlxuICAgICAgICAgICAgPGRpdiBzdHlsZT1cIlxuICAgICAgICAgICAgICBkaXNwbGF5OiBpbmxpbmUtZmxleDtcbiAgICAgICAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICAgICAgICAgICAgZ2FwOiA2cHg7XG4gICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTFweDtcbiAgICAgICAgICAgICAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgICAgICAgICAgICAgbGV0dGVyLXNwYWNpbmc6IDAuMDZlbTtcbiAgICAgICAgICAgICAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcbiAgICAgICAgICAgICAgY29sb3I6ICM3MTcxN2E7XG4gICAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IDIwcHg7XG4gICAgICAgICAgICBcIj5cbiAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9XCJcbiAgICAgICAgICAgICAgICB3aWR0aDogNnB4O1xuICAgICAgICAgICAgICAgIGhlaWdodDogNnB4O1xuICAgICAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiAjYTFhMWFhO1xuICAgICAgICAgICAgICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgICAgICAgICAgICAgXCI+PC9zcGFuPlxuICAgICAgICAgICAgICBOdWRnZSBGb2N1c1xuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDwhLS0gQ2xlYW4gRGlyZWN0IFRpdGxlIC0tPlxuICAgICAgICAgICAgPGgxIHN0eWxlPVwiXG4gICAgICAgICAgICAgIGZvbnQtc2l6ZTogMjJweDtcbiAgICAgICAgICAgICAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgICAgICAgICAgICAgY29sb3I6ICNmYWZhZmE7XG4gICAgICAgICAgICAgIGxldHRlci1zcGFjaW5nOiAtMC4wMmVtO1xuICAgICAgICAgICAgICBtYXJnaW46IDAgMCA4cHggMDtcbiAgICAgICAgICAgICAgbGluZS1oZWlnaHQ6IDEuMztcbiAgICAgICAgICAgIFwiPiR7YmxvY2tlZEhvc3R9IGlzIGJsb2NrZWQ8L2gxPlxuXG4gICAgICAgICAgICA8IS0tIFVuZGVyc3RhdGVkIFN1YnRpdGxlIC0tPlxuICAgICAgICAgICAgPHAgc3R5bGU9XCJcbiAgICAgICAgICAgICAgZm9udC1zaXplOiAxM3B4O1xuICAgICAgICAgICAgICBjb2xvcjogIzcxNzE3YTtcbiAgICAgICAgICAgICAgbGluZS1oZWlnaHQ6IDEuNTtcbiAgICAgICAgICAgICAgbWFyZ2luOiAwIDAgMjRweCAwO1xuICAgICAgICAgICAgXCI+XG4gICAgICAgICAgICAgIFRoaXMgc2l0ZSBpcyBibG9ja2VkIGR1cmluZyB5b3VyIGFjdGl2ZSBmb2N1cyBzcHJpbnQuXG4gICAgICAgICAgICA8L3A+XG5cbiAgICAgICAgICAgIDwhLS0gUXVpZXQgU2Vzc2lvbiBEdXJhdGlvbiAtLT5cbiAgICAgICAgICAgIDxkaXYgc3R5bGU9XCJcbiAgICAgICAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICAgICAgICAgICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuICAgICAgICAgICAgICBwYWRkaW5nOiAxMnB4IDE2cHg7XG4gICAgICAgICAgICAgIGJhY2tncm91bmQ6IHJnYmEoMjU1LCAyNTUsIDI1NSwgMC4wMyk7XG4gICAgICAgICAgICAgIGJvcmRlcjogMXB4IHNvbGlkIHJnYmEoMjU1LCAyNTUsIDI1NSwgMC4wOCk7XG4gICAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDEycHg7XG4gICAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IDI0cHg7XG4gICAgICAgICAgICBcIj5cbiAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9XCJmb250LXNpemU6IDEycHg7IGNvbG9yOiAjNzE3MTdhO1wiPkZvY3VzIGVsYXBzZWQ8L3NwYW4+XG4gICAgICAgICAgICAgIDxzcGFuIGlkPVwibnVkZ2UtYmxvY2tlZC10aW1lclwiIHN0eWxlPVwiXG4gICAgICAgICAgICAgICAgZm9udC1zaXplOiAxNHB4O1xuICAgICAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA2MDA7XG4gICAgICAgICAgICAgICAgY29sb3I6ICNlNGU0ZTc7XG4gICAgICAgICAgICAgICAgZm9udC12YXJpYW50LW51bWVyaWM6IHRhYnVsYXItbnVtcztcbiAgICAgICAgICAgICAgICBmb250LWZhbWlseTogdWktbW9ub3NwYWNlLCBTRk1vbm8tUmVndWxhciwgTWVubG8sIE1vbmFjbywgQ29uc29sYXMsIG1vbm9zcGFjZTtcbiAgICAgICAgICAgICAgXCI+JHtzZXNzaW9uU3RhcnRlZEF0ID4gMCA/IGZvcm1hdFNlY29uZHMoTWF0aC5tYXgoMCwgTWF0aC5mbG9vcigoRGF0ZS5ub3coKSAtIHNlc3Npb25TdGFydGVkQXQpIC8gMTAwMCkpKSA6IFwiMDA6MDA6MDBcIn08L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPCEtLSBDbGVhbiBBY3Rpb24gQnV0dG9ucyAtLT5cbiAgICAgICAgICAgIDxkaXYgc3R5bGU9XCJcbiAgICAgICAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgICAgICAgZ2FwOiAxMHB4O1xuICAgICAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgICAgICAgICAgIFwiPlxuICAgICAgICAgICAgICA8YnV0dG9uIGlkPVwibnVkZ2UtYmxvY2stYmFjay1idG5cIiBzdHlsZT1cIlxuICAgICAgICAgICAgICAgIGZsZXg6IDE7XG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZDogIzI3MjcyYTtcbiAgICAgICAgICAgICAgICBjb2xvcjogI2Y0ZjRmNTtcbiAgICAgICAgICAgICAgICBib3JkZXI6IDFweCBzb2xpZCByZ2JhKDI1NSwgMjU1LCAyNTUsIDAuMSk7XG4gICAgICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgICAgICAgICAgICAgICBwYWRkaW5nOiA5cHggMTZweDtcbiAgICAgICAgICAgICAgICBmb250LXNpemU6IDEzcHg7XG4gICAgICAgICAgICAgICAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgICAgICAgICAgICAgICBjdXJzb3I6IHBvaW50ZXI7XG4gICAgICAgICAgICAgICAgdHJhbnNpdGlvbjogYmFja2dyb3VuZCAwLjE1cyBlYXNlLCBib3JkZXItY29sb3IgMC4xNXMgZWFzZTtcbiAgICAgICAgICAgICAgICBvdXRsaW5lOiBub25lO1xuICAgICAgICAgICAgICBcIj5HbyBiYWNrPC9idXR0b24+XG5cbiAgICAgICAgICAgICAgPGJ1dHRvbiBpZD1cIm51ZGdlLWJsb2NrLWRhc2gtYnRuXCIgc3R5bGU9XCJcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbiAgICAgICAgICAgICAgICBjb2xvcjogI2ExYTFhYTtcbiAgICAgICAgICAgICAgICBib3JkZXI6IDFweCBzb2xpZCByZ2JhKDI1NSwgMjU1LCAyNTUsIDAuMDgpO1xuICAgICAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XG4gICAgICAgICAgICAgICAgcGFkZGluZzogOXB4IDE2cHg7XG4gICAgICAgICAgICAgICAgZm9udC1zaXplOiAxM3B4O1xuICAgICAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA1MDA7XG4gICAgICAgICAgICAgICAgY3Vyc29yOiBwb2ludGVyO1xuICAgICAgICAgICAgICAgIHRyYW5zaXRpb246IGJhY2tncm91bmQgMC4xNXMgZWFzZSwgY29sb3IgMC4xNXMgZWFzZTtcbiAgICAgICAgICAgICAgICBvdXRsaW5lOiBub25lO1xuICAgICAgICAgICAgICBcIj5EYXNoYm9hcmQ8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8IS0tIFF1aWV0IEhpbnQgLS0+XG4gICAgICAgICAgICA8ZGl2IHN0eWxlPVwiXG4gICAgICAgICAgICAgIG1hcmdpbi10b3A6IDI0cHg7XG4gICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTFweDtcbiAgICAgICAgICAgICAgY29sb3I6ICM1MjUyNWI7XG4gICAgICAgICAgICAgIGxldHRlci1zcGFjaW5nOiAwLjAyZW07XG4gICAgICAgICAgICBcIj5BbHQgKyDihpAgdG8gcmV0dXJuPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgYDtcblxuICAgICAgLy8gNS4gRGlyZWN0IGlubmVySFRNTCBhc3NpZ25tZW50IHRvIHdpcGUgb3V0IGFsbCBwYWdlIHNjcmlwdHMsIFJlYWN0IHJvb3RzLCBhbmQgc3R5bGluZ1xuICAgICAgaWYgKGRvY3VtZW50LmRvY3VtZW50RWxlbWVudCkge1xuICAgICAgICBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuaW5uZXJIVE1MID0gYFxuICAgICAgICAgIDxoZWFkPlxuICAgICAgICAgICAgPG1ldGEgY2hhcnNldD1cInV0Zi04XCI+XG4gICAgICAgICAgICA8bWV0YSBuYW1lPVwidmlld3BvcnRcIiBjb250ZW50PVwid2lkdGg9ZGV2aWNlLXdpZHRoLCBpbml0aWFsLXNjYWxlPTEuMFwiPlxuICAgICAgICAgICAgPHRpdGxlPkJsb2NrZWQg4oCiIE51ZGdlIEZvY3VzICgke2Jsb2NrZWRIb3N0fSk8L3RpdGxlPlxuICAgICAgICAgICAgPHN0eWxlPlxuICAgICAgICAgICAgICBodG1sLCBib2R5IHtcbiAgICAgICAgICAgICAgICBtYXJnaW46IDAgIWltcG9ydGFudDtcbiAgICAgICAgICAgICAgICBwYWRkaW5nOiAwICFpbXBvcnRhbnQ7XG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZDogIzA5MDkwYiAhaW1wb3J0YW50O1xuICAgICAgICAgICAgICAgIG92ZXJmbG93OiBoaWRkZW4gIWltcG9ydGFudDtcbiAgICAgICAgICAgICAgICB3aWR0aDogMTAwdncgIWltcG9ydGFudDtcbiAgICAgICAgICAgICAgICBoZWlnaHQ6IDEwMHZoICFpbXBvcnRhbnQ7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIDwvc3R5bGU+XG4gICAgICAgICAgPC9oZWFkPlxuICAgICAgICAgIDxib2R5PiR7YmxvY2tlZEh0bWx9PC9ib2R5PlxuICAgICAgICBgO1xuICAgICAgfSBlbHNlIGlmIChkb2N1bWVudC5ib2R5KSB7XG4gICAgICAgIGRvY3VtZW50LmJvZHkuaW5uZXJIVE1MID0gYmxvY2tlZEh0bWw7XG4gICAgICAgIGRvY3VtZW50LmJvZHkuc3R5bGUuY3NzVGV4dCA9IFwibWFyZ2luOjAhaW1wb3J0YW50O3BhZGRpbmc6MCFpbXBvcnRhbnQ7YmFja2dyb3VuZDojMDkwOTBiIWltcG9ydGFudDtvdmVyZmxvdzpoaWRkZW4haW1wb3J0YW50O1wiO1xuICAgICAgfVxuXG4gICAgICAvLyBXaXJlIGludGVyYWN0aXZlIGJ1dHRvbnNcbiAgICAgIGNvbnN0IGJhY2tCdG4gPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcIm51ZGdlLWJsb2NrLWJhY2stYnRuXCIpO1xuICAgICAgaWYgKGJhY2tCdG4pIHtcbiAgICAgICAgYmFja0J0bi5vbm1vdXNlZW50ZXIgPSAoKSA9PiB7XG4gICAgICAgICAgYmFja0J0bi5zdHlsZS5iYWNrZ3JvdW5kID0gXCIjM2YzZjQ2XCI7XG4gICAgICAgICAgYmFja0J0bi5zdHlsZS5ib3JkZXJDb2xvciA9IFwicmdiYSgyNTUsIDI1NSwgMjU1LCAwLjE4KVwiO1xuICAgICAgICB9O1xuICAgICAgICBiYWNrQnRuLm9ubW91c2VsZWF2ZSA9ICgpID0+IHtcbiAgICAgICAgICBiYWNrQnRuLnN0eWxlLmJhY2tncm91bmQgPSBcIiMyNzI3MmFcIjtcbiAgICAgICAgICBiYWNrQnRuLnN0eWxlLmJvcmRlckNvbG9yID0gXCJyZ2JhKDI1NSwgMjU1LCAyNTUsIDAuMSlcIjtcbiAgICAgICAgfTtcbiAgICAgICAgYmFja0J0bi5vbmNsaWNrID0gYXN5bmMgKCkgPT4ge1xuICAgICAgICAgIGlmICh3aW5kb3cuaGlzdG9yeS5sZW5ndGggPiAxKSB7XG4gICAgICAgICAgICB3aW5kb3cuaGlzdG9yeS5iYWNrKCk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgIGF3YWl0IGJyb3dzZXIucnVudGltZS5zZW5kTWVzc2FnZSh7IG1lc3NhZ2U6IFwiY2xvc2VfY3VycmVudF90YWJcIiB9KTtcbiAgICAgICAgICAgIH0gY2F0Y2gge1xuICAgICAgICAgICAgICB3aW5kb3cuY2xvc2UoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgICB9XG5cbiAgICAgIGNvbnN0IGRhc2hCdG4gPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcIm51ZGdlLWJsb2NrLWRhc2gtYnRuXCIpO1xuICAgICAgaWYgKGRhc2hCdG4pIHtcbiAgICAgICAgZGFzaEJ0bi5vbm1vdXNlZW50ZXIgPSAoKSA9PiB7XG4gICAgICAgICAgZGFzaEJ0bi5zdHlsZS5iYWNrZ3JvdW5kID0gXCJyZ2JhKDI1NSwgMjU1LCAyNTUsIDAuMDUpXCI7XG4gICAgICAgICAgZGFzaEJ0bi5zdHlsZS5jb2xvciA9IFwiI2Y0ZjRmNVwiO1xuICAgICAgICB9O1xuICAgICAgICBkYXNoQnRuLm9ubW91c2VsZWF2ZSA9ICgpID0+IHtcbiAgICAgICAgICBkYXNoQnRuLnN0eWxlLmJhY2tncm91bmQgPSBcInRyYW5zcGFyZW50XCI7XG4gICAgICAgICAgZGFzaEJ0bi5zdHlsZS5jb2xvciA9IFwiI2ExYTFhYVwiO1xuICAgICAgICB9O1xuICAgICAgICBkYXNoQnRuLm9uY2xpY2sgPSBhc3luYyAoKSA9PiB7XG4gICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGF3YWl0IGJyb3dzZXIucnVudGltZS5zZW5kTWVzc2FnZSh7IG1lc3NhZ2U6IFwib3Blbl9kYXNoYm9hcmRcIiB9KTtcbiAgICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKFwiRGFzaGJvYXJkIGVycm9yOlwiLCBlKTtcbiAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgICB9XG5cbiAgICAgIC8vIEFjdGl2ZSBHdWFyZDogSWYgYW55IGV4dGVybmFsIHNjcmlwdCBhdHRlbXB0cyB0byB3aXBlIG9yIG1vdW50IG92ZXIgb3VyIGJsb2NrZWQgY29udGFpbmVyLCByZXN0b3JlIGl0XG4gICAgICBpZiAoIWJsb2NrT2JzZXJ2ZXIgJiYgZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50KSB7XG4gICAgICAgIGJsb2NrT2JzZXJ2ZXIgPSBuZXcgTXV0YXRpb25PYnNlcnZlcigoKSA9PiB7XG4gICAgICAgICAgaWYgKCFwYWdlQmxvY2tlZCkgcmV0dXJuO1xuICAgICAgICAgIGlmICghZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJudWRnZS1ibG9ja2VkLWNvbnRhaW5lclwiKSkge1xuICAgICAgICAgICAgcmVuZGVyQmxvY2tlZFBhZ2UoYmxvY2tlZEhvc3QpO1xuICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICAgIGJsb2NrT2JzZXJ2ZXIub2JzZXJ2ZShkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQsIHtcbiAgICAgICAgICBjaGlsZExpc3Q6IHRydWUsXG4gICAgICAgICAgc3VidHJlZTogdHJ1ZSxcbiAgICAgICAgfSk7XG4gICAgICB9XG5cbiAgICAgIC8vIERPTUNvbnRlbnRMb2FkZWQgaG9vazogaWYgZG9jdW1lbnQgd2FzIHN0aWxsIHN0cmVhbWluZyB3aGVuIHN0b3AoKSBvY2N1cnJlZFxuICAgICAgaWYgKGRvY3VtZW50LnJlYWR5U3RhdGUgPT09IFwibG9hZGluZ1wiKSB7XG4gICAgICAgIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoXG4gICAgICAgICAgXCJET01Db250ZW50TG9hZGVkXCIsXG4gICAgICAgICAgKCkgPT4ge1xuICAgICAgICAgICAgaWYgKHBhZ2VCbG9ja2VkICYmICFkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcIm51ZGdlLWJsb2NrZWQtY29udGFpbmVyXCIpKSB7XG4gICAgICAgICAgICAgIHJlbmRlckJsb2NrZWRQYWdlKGJsb2NrZWRIb3N0KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9LFxuICAgICAgICAgIHsgb25jZTogdHJ1ZSB9XG4gICAgICAgICk7XG4gICAgICB9XG4gICAgfTtcblxuICAgIC8vIFN5bmNocm9ub3VzIHJlZnJlc2ggcmVjb3ZlcnkgZnJvbSBzZXNzaW9uU3RvcmFnZTogZWxpbWluYXRlcyBhbnkgZmxpY2tlciBvciBjb250ZW50IGZsYXNoIG9uIHBhZ2UgcmVmcmVzaFxuICAgIGlmIChnZXRTYXZlZEJsb2NrZWRTdGF0ZSgpKSB7XG4gICAgICBwYWdlQmxvY2tlZCA9IHRydWU7XG4gICAgICByZW5kZXJCbG9ja2VkUGFnZShob3N0bmFtZSk7XG4gICAgfVxuXG4gICAgLy8gSW5zdGFudCBjaGVjayBmcm9tIGxvY2FsIGNhY2hlIC0gcnVucyBhdCBkb2N1bWVudF9zdGFydCB3aXRob3V0IHdhaXRpbmcgb24gc2VydmljZSB3b3JrZXJcbiAgICBjb25zdCBjaGVja0ltbWVkaWF0ZUJsb2NrID0gYXN5bmMgKCkgPT4ge1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgZGF0YSA9IChhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuZ2V0KFtcbiAgICAgICAgICBcImlzQWN0aXZlXCIsXG4gICAgICAgICAgXCJtb2RlXCIsXG4gICAgICAgICAgXCJibG9ja2VkU2l0ZXNcIixcbiAgICAgICAgICBcInN0YXJ0ZWRBdFwiLFxuICAgICAgICBdKSkgYXMge1xuICAgICAgICAgIGlzQWN0aXZlPzogYm9vbGVhbjtcbiAgICAgICAgICBtb2RlPzogc3RyaW5nO1xuICAgICAgICAgIGJsb2NrZWRTaXRlcz86IHN0cmluZ1tdO1xuICAgICAgICAgIHN0YXJ0ZWRBdD86IG51bWJlcjtcbiAgICAgICAgfTtcblxuICAgICAgICBpZiAoZGF0YS5pc0FjdGl2ZSAmJiBkYXRhLm1vZGUgPT09IFwiYmxvY2tcIikge1xuICAgICAgICAgIGNvbnN0IHNpdGVzOiBzdHJpbmdbXSA9IEFycmF5LmlzQXJyYXkoZGF0YS5ibG9ja2VkU2l0ZXMpID8gZGF0YS5ibG9ja2VkU2l0ZXMgOiBbXTtcblxuICAgICAgICAgIGlmIChpc0hvc3RCbG9ja2VkKGhvc3RuYW1lLCBzaXRlcykpIHtcbiAgICAgICAgICAgIGlmICh0eXBlb2YgZGF0YS5zdGFydGVkQXQgPT09IFwibnVtYmVyXCIgJiYgZGF0YS5zdGFydGVkQXQgPiAwKSB7XG4gICAgICAgICAgICAgIHNlc3Npb25TdGFydGVkQXQgPSBkYXRhLnN0YXJ0ZWRBdDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHBhZ2VCbG9ja2VkID0gdHJ1ZTtcbiAgICAgICAgICAgIGlzUmVzdHJpY3RlZFBhZ2UgPSBmYWxzZTtcbiAgICAgICAgICAgIHBlcnNpc3RCbG9ja2VkU3RhdGUodHJ1ZSk7XG4gICAgICAgICAgICByZW5kZXJCbG9ja2VkUGFnZShob3N0bmFtZSk7XG4gICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgICB9IGVsc2UgaWYgKHBhZ2VCbG9ja2VkKSB7XG4gICAgICAgICAgICBwYWdlQmxvY2tlZCA9IGZhbHNlO1xuICAgICAgICAgICAgcmVtb3ZlQmxvY2tlZFBhZ2UoKTtcbiAgICAgICAgICAgIHdpbmRvdy5sb2NhdGlvbi5yZWxvYWQoKTtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSBpZiAocGFnZUJsb2NrZWQpIHtcbiAgICAgICAgICBwYWdlQmxvY2tlZCA9IGZhbHNlO1xuICAgICAgICAgIHJlbW92ZUJsb2NrZWRQYWdlKCk7XG4gICAgICAgICAgd2luZG93LmxvY2F0aW9uLnJlbG9hZCgpO1xuICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgIGNvbnNvbGUud2FybihcIkltbWVkaWF0ZSBibG9jayBjaGVjazpcIiwgZXJyKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9O1xuXG4gICAgLy8gSW5zdGFudCBjaGVjayBmcm9tIGxvY2FsIGNhY2hlIGZvciByZXN0cmljdGVkIHNpdGVzIChydW5zIGF0IGRvY3VtZW50X3N0YXJ0IHdpdGhvdXQgMDA6MDA6MDAgZmxpY2tlcilcbiAgICBjb25zdCBjaGVja0ltbWVkaWF0ZVJlc3RyaWN0ZWQgPSBhc3luYyAoKSA9PiB7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCBkYXRhID0gKGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5nZXQoW1xuICAgICAgICAgIFwiaXNBY3RpdmVcIixcbiAgICAgICAgICBcIm1vZGVcIixcbiAgICAgICAgICBcInJlc3RyaWN0ZWRTaXRlc1wiLFxuICAgICAgICAgIFwic3RhcnRlZEF0XCIsXG4gICAgICAgICAgXCJzZXNzaW9uU2l0ZVVzYWdlXCIsXG4gICAgICAgICAgXCJkb21haW5TcGFuc1wiLFxuICAgICAgICAgIFwiYWN0aXZlVmlzaXRzXCIsXG4gICAgICAgIF0pKSBhcyB7XG4gICAgICAgICAgaXNBY3RpdmU/OiBib29sZWFuO1xuICAgICAgICAgIG1vZGU/OiBzdHJpbmc7XG4gICAgICAgICAgcmVzdHJpY3RlZFNpdGVzPzogc3RyaW5nW107XG4gICAgICAgICAgc3RhcnRlZEF0PzogbnVtYmVyO1xuICAgICAgICAgIHNlc3Npb25TaXRlVXNhZ2U/OiBSZWNvcmQ8c3RyaW5nLCBudW1iZXI+O1xuICAgICAgICAgIGRvbWFpblNwYW5zPzogUmVjb3JkPHN0cmluZywgYW55PjtcbiAgICAgICAgICBhY3RpdmVWaXNpdHM/OiBSZWNvcmQ8c3RyaW5nLCBhbnk+O1xuICAgICAgICB9O1xuXG4gICAgICAgIGlmIChkYXRhLmlzQWN0aXZlICYmIChkYXRhLm1vZGUgPT09IFwicmVzdHJpY3RcIiB8fCBkYXRhLm1vZGUgPT09IFwiYmxvY2tcIikpIHtcbiAgICAgICAgICBjb25zdCBzaXRlczogc3RyaW5nW10gPSBBcnJheS5pc0FycmF5KGRhdGEucmVzdHJpY3RlZFNpdGVzKSA/IGRhdGEucmVzdHJpY3RlZFNpdGVzIDogW107XG5cbiAgICAgICAgICBpZiAoaXNIb3N0QmxvY2tlZChob3N0bmFtZSwgc2l0ZXMpKSB7XG4gICAgICAgICAgICBjb25zdCBzU3RhcnQgPSB0eXBlb2YgZGF0YS5zdGFydGVkQXQgPT09IFwibnVtYmVyXCIgJiYgZGF0YS5zdGFydGVkQXQgPiAwID8gZGF0YS5zdGFydGVkQXQgOiAwO1xuICAgICAgICAgICAgc2Vzc2lvblN0YXJ0ZWRBdCA9IHNTdGFydDtcbiAgICAgICAgICAgIGlzUmVzdHJpY3RlZFBhZ2UgPSB0cnVlO1xuXG4gICAgICAgICAgICBjb25zdCBtYXRjaGVkID0gZ2V0TWF0Y2hpbmdTaXRlKGhvc3RuYW1lLCBzaXRlcykgfHwgaG9zdG5hbWU7XG5cbiAgICAgICAgICAgIC8vIFVzYWdlIG1zIGZyb20gcHJpb3IgY29tcGxldGVkIHNwYW5zXG4gICAgICAgICAgICBjb25zdCB1c2FnZSA9IGRhdGEuc2Vzc2lvblNpdGVVc2FnZSA/PyB7fTtcbiAgICAgICAgICAgIGlmICh0eXBlb2YgdXNhZ2VbbWF0Y2hlZF0gPT09IFwibnVtYmVyXCIpIHtcbiAgICAgICAgICAgICAgYmFzZVNpdGVVc2FnZU1zID0gdXNhZ2VbbWF0Y2hlZF07XG4gICAgICAgICAgICAgIHBlcnNpc3RCYXNlVXNhZ2UoYmFzZVNpdGVVc2FnZU1zKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgLy8gQWN0aXZlIHNoYXJlZCBkb21haW4gc3BhbiBvbmx5IOKAlCBuZXZlciBzdWJzdGl0dXRlIHBlci10YWIgdmlzaXQgc3RhcnRcbiAgICAgICAgICAgIGNvbnN0IGFjdGl2ZURvbWFpblNwYW4gPSBkYXRhLmRvbWFpblNwYW5zPy5bbWF0Y2hlZF07XG4gICAgICAgICAgICBpZiAoYWN0aXZlRG9tYWluU3Bhbj8uc3RhcnRlZEF0ICYmIChzU3RhcnQgPT09IDAgfHwgYWN0aXZlRG9tYWluU3Bhbi5zdGFydGVkQXQgPj0gc1N0YXJ0KSkge1xuICAgICAgICAgICAgICBkb21haW5TcGFuU3RhcnRlZEF0ID0gYWN0aXZlRG9tYWluU3Bhbi5zdGFydGVkQXQ7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICBkb21haW5TcGFuU3RhcnRlZEF0ID0gMDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHBlcnNpc3REb21haW5TcGFuU3RhcnQoZG9tYWluU3BhblN0YXJ0ZWRBdCk7XG5cbiAgICAgICAgICAgIGNvbnN0IGNoZWNrTm93ID0gRGF0ZS5ub3coKTtcbiAgICAgICAgICAgIGNvbnN0IGxpdmVTcGFuU3RhcnQgPSBkb21haW5TcGFuU3RhcnRlZEF0ID4gMCA/IGRvbWFpblNwYW5TdGFydGVkQXQgOiB2aXNpdFN0YXJ0ZWRBdDtcbiAgICAgICAgICAgIGNvbnN0IGVmZmVjdGl2ZVNwYW5TdGFydCA9XG4gICAgICAgICAgICAgIGxpdmVTcGFuU3RhcnQgPiAwICYmIHNTdGFydCA+IDAgPyBNYXRoLm1heChsaXZlU3BhblN0YXJ0LCBzU3RhcnQpIDogbGl2ZVNwYW5TdGFydDtcbiAgICAgICAgICAgIGNvbnN0IGxpdmVBbmNob3IgPVxuICAgICAgICAgICAgICBkb21haW5TcGFuU3RhcnRlZEF0ID09PSAwICYmIGJhc2VTaXRlVXNhZ2VNcyA+IDBcbiAgICAgICAgICAgICAgICA/IE1hdGgubWF4KGVmZmVjdGl2ZVNwYW5TdGFydCwgcGFnZUxvYWRUaW1lKVxuICAgICAgICAgICAgICAgIDogZWZmZWN0aXZlU3BhblN0YXJ0O1xuICAgICAgICAgICAgY29uc3QgbGl2ZU1zID0gbGl2ZUFuY2hvciA+IDAgPyBNYXRoLm1heCgwLCBjaGVja05vdyAtIGxpdmVBbmNob3IpIDogMDtcbiAgICAgICAgICAgIGNvbnN0IHRvdGFsRHVyYXRpb25NcyA9IGJhc2VTaXRlVXNhZ2VNcyArIGxpdmVNcztcbiAgICAgICAgICAgIHVzYWdlU25hcHNob3RTZWMgPSBNYXRoLmZsb29yKHRvdGFsRHVyYXRpb25NcyAvIDEwMDApO1xuICAgICAgICAgICAgdXNhZ2VTbmFwc2hvdEF0ID0gY2hlY2tOb3cgLSAodG90YWxEdXJhdGlvbk1zICUgMTAwMCk7XG5cbiAgICAgICAgICAgIC8vIFRhYiB2aXNpdCBzdGFydCAocGVyLXRhYiBsaWZldGltZSlcbiAgICAgICAgICAgIGlmIChpc0NvbnRpbnVpbmdWaXNpdCkge1xuICAgICAgICAgICAgICBjb25zdCBzdG9yZWRTdGFydCA9IGdldFN0b3JlZFZpc2l0U3RhcnQoKTtcbiAgICAgICAgICAgICAgaWYgKHN0b3JlZFN0YXJ0ID4gMCAmJiAoc1N0YXJ0ID09PSAwIHx8IHN0b3JlZFN0YXJ0ID49IHNTdGFydCkpIHtcbiAgICAgICAgICAgICAgICB2aXNpdFN0YXJ0ZWRBdCA9IHN0b3JlZFN0YXJ0O1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9IGVsc2UgaWYgKCF2aXNpdFN0YXJ0ZWRBdCB8fCB2aXNpdFN0YXJ0ZWRBdCA9PT0gMCkge1xuICAgICAgICAgICAgICB2aXNpdFN0YXJ0ZWRBdCA9IHBhZ2VMb2FkVGltZTtcbiAgICAgICAgICAgICAgcGVyc2lzdFZpc2l0U3RhcnQodmlzaXRTdGFydGVkQXQpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBpZiAoZGF0YS5tb2RlID09PSBcImJsb2NrXCIpIHtcbiAgICAgICAgICAgICAgd2FybmluZy50ZXh0Q29udGVudCA9IFwiRm9jdXMgU3ByaW50IEFjdGl2ZSAoQmxvY2sgTW9kZSlcIjtcbiAgICAgICAgICAgICAgZGlzdEJhci5zdHlsZS5iYWNrZ3JvdW5kQ29sb3IgPSBcIiNlMTFkNDhcIjtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgIHdhcm5pbmcudGV4dENvbnRlbnQgPSBcIllvdSd2ZSBiZWVuIGRpc3RyYWN0ZWRcIjtcbiAgICAgICAgICAgICAgZGlzdEJhci5zdHlsZS5iYWNrZ3JvdW5kQ29sb3IgPSBcIiNiZTEyM2NcIjtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgZW5zdXJlRG9tSW5qZWN0ZWQoKTtcbiAgICAgICAgICAgIGRpc3RCYXIuc3R5bGUuZGlzcGxheSA9IFwiZmxleFwiO1xuICAgICAgICAgICAgdXBkYXRlRGlzcGxheVRpbWVycygpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAvLyBJc3N1ZSA0IEZpeDogSWYgc2l0ZSBpcyBub3QgaW4gcmVzdHJpY3RlZCBsaXN0LCBpbW1lZGlhdGVseSBoaWRlIGRpc3RyYWN0aW9uIGJhclxuICAgICAgICAgICAgaXNSZXN0cmljdGVkUGFnZSA9IGZhbHNlO1xuICAgICAgICAgICAgZGlzdEJhci5zdHlsZS5kaXNwbGF5ID0gXCJub25lXCI7XG4gICAgICAgICAgfVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGlzUmVzdHJpY3RlZFBhZ2UgPSBmYWxzZTtcbiAgICAgICAgICBkaXN0QmFyLnN0eWxlLmRpc3BsYXkgPSBcIm5vbmVcIjtcbiAgICAgICAgfVxuICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgIGNvbnNvbGUud2FybihcIkltbWVkaWF0ZSByZXN0cmljdGVkIGNoZWNrOlwiLCBlcnIpO1xuICAgICAgfVxuICAgIH07XG5cbiAgICAvLyA0LiBSRUFMLVRJTUUgTE9DQUwgVElNRVIgRElTUExBWVxuICAgIC8vIFJpZ2h0OiBzaGFyZWQgZG9tYWluIHVzYWdlIChjYW5vbmljYWwgc25hcHNob3QgKyBsaXZlIHRpY2sgd2hpbGUgc3BhbiBvcGVuKVxuICAgIC8vIE1pZGRsZTogcGVyLXRhYiB2aXNpdCBsaWZldGltZSBmcm9tIHZpc2l0U3RhcnRlZEF0IChmb3JlZ3JvdW5kIG9yIGJhY2tncm91bmQpXG4gICAgY29uc3QgdXBkYXRlRGlzcGxheVRpbWVycyA9ICgpID0+IHtcbiAgICAgIGNvbnN0IG5vdyA9IERhdGUubm93KCk7XG5cbiAgICAgIC8vIFNlc3Npb24gVGltZXIgKEJvdHRvbS1SaWdodCBQYW5lbCAmIEZ1bGxzY3JlZW4gQmxvY2tlZCBQYWdlKVxuICAgICAgaWYgKHNlc3Npb25TdGFydGVkQXQgPiAwKSB7XG4gICAgICAgIGNvbnN0IHNlc3Npb25FbGFwc2VkU2VjID0gTWF0aC5tYXgoMCwgTWF0aC5mbG9vcigobm93IC0gc2Vzc2lvblN0YXJ0ZWRBdCkgLyAxMDAwKSk7XG4gICAgICAgIGlmIChzZXNzaW9uRWxhcHNlZFNlYyAhPT0gbGFzdFNlc3Npb25TZWMpIHtcbiAgICAgICAgICBsYXN0U2Vzc2lvblNlYyA9IHNlc3Npb25FbGFwc2VkU2VjO1xuICAgICAgICAgIHAxLnRleHRDb250ZW50ID0gZm9ybWF0U2Vjb25kcyhzZXNzaW9uRWxhcHNlZFNlYyk7XG5cbiAgICAgICAgICBpZiAocGFnZUJsb2NrZWQpIHtcbiAgICAgICAgICAgIGNvbnN0IGJsb2NrVGltZXJFbCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwibnVkZ2UtYmxvY2tlZC10aW1lclwiKTtcbiAgICAgICAgICAgIGlmIChibG9ja1RpbWVyRWwpIHtcbiAgICAgICAgICAgICAgYmxvY2tUaW1lckVsLnRleHRDb250ZW50ID0gZm9ybWF0U2Vjb25kcyhzZXNzaW9uRWxhcHNlZFNlYyk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICByZW5kZXJCbG9ja2VkUGFnZShob3N0bmFtZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIC8vIERpc3RyYWN0aW9uIEJhciBUaW1lcnNcbiAgICAgIGlmIChpc1Jlc3RyaWN0ZWRQYWdlICYmIHZpc2l0U3RhcnRlZEF0ID4gMCkge1xuICAgICAgICAvLyBSaWdodCB0aW1lcjogc2hhcmVkIGRvbWFpbiB1c2FnZSBhY3Jvc3Mgc2Vzc2lvbiAoYmFzZSBhY2N1bXVsYXRlZCBtcyArIGxpdmUgc3BhbiBtcylcbiAgICAgICAgY29uc3QgbGl2ZVNwYW5TdGFydCA9IGRvbWFpblNwYW5TdGFydGVkQXQgPiAwID8gZG9tYWluU3BhblN0YXJ0ZWRBdCA6IHZpc2l0U3RhcnRlZEF0O1xuICAgICAgICBjb25zdCBlZmZlY3RpdmVTcGFuU3RhcnQgPVxuICAgICAgICAgIHNlc3Npb25TdGFydGVkQXQgPiAwXG4gICAgICAgICAgICA/IE1hdGgubWF4KGxpdmVTcGFuU3RhcnQsIHNlc3Npb25TdGFydGVkQXQpXG4gICAgICAgICAgICA6IGxpdmVTcGFuU3RhcnQ7XG4gICAgICAgIGNvbnN0IGxpdmVBbmNob3IgPVxuICAgICAgICAgIGRvbWFpblNwYW5TdGFydGVkQXQgPT09IDAgJiYgYmFzZVNpdGVVc2FnZU1zID4gMFxuICAgICAgICAgICAgPyBNYXRoLm1heChlZmZlY3RpdmVTcGFuU3RhcnQsIHBhZ2VMb2FkVGltZSlcbiAgICAgICAgICAgIDogZWZmZWN0aXZlU3BhblN0YXJ0O1xuICAgICAgICBjb25zdCBsaXZlTXMgPSBsaXZlQW5jaG9yID4gMCA/IE1hdGgubWF4KDAsIG5vdyAtIGxpdmVBbmNob3IpIDogMDtcbiAgICAgICAgbGV0IHRvdGFsRHVyYXRpb25NcyA9IGJhc2VTaXRlVXNhZ2VNcyArIGxpdmVNcztcbiAgICAgICAgaWYgKHNlc3Npb25TdGFydGVkQXQgPiAwKSB7XG4gICAgICAgICAgY29uc3QgbWF4U2Vzc2lvbk1zID0gTWF0aC5tYXgoMCwgbm93IC0gc2Vzc2lvblN0YXJ0ZWRBdCk7XG4gICAgICAgICAgaWYgKHRvdGFsRHVyYXRpb25NcyA+IG1heFNlc3Npb25Ncykge1xuICAgICAgICAgICAgdG90YWxEdXJhdGlvbk1zID0gbWF4U2Vzc2lvbk1zO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBsZXQgdG90YWxTaXRlU2VjID0gTWF0aC5mbG9vcih0b3RhbER1cmF0aW9uTXMgLyAxMDAwKTtcblxuICAgICAgICAvLyBNb25vdG9uaWMgZGlzcGxheSBndWFyZDogdG90YWwgc2Vzc2lvbiBkb21haW4gdXNhZ2UgbmV2ZXIgZGVjcmVhc2VzIGR1cmluZyBhY3RpdmUgc2Vzc2lvblxuICAgICAgICBpZiAobGFzdFRvdGFsU2VjID49IDAgJiYgdG90YWxTaXRlU2VjIDwgbGFzdFRvdGFsU2VjKSB7XG4gICAgICAgICAgdG90YWxTaXRlU2VjID0gbGFzdFRvdGFsU2VjO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gTWlkZGxlIHRpbWVyOiBpbmRlcGVuZGVudCBwZXItdGFiIHZpc2l0IGxpZmV0aW1lIChub3QgY2FwcGVkIGJ5IGRvbWFpbiB0b3RhbClcbiAgICAgICAgY29uc3QgZWZmZWN0aXZlVmlzaXRTdGFydCA9XG4gICAgICAgICAgc2Vzc2lvblN0YXJ0ZWRBdCA+IDBcbiAgICAgICAgICAgID8gTWF0aC5tYXgodmlzaXRTdGFydGVkQXQsIHNlc3Npb25TdGFydGVkQXQpXG4gICAgICAgICAgICA6IHZpc2l0U3RhcnRlZEF0O1xuICAgICAgICBsZXQgY3VycmVudFZpc2l0U2VjID0gTWF0aC5tYXgoXG4gICAgICAgICAgMCxcbiAgICAgICAgICBNYXRoLmZsb29yKChub3cgLSBlZmZlY3RpdmVWaXNpdFN0YXJ0KSAvIDEwMDApLFxuICAgICAgICApO1xuXG4gICAgICAgIC8vIE1vbm90b25pYyBkaXNwbGF5IGd1YXJkOiB2aXNpdCBzZWNvbmRzIG5ldmVyIHN0ZXAgYmFja3dhcmRcbiAgICAgICAgaWYgKGxhc3RWaXNpdFNlYyA+PSAwICYmIGN1cnJlbnRWaXNpdFNlYyA8IGxhc3RWaXNpdFNlYykge1xuICAgICAgICAgIGN1cnJlbnRWaXNpdFNlYyA9IGxhc3RWaXNpdFNlYztcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChjdXJyZW50VmlzaXRTZWMgIT09IGxhc3RWaXNpdFNlYykge1xuICAgICAgICAgIGxhc3RWaXNpdFNlYyA9IGN1cnJlbnRWaXNpdFNlYztcbiAgICAgICAgICB0aW1lci50ZXh0Q29udGVudCA9IGZvcm1hdFNlY29uZHMoY3VycmVudFZpc2l0U2VjKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmICh0b3RhbFNpdGVTZWMgIT09IGxhc3RUb3RhbFNlYykge1xuICAgICAgICAgIGxhc3RUb3RhbFNlYyA9IHRvdGFsU2l0ZVNlYztcbiAgICAgICAgICB0b3RhbFRpbWVyLnRleHRDb250ZW50ID0gYChUaGlzIHNlc3Npb246ICR7Zm9ybWF0U2Vjb25kcyh0b3RhbFNpdGVTZWMpfSlgO1xuICAgICAgICB9XG5cbiAgICAgICAgdXBkYXRlTGFzdFRpY2soKTtcbiAgICAgIH1cbiAgICB9O1xuXG4gICAgLy8gNS4gQVRPTUlDIFNZTkMgV0lUSCBCQUNLR1JPVU5EIFNDUklQVFxuICAgIGNvbnN0IHN5bmNTaXRlID0gYXN5bmMgKCkgPT4ge1xuICAgICAgaWYgKGlzU3luY2luZykgcmV0dXJuO1xuICAgICAgaXNTeW5jaW5nID0gdHJ1ZTtcbiAgICAgIGNvbnN0IHN5bmNTZXEgPSArK2xhdGVzdFN5bmNTZXE7XG5cbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IGlzVmlzaWJsZSA9IGRvY3VtZW50LnZpc2liaWxpdHlTdGF0ZSA9PT0gXCJ2aXNpYmxlXCI7XG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYnJvd3Nlci5ydW50aW1lLnNlbmRNZXNzYWdlKHtcbiAgICAgICAgICBtZXNzYWdlOiBcImNoZWNrX3NpdGVcIixcbiAgICAgICAgICBob3N0bmFtZSxcbiAgICAgICAgICB0YWJJbnN0YW5jZUlkLFxuICAgICAgICAgIHRhYlZpc2l0U3RhcnRlZEF0OiB2aXNpdFN0YXJ0ZWRBdCxcbiAgICAgICAgICBpc1Zpc2libGUsXG4gICAgICAgIH0pO1xuXG4gICAgICAgIC8vIElmIGJhY2tncm91bmQgd29ya2VyIGlzIHRlbXBvcmFyaWx5IHdha2luZyB1cCwgb3IgcmVzcG9uc2UgaXMgc3RhbGUsIGRvIG5vdCB3aXBlIHN0YXRlXG4gICAgICAgIGlmICghcmVzcG9uc2UgfHwgc3luY1NlcSAhPT0gbGF0ZXN0U3luY1NlcSkge1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmICghcmVzcG9uc2UuaXNBY3RpdmUpIHtcbiAgICAgICAgICBwZXJzaXN0QmxvY2tlZFN0YXRlKGZhbHNlKTtcbiAgICAgICAgICBpZiAocGFnZUJsb2NrZWQpIHtcbiAgICAgICAgICAgIHBhZ2VCbG9ja2VkID0gZmFsc2U7XG4gICAgICAgICAgICByZW1vdmVCbG9ja2VkUGFnZSgpO1xuICAgICAgICAgICAgd2luZG93LmxvY2F0aW9uLnJlbG9hZCgpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIHBlcnNpc3RWaXNpdFN0YXJ0KDApO1xuICAgICAgICAgIHBlcnNpc3REb21haW5TcGFuU3RhcnQoMCk7XG4gICAgICAgICAgcGVyc2lzdEJhc2VVc2FnZSgwKTtcbiAgICAgICAgICBwZXJzaXN0VGFiQWN0aXZlTXMoMCk7XG4gICAgICAgICAgaXNSZXN0cmljdGVkUGFnZSA9IGZhbHNlO1xuICAgICAgICAgIHZpc2l0U3RhcnRlZEF0ID0gMDtcbiAgICAgICAgICBkb21haW5TcGFuU3RhcnRlZEF0ID0gMDtcbiAgICAgICAgICBiYXNlU2l0ZVVzYWdlTXMgPSAwO1xuICAgICAgICAgIHVzYWdlU25hcHNob3RTZWMgPSAwO1xuICAgICAgICAgIHVzYWdlU25hcHNob3RBdCA9IDA7XG4gICAgICAgICAgc2Vzc2lvblN0YXJ0ZWRBdCA9IDA7XG4gICAgICAgICAgbGFzdFZpc2l0U2VjID0gLTE7XG4gICAgICAgICAgbGFzdFRvdGFsU2VjID0gLTE7XG4gICAgICAgICAgbGFzdFNlc3Npb25TZWMgPSAtMTtcblxuICAgICAgICAgIGRpc3RCYXIuc3R5bGUuZGlzcGxheSA9IFwibm9uZVwiO1xuICAgICAgICAgIHAxLnRleHRDb250ZW50ID0gXCIwMDowMDowMFwiO1xuICAgICAgICAgIHAyLnRleHRDb250ZW50ID0gXCJJZGxlXCI7XG4gICAgICAgICAgcDIuc3R5bGUuYmFja2dyb3VuZCA9IFwicmdiYSgyNTUsIDI1NSwgMjU1LCAwLjA4KVwiO1xuICAgICAgICAgIHAyLnN0eWxlLmNvbG9yID0gXCIjYTFhMWFhXCI7XG4gICAgICAgICAgcDIuc3R5bGUuYm9yZGVyID0gXCIxcHggc29saWQgcmdiYSgyNTUsIDI1NSwgMjU1LCAwLjA4KVwiO1xuICAgICAgICAgIHN0YXR1c0RvdC5zdHlsZS5iYWNrZ3JvdW5kID0gXCIjNzE3MTdhXCI7XG4gICAgICAgICAgc3RhdHVzRG90LnN0eWxlLmJveFNoYWRvdyA9IFwibm9uZVwiO1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIHNlc3Npb25TdGFydGVkQXQgPSByZXNwb25zZS5zZXNzaW9uU3RhcnRlZEF0ID8/IDA7XG5cbiAgICAgICAgLy8gQ2hlY2sgaWYgdGFiSWQgcmV0dXJuZWQgcmV2ZWFscyB0aGlzIGlzIGEgZHVwbGljYXRlZCB0YWJcbiAgICAgICAgaWYgKHJlc3BvbnNlLnRhYklkICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgY29uc3Qgc3RvcmVkVGFiSWQgPSBzZXNzaW9uU3RvcmFnZS5nZXRJdGVtKHRhYklkU3RvcmFnZUtleSk7XG4gICAgICAgICAgICBpZiAoc3RvcmVkVGFiSWQgJiYgc3RvcmVkVGFiSWQgIT09IFN0cmluZyhyZXNwb25zZS50YWJJZCkpIHtcbiAgICAgICAgICAgICAgLy8gRGlmZmVyZW50IHRhYiBJRCBtZWFucyB0aGlzIHRhYiB3YXMgZHVwbGljYXRlZCBmcm9tIGFub3RoZXIgdGFiIVxuICAgICAgICAgICAgICB0YWJJbnN0YW5jZUlkID0gZ2VuZXJhdGVVbmlxdWVJbnN0YW5jZUlkKCk7XG4gICAgICAgICAgICAgIHNlc3Npb25TdG9yYWdlLnNldEl0ZW0oaW5zdGFuY2VTdG9yYWdlS2V5LCB0YWJJbnN0YW5jZUlkKTtcbiAgICAgICAgICAgICAgcGVyc2lzdFZpc2l0U3RhcnQocmVzcG9uc2UudmlzaXRTdGFydGVkQXQgfHwgcGFnZUxvYWRUaW1lKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHNlc3Npb25TdG9yYWdlLnNldEl0ZW0odGFiSWRTdG9yYWdlS2V5LCBTdHJpbmcocmVzcG9uc2UudGFiSWQpKTtcbiAgICAgICAgICB9IGNhdGNoIHt9XG4gICAgICAgIH1cblxuICAgICAgICAvLyBBY3RpdmUgc3RhdGUgYmFkZ2Ugc3R5bGluZ1xuICAgICAgICBzdGF0dXNEb3Quc3R5bGUuYmFja2dyb3VuZCA9IFwiIzIyYzU1ZVwiO1xuICAgICAgICBzdGF0dXNEb3Quc3R5bGUuYm94U2hhZG93ID0gXCIwIDAgOHB4ICMyMmM1NWVcIjtcblxuICAgICAgICBjb25zdCBtb2RlU3RyID0gcmVzcG9uc2UubW9kZSB8fCBcIlwiO1xuICAgICAgICBwMi50ZXh0Q29udGVudCA9IG1vZGVTdHIgPyBtb2RlU3RyLmNoYXJBdCgwKS50b1VwcGVyQ2FzZSgpICsgbW9kZVN0ci5zbGljZSgxKSA6IFwiQWN0aXZlXCI7XG4gICAgICAgIGlmIChtb2RlU3RyID09PSBcInJlc3RyaWN0XCIpIHtcbiAgICAgICAgICBwMi5zdHlsZS5iYWNrZ3JvdW5kID0gXCJyZ2JhKDE2OCwgODUsIDI0NywgMC4xNSlcIjtcbiAgICAgICAgICBwMi5zdHlsZS5jb2xvciA9IFwiI2MwODRmY1wiO1xuICAgICAgICAgIHAyLnN0eWxlLmJvcmRlciA9IFwiMXB4IHNvbGlkIHJnYmEoMTY4LCA4NSwgMjQ3LCAwLjMpXCI7XG4gICAgICAgIH0gZWxzZSBpZiAobW9kZVN0ciA9PT0gXCJibG9ja1wiKSB7XG4gICAgICAgICAgcDIuc3R5bGUuYmFja2dyb3VuZCA9IFwicmdiYSgyNDQsIDYzLCA5NCwgMC4xNSlcIjtcbiAgICAgICAgICBwMi5zdHlsZS5jb2xvciA9IFwiI2ZiNzE4NVwiO1xuICAgICAgICAgIHAyLnN0eWxlLmJvcmRlciA9IFwiMXB4IHNvbGlkIHJnYmEoMjQ0LCA2MywgOTQsIDAuMylcIjtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIEJsb2NrIE1vZGVcbiAgICAgICAgaWYgKHJlc3BvbnNlLmlzQmxvY2tlZCkge1xuICAgICAgICAgIHBhZ2VCbG9ja2VkID0gdHJ1ZTtcbiAgICAgICAgICBpc1Jlc3RyaWN0ZWRQYWdlID0gZmFsc2U7XG4gICAgICAgICAgaWYgKHJlc3BvbnNlLnNlc3Npb25TdGFydGVkQXQpIHtcbiAgICAgICAgICAgIHNlc3Npb25TdGFydGVkQXQgPSByZXNwb25zZS5zZXNzaW9uU3RhcnRlZEF0O1xuICAgICAgICAgIH1cbiAgICAgICAgICBkaXN0QmFyLnN0eWxlLmRpc3BsYXkgPSBcIm5vbmVcIjtcbiAgICAgICAgICB3aWRnZXRDb250YWluZXIuc3R5bGUuZGlzcGxheSA9IFwibm9uZVwiO1xuICAgICAgICAgIHJlbmRlckJsb2NrZWRQYWdlKGhvc3RuYW1lKTtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH0gZWxzZSBpZiAocGFnZUJsb2NrZWQgJiYgKCFyZXNwb25zZS5pc0FjdGl2ZSB8fCByZXNwb25zZS5tb2RlICE9PSBcImJsb2NrXCIpKSB7XG4gICAgICAgICAgcGFnZUJsb2NrZWQgPSBmYWxzZTtcbiAgICAgICAgICByZW1vdmVCbG9ja2VkUGFnZSgpO1xuICAgICAgICAgIHdpbmRvdy5sb2NhdGlvbi5yZWxvYWQoKTtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH0gZWxzZSBpZiAocGFnZUJsb2NrZWQpIHtcbiAgICAgICAgICAvLyBLZWVwIGJsb2NrZWQgcGFnZSBmb3JjZWQgYWN0aXZlXG4gICAgICAgICAgcmVuZGVyQmxvY2tlZFBhZ2UoaG9zdG5hbWUpO1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIFJlc3RyaWN0IE1vZGUgJiBNb25pdG9yZWQgU2l0ZXMgaW4gQmxvY2sgTW9kZVxuICAgICAgICBpZiAocmVzcG9uc2UuaXNSZXN0cmljdGVkKSB7XG4gICAgICAgICAgaXNSZXN0cmljdGVkUGFnZSA9IHRydWU7XG5cbiAgICAgICAgICBjb25zdCBzU3RhcnQgPSByZXNwb25zZS5zZXNzaW9uU3RhcnRlZEF0ID8/IHNlc3Npb25TdGFydGVkQXQ7XG4gICAgICAgICAgc2Vzc2lvblN0YXJ0ZWRBdCA9IHNTdGFydDtcblxuICAgICAgICAgIC8vIENhbm9uaWNhbCB0YWIgdmlzaXQgc3RhcnQgZnJvbSBiYWNrZ3JvdW5kIOKAlCBhZG9wdCBpZiB1bmluaXRpYWxpemVkIG9yIGVhcmxpZXIgKG5ldmVyIHNoaWZ0IGludG8gZnV0dXJlKVxuICAgICAgICAgIGlmICh0eXBlb2YgcmVzcG9uc2UudmlzaXRTdGFydGVkQXQgPT09IFwibnVtYmVyXCIgJiYgcmVzcG9uc2UudmlzaXRTdGFydGVkQXQgPiAwKSB7XG4gICAgICAgICAgICBpZiAodmlzaXRTdGFydGVkQXQgPT09IDAgfHwgcmVzcG9uc2UudmlzaXRTdGFydGVkQXQgPD0gdmlzaXRTdGFydGVkQXQpIHtcbiAgICAgICAgICAgICAgdmlzaXRTdGFydGVkQXQgPSByZXNwb25zZS52aXNpdFN0YXJ0ZWRBdDtcbiAgICAgICAgICAgICAgcGVyc2lzdFZpc2l0U3RhcnQodmlzaXRTdGFydGVkQXQpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cblxuICAgICAgICAgIC8vIFNoYXJlZCBkb21haW4gc3BhbiBzdGFydCDigJQgMCBtZWFucyBubyBsaXZlIHNwYW4gKG5ldmVyIHVzZSB2aXNpdFN0YXJ0ZWRBdClcbiAgICAgICAgICBpZiAodHlwZW9mIHJlc3BvbnNlLmRvbWFpblNwYW5TdGFydGVkQXQgPT09IFwibnVtYmVyXCIgJiYgcmVzcG9uc2UuZG9tYWluU3BhblN0YXJ0ZWRBdCA+IDApIHtcbiAgICAgICAgICAgIGRvbWFpblNwYW5TdGFydGVkQXQgPSByZXNwb25zZS5kb21haW5TcGFuU3RhcnRlZEF0O1xuICAgICAgICAgIH0gZWxzZSBpZiAodHlwZW9mIHJlc3BvbnNlLmRvbWFpblN0YXJ0ZWRBdCA9PT0gXCJudW1iZXJcIiAmJiByZXNwb25zZS5kb21haW5TdGFydGVkQXQgPiAwKSB7XG4gICAgICAgICAgICBkb21haW5TcGFuU3RhcnRlZEF0ID0gcmVzcG9uc2UuZG9tYWluU3RhcnRlZEF0O1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBkb21haW5TcGFuU3RhcnRlZEF0ID0gMDtcbiAgICAgICAgICB9XG4gICAgICAgICAgcGVyc2lzdERvbWFpblNwYW5TdGFydChkb21haW5TcGFuU3RhcnRlZEF0KTtcblxuICAgICAgICAgIC8vIENhbm9uaWNhbCBiYXNlIHNpdGUgdXNhZ2UgZnJvbSBiYWNrZ3JvdW5kIChjb21wbGV0ZWQgaW50ZXJ2YWxzIG9ubHkpXG4gICAgICAgICAgY29uc3QgcmF3QmFzZVVzYWdlID1cbiAgICAgICAgICAgIHR5cGVvZiByZXNwb25zZS5iYXNlU2l0ZVVzYWdlTXMgPT09IFwibnVtYmVyXCJcbiAgICAgICAgICAgICAgPyByZXNwb25zZS5iYXNlU2l0ZVVzYWdlTXNcbiAgICAgICAgICAgICAgOiAodHlwZW9mIHJlc3BvbnNlLmJhc2VTaXRlVXNhZ2UgPT09IFwibnVtYmVyXCIgPyByZXNwb25zZS5iYXNlU2l0ZVVzYWdlIDogMCk7XG4gICAgICAgICAgYmFzZVNpdGVVc2FnZU1zID0gcmF3QmFzZVVzYWdlO1xuICAgICAgICAgIHBlcnNpc3RCYXNlVXNhZ2UoYmFzZVNpdGVVc2FnZU1zKTtcblxuICAgICAgICAgIC8vIFByZWZlciBiYWNrZ3JvdW5kIHRvdGFsIHNuYXBzaG90IChhbHJlYWR5ID0gYmFzZSArIGxpdmUgc3BhbiBhdCByZXNwb25zZSB0aW1lKVxuICAgICAgICAgIGNvbnN0IHNuYXBzaG90QXQgPVxuICAgICAgICAgICAgdHlwZW9mIHJlc3BvbnNlLnVzYWdlU25hcHNob3RBdCA9PT0gXCJudW1iZXJcIiAmJiByZXNwb25zZS51c2FnZVNuYXBzaG90QXQgPiAwXG4gICAgICAgICAgICAgID8gcmVzcG9uc2UudXNhZ2VTbmFwc2hvdEF0XG4gICAgICAgICAgICAgIDogRGF0ZS5ub3coKTtcbiAgICAgICAgICBpZiAodHlwZW9mIHJlc3BvbnNlLnRvdGFsU2l0ZVVzYWdlU2VjID09PSBcIm51bWJlclwiICYmIHJlc3BvbnNlLnRvdGFsU2l0ZVVzYWdlU2VjID49IDApIHtcbiAgICAgICAgICAgIC8vIFJlY29uY2lsZSBzbmFwc2hvdCB3aXRob3V0IGxldHRpbmcgYSBzdGFsZSByZXNwb25zZSBvdmVyd3JpdGUgbmV3ZXIgdGltZXIgc3RhdGVcbiAgICAgICAgICAgIGlmIChzbmFwc2hvdEF0ID49IHVzYWdlU25hcHNob3RBdCkge1xuICAgICAgICAgICAgICB1c2FnZVNuYXBzaG90U2VjID0gcmVzcG9uc2UudG90YWxTaXRlVXNhZ2VTZWM7XG4gICAgICAgICAgICAgIHVzYWdlU25hcHNob3RBdCA9IHNuYXBzaG90QXQ7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGNvbnN0IGVmZmVjdGl2ZVNwYW5TdGFydCA9XG4gICAgICAgICAgICAgIGRvbWFpblNwYW5TdGFydGVkQXQgPiAwICYmIHNTdGFydCA+IDBcbiAgICAgICAgICAgICAgICA/IE1hdGgubWF4KGRvbWFpblNwYW5TdGFydGVkQXQsIHNTdGFydClcbiAgICAgICAgICAgICAgICA6IGRvbWFpblNwYW5TdGFydGVkQXQ7XG4gICAgICAgICAgICBjb25zdCBsaXZlTXMgPVxuICAgICAgICAgICAgICBlZmZlY3RpdmVTcGFuU3RhcnQgPiAwID8gTWF0aC5tYXgoMCwgc25hcHNob3RBdCAtIGVmZmVjdGl2ZVNwYW5TdGFydCkgOiAwO1xuICAgICAgICAgICAgY29uc3QgdG90YWxNcyA9IGJhc2VTaXRlVXNhZ2VNcyArIGxpdmVNcztcbiAgICAgICAgICAgIHVzYWdlU25hcHNob3RTZWMgPSBNYXRoLmZsb29yKHRvdGFsTXMgLyAxMDAwKTtcbiAgICAgICAgICAgIHVzYWdlU25hcHNob3RBdCA9IHNuYXBzaG90QXQgLSAodG90YWxNcyAlIDEwMDApO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIGlmIChyZXNwb25zZS5tb2RlID09PSBcImJsb2NrXCIpIHtcbiAgICAgICAgICAgIHdhcm5pbmcudGV4dENvbnRlbnQgPSBcIkZvY3VzIFNwcmludCBBY3RpdmUgKEJsb2NrIE1vZGUpXCI7XG4gICAgICAgICAgICBkaXN0QmFyLnN0eWxlLmJhY2tncm91bmRDb2xvciA9IFwiI2UxMWQ0OFwiO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB3YXJuaW5nLnRleHRDb250ZW50ID0gXCJZb3UndmUgYmVlbiBkaXN0cmFjdGVkXCI7XG4gICAgICAgICAgICBkaXN0QmFyLnN0eWxlLmJhY2tncm91bmRDb2xvciA9IFwiI2JlMTIzY1wiO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIGVuc3VyZURvbUluamVjdGVkKCk7XG4gICAgICAgICAgZGlzdEJhci5zdHlsZS5kaXNwbGF5ID0gXCJmbGV4XCI7XG4gICAgICAgICAgdXBkYXRlRGlzcGxheVRpbWVycygpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIC8vIFNpdGUgaXMgbm90IHJlc3RyaWN0ZWQg4oCUIHRlYXIgZG93biBkaXN0cmFjdGlvbiBiYXJcbiAgICAgICAgICBpc1Jlc3RyaWN0ZWRQYWdlID0gZmFsc2U7XG4gICAgICAgICAgdmlzaXRTdGFydGVkQXQgPSAwO1xuICAgICAgICAgIGRvbWFpblNwYW5TdGFydGVkQXQgPSAwO1xuICAgICAgICAgIGJhc2VTaXRlVXNhZ2VNcyA9IDA7XG4gICAgICAgICAgdXNhZ2VTbmFwc2hvdFNlYyA9IDA7XG4gICAgICAgICAgdXNhZ2VTbmFwc2hvdEF0ID0gMDtcbiAgICAgICAgICBwZXJzaXN0VmlzaXRTdGFydCgwKTtcbiAgICAgICAgICBwZXJzaXN0RG9tYWluU3BhblN0YXJ0KDApO1xuICAgICAgICAgIHBlcnNpc3RCYXNlVXNhZ2UoMCk7XG4gICAgICAgICAgcGVyc2lzdFRhYkFjdGl2ZU1zKDApO1xuICAgICAgICAgIGxhc3RWaXNpdFNlYyA9IC0xO1xuICAgICAgICAgIGxhc3RUb3RhbFNlYyA9IC0xO1xuICAgICAgICAgIGRpc3RCYXIuc3R5bGUuZGlzcGxheSA9IFwibm9uZVwiO1xuICAgICAgICAgIHVwZGF0ZURpc3BsYXlUaW1lcnMoKTtcbiAgICAgICAgfVxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihcIk51ZGdlIHN5bmMgZXJyb3I6XCIsIGVycm9yKTtcbiAgICAgIH0gZmluYWxseSB7XG4gICAgICAgIGlzU3luY2luZyA9IGZhbHNlO1xuICAgICAgfVxuICAgIH07XG5cbiAgICAvLyA2LiBJTklUSUFMSVpFIElNTUVESUFURUxZXG4gICAgdm9pZCBjaGVja0ltbWVkaWF0ZUJsb2NrKCk7XG4gICAgdm9pZCBjaGVja0ltbWVkaWF0ZVJlc3RyaWN0ZWQoKTtcbiAgICB2b2lkIHN5bmNTaXRlKCk7XG5cbiAgICAvLyA3LiBVTFRSQS1TTU9PVEggTE9DQUwgRElTUExBWSBUSUNLICgyNTBtcyBpbnRlcnZhbCBjYXRjaGVzIHNlY29uZCByb2xsLW92ZXJzIHdpdGggemVybyBkcmlmdClcbiAgICBzZXRJbnRlcnZhbCh1cGRhdGVEaXNwbGF5VGltZXJzLCAyNTApO1xuXG4gICAgLy8gOC4gUEVSSU9ESUMgQkFDS0dST1VORCBTWU5DIChFdmVyeSAzIHNlY29uZHMpXG4gICAgc2V0SW50ZXJ2YWwoKCkgPT4ge1xuICAgICAgdm9pZCBzeW5jU2l0ZSgpO1xuICAgIH0sIDMwMDApO1xuXG4gICAgLy8gOS4gVmlzaWJpbGl0eSBjaGFuZ2VzIG11c3Qgbm90IHBhdXNlL3Jlc2V0IGRvbWFpbiBvciB2aXNpdCBhY2NvdW50aW5nLlxuICAgIC8vIEtlZXAgZGlzcGxheWluZyBmcm9tIGN1cnJlbnQgYW5jaG9yczsgcmVmcmVzaCBoZWFydGJlYXQgd2l0aG91dCB3aXBpbmcgc3RhdGUuXG4gICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcihcInZpc2liaWxpdHljaGFuZ2VcIiwgKCkgPT4ge1xuICAgICAgdm9pZCBzeW5jU2l0ZSgpO1xuICAgIH0pO1xuXG4gICAgLy8gMTAuIFJFLVNZTkMgT04gU1BBIE5BVklHQVRJT04gJiBCRkNBQ0hFIFJFU1RPUkFUSU9OXG4gICAgY29uc3Qgb25Mb2NhdGlvbkNoYW5nZSA9ICgpID0+IHtcbiAgICAgIHZvaWQgc3luY1NpdGUoKTtcbiAgICB9O1xuXG4gICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJwb3BzdGF0ZVwiLCBvbkxvY2F0aW9uQ2hhbmdlKTtcblxuICAgIC8vIFJlLXN5bmMgYW5kIHJlc2V0IGxlYXZpbmcgZmxhZyB3aGVuIHBhZ2UgaXMgcmVzdG9yZWQgZnJvbSBiZmNhY2hlIChCYWNrL0ZvcndhcmQgYnV0dG9uKVxuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwicGFnZXNob3dcIiwgKGV2ZW50KSA9PiB7XG4gICAgICBoYXNOb3RpZmllZExlYXZpbmcgPSBmYWxzZTtcbiAgICAgIGlmIChldmVudC5wZXJzaXN0ZWQpIHtcbiAgICAgICAgdm9pZCBjaGVja0ltbWVkaWF0ZUJsb2NrKCk7XG4gICAgICAgIHZvaWQgY2hlY2tJbW1lZGlhdGVSZXN0cmljdGVkKCk7XG4gICAgICAgIHZvaWQgc3luY1NpdGUoKTtcbiAgICAgIH1cbiAgICB9KTtcblxuICAgIC8vIEludGVyY2VwdCBwdXNoU3RhdGUgJiByZXBsYWNlU3RhdGUgZm9yIGltbWVkaWF0ZSByZWFjdGlvbiB0byBpbi1wYWdlIFNQQSBuYXZpZ2F0aW9uc1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBvcmlnUHVzaCA9IGhpc3RvcnkucHVzaFN0YXRlO1xuICAgICAgaGlzdG9yeS5wdXNoU3RhdGUgPSBmdW5jdGlvbiAodGhpczogSGlzdG9yeSwgLi4uYXJnczogUGFyYW1ldGVyczxIaXN0b3J5W1wicHVzaFN0YXRlXCJdPikge1xuICAgICAgICBjb25zdCByZXQgPSBvcmlnUHVzaC5hcHBseSh0aGlzLCBhcmdzKTtcbiAgICAgICAgd2luZG93LmRpc3BhdGNoRXZlbnQobmV3IEV2ZW50KFwibnVkZ2VfbG9jYXRpb25fY2hhbmdlXCIpKTtcbiAgICAgICAgcmV0dXJuIHJldDtcbiAgICAgIH07XG4gICAgICBjb25zdCBvcmlnUmVwbGFjZSA9IGhpc3RvcnkucmVwbGFjZVN0YXRlO1xuICAgICAgaGlzdG9yeS5yZXBsYWNlU3RhdGUgPSBmdW5jdGlvbiAodGhpczogSGlzdG9yeSwgLi4uYXJnczogUGFyYW1ldGVyczxIaXN0b3J5W1wicmVwbGFjZVN0YXRlXCJdPikge1xuICAgICAgICBjb25zdCByZXQgPSBvcmlnUmVwbGFjZS5hcHBseSh0aGlzLCBhcmdzKTtcbiAgICAgICAgd2luZG93LmRpc3BhdGNoRXZlbnQobmV3IEV2ZW50KFwibnVkZ2VfbG9jYXRpb25fY2hhbmdlXCIpKTtcbiAgICAgICAgcmV0dXJuIHJldDtcbiAgICAgIH07XG4gICAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcIm51ZGdlX2xvY2F0aW9uX2NoYW5nZVwiLCBvbkxvY2F0aW9uQ2hhbmdlKTtcbiAgICB9IGNhdGNoIHt9XG5cbiAgICAvLyAxMGIuIE5PVElGWSBCQUNLR1JPVU5EIFNDUklQVCBXSEVOIFRBQiBDTE9TRVMgT1IgVU5MT0FEU1xuICAgIGxldCBoYXNOb3RpZmllZExlYXZpbmcgPSBmYWxzZTtcbiAgICBjb25zdCBub3RpZnlUYWJMZWF2aW5nID0gKCkgPT4ge1xuICAgICAgaWYgKCFpc1Jlc3RyaWN0ZWRQYWdlIHx8IGhhc05vdGlmaWVkTGVhdmluZykgcmV0dXJuO1xuICAgICAgaGFzTm90aWZpZWRMZWF2aW5nID0gdHJ1ZTtcbiAgICAgIHRyeSB7XG4gICAgICAgIGJyb3dzZXIucnVudGltZS5zZW5kTWVzc2FnZSh7XG4gICAgICAgICAgbWVzc2FnZTogXCJ0YWJfbGVhdmluZ1wiLFxuICAgICAgICAgIHRhYkluc3RhbmNlSWQsXG4gICAgICAgICAgaG9zdG5hbWUsXG4gICAgICAgIH0pO1xuICAgICAgfSBjYXRjaCB7fVxuICAgIH07XG5cbiAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcInBhZ2VoaWRlXCIsIG5vdGlmeVRhYkxlYXZpbmcpO1xuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwiYmVmb3JldW5sb2FkXCIsIG5vdGlmeVRhYkxlYXZpbmcpO1xuXG4gICAgLy8gMTEuIFJFQUNUIFRPIFNUT1JBR0UgQ0hBTkdFUyAoZS5nLiBTZXNzaW9uIHN0YXJ0IC8gc3RvcCBmcm9tIHBvcHVwKVxuICAgIGJyb3dzZXIuc3RvcmFnZS5vbkNoYW5nZWQuYWRkTGlzdGVuZXIoKGNoYW5nZXMsIGFyZWEpID0+IHtcbiAgICAgIGlmIChhcmVhICE9PSBcImxvY2FsXCIpIHJldHVybjtcblxuICAgICAgaWYgKFxuICAgICAgICBjaGFuZ2VzLmlzQWN0aXZlIHx8XG4gICAgICAgIGNoYW5nZXMubW9kZSB8fFxuICAgICAgICBjaGFuZ2VzLmJsb2NrZWRTaXRlcyB8fFxuICAgICAgICBjaGFuZ2VzLnJlc3RyaWN0ZWRTaXRlcyB8fFxuICAgICAgICBjaGFuZ2VzLnN0YXJ0ZWRBdCB8fFxuICAgICAgICBjaGFuZ2VzLmRvbWFpblNwYW5zIHx8XG4gICAgICAgIGNoYW5nZXMuc2Vzc2lvblNpdGVVc2FnZVxuICAgICAgKSB7XG4gICAgICAgIGlmIChcbiAgICAgICAgICBwYWdlQmxvY2tlZCAmJlxuICAgICAgICAgIChjaGFuZ2VzLmlzQWN0aXZlPy5uZXdWYWx1ZSA9PT0gZmFsc2UgfHxcbiAgICAgICAgICAgIGNoYW5nZXMubW9kZT8ubmV3VmFsdWUgIT09IFwiYmxvY2tcIilcbiAgICAgICAgKSB7XG4gICAgICAgICAgcGFnZUJsb2NrZWQgPSBmYWxzZTtcbiAgICAgICAgICByZW1vdmVCbG9ja2VkUGFnZSgpO1xuICAgICAgICAgIHdpbmRvdy5sb2NhdGlvbi5yZWxvYWQoKTtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICBpZiAoY2hhbmdlcy5zdGFydGVkQXQgJiYgdHlwZW9mIGNoYW5nZXMuc3RhcnRlZEF0Lm5ld1ZhbHVlID09PSBcIm51bWJlclwiKSB7XG4gICAgICAgICAgY29uc3QgbmV3U3RhcnQgPSBjaGFuZ2VzLnN0YXJ0ZWRBdC5uZXdWYWx1ZSA+IDAgPyBjaGFuZ2VzLnN0YXJ0ZWRBdC5uZXdWYWx1ZSA6IDA7XG4gICAgICAgICAgaWYgKG5ld1N0YXJ0ICE9PSBzZXNzaW9uU3RhcnRlZEF0KSB7XG4gICAgICAgICAgICBzZXNzaW9uU3RhcnRlZEF0ID0gbmV3U3RhcnQ7XG4gICAgICAgICAgICAvLyBDbGVhbiByZXNldCB3aGVuIGEgbmV3IGZvY3VzIHNlc3Npb24gc3RhcnRzXG4gICAgICAgICAgICBpZiAobmV3U3RhcnQgPiAwKSB7XG4gICAgICAgICAgICAgIGJhc2VTaXRlVXNhZ2VNcyA9IDA7XG4gICAgICAgICAgICAgIHBlcnNpc3RCYXNlVXNhZ2UoMCk7XG4gICAgICAgICAgICAgIHBlcnNpc3RUYWJBY3RpdmVNcygwKTtcbiAgICAgICAgICAgICAgdmlzaXRTdGFydGVkQXQgPSBwYWdlTG9hZFRpbWUgPj0gbmV3U3RhcnQgPyBwYWdlTG9hZFRpbWUgOiBuZXdTdGFydDtcbiAgICAgICAgICAgICAgcGVyc2lzdFZpc2l0U3RhcnQodmlzaXRTdGFydGVkQXQpO1xuICAgICAgICAgICAgICBkb21haW5TcGFuU3RhcnRlZEF0ID0gMDtcbiAgICAgICAgICAgICAgcGVyc2lzdERvbWFpblNwYW5TdGFydCgwKTtcbiAgICAgICAgICAgICAgdXNhZ2VTbmFwc2hvdFNlYyA9IDA7XG4gICAgICAgICAgICAgIHVzYWdlU25hcHNob3RBdCA9IDA7XG4gICAgICAgICAgICAgIGxhc3RWaXNpdFNlYyA9IC0xO1xuICAgICAgICAgICAgICBsYXN0VG90YWxTZWMgPSAtMTtcbiAgICAgICAgICAgICAgbGFzdFNlc3Npb25TZWMgPSAtMTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICAvLyBJZiByZXN0cmljdGVkU2l0ZXMgY2hhbmdlZCBhbmQgY3VycmVudCBzaXRlIGlzIG5vIGxvbmdlciByZXN0cmljdGVkLCB0ZWFyIGRvd24gaW1tZWRpYXRlbHlcbiAgICAgICAgaWYgKGNoYW5nZXMucmVzdHJpY3RlZFNpdGVzICYmIEFycmF5LmlzQXJyYXkoY2hhbmdlcy5yZXN0cmljdGVkU2l0ZXMubmV3VmFsdWUpKSB7XG4gICAgICAgICAgY29uc3QgbmV3U2l0ZXM6IHN0cmluZ1tdID0gY2hhbmdlcy5yZXN0cmljdGVkU2l0ZXMubmV3VmFsdWU7XG4gICAgICAgICAgaWYgKCFpc0hvc3RCbG9ja2VkKGhvc3RuYW1lLCBuZXdTaXRlcykpIHtcbiAgICAgICAgICAgIGlzUmVzdHJpY3RlZFBhZ2UgPSBmYWxzZTtcbiAgICAgICAgICAgIHZpc2l0U3RhcnRlZEF0ID0gMDtcbiAgICAgICAgICAgIGRvbWFpblNwYW5TdGFydGVkQXQgPSAwO1xuICAgICAgICAgICAgYmFzZVNpdGVVc2FnZU1zID0gMDtcbiAgICAgICAgICAgIHVzYWdlU25hcHNob3RTZWMgPSAwO1xuICAgICAgICAgICAgdXNhZ2VTbmFwc2hvdEF0ID0gMDtcbiAgICAgICAgICAgIHBlcnNpc3RWaXNpdFN0YXJ0KDApO1xuICAgICAgICAgICAgcGVyc2lzdERvbWFpblNwYW5TdGFydCgwKTtcbiAgICAgICAgICAgIHBlcnNpc3RCYXNlVXNhZ2UoMCk7XG4gICAgICAgICAgICBwZXJzaXN0VGFiQWN0aXZlTXMoMCk7XG4gICAgICAgICAgICBsYXN0VmlzaXRTZWMgPSAtMTtcbiAgICAgICAgICAgIGxhc3RUb3RhbFNlYyA9IC0xO1xuICAgICAgICAgICAgZGlzdEJhci5zdHlsZS5kaXNwbGF5ID0gXCJub25lXCI7XG4gICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgLy8gSW1tZWRpYXRlbHkgcmUtY2hlY2sgYmxvY2tlZCBhbmQgcmVzdHJpY3RlZCBzdGF0ZSBmcm9tIHN0b3JhZ2Ugb24gYW55IHNlc3Npb24gY2hhbmdlc1xuICAgICAgICB2b2lkIGNoZWNrSW1tZWRpYXRlQmxvY2soKTtcbiAgICAgICAgdm9pZCBjaGVja0ltbWVkaWF0ZVJlc3RyaWN0ZWQoKTtcblxuICAgICAgICAvLyBPbmx5IHJlc2V0IHZpc2l0IGNvdW50ZXJzIGlmIHRoZSBzZXNzaW9uIGFjdHVhbGx5IGVuZGVkXG4gICAgICAgIGlmIChjaGFuZ2VzLmlzQWN0aXZlPy5uZXdWYWx1ZSA9PT0gZmFsc2UpIHtcbiAgICAgICAgICBwZXJzaXN0VmlzaXRTdGFydCgwKTtcbiAgICAgICAgICBwZXJzaXN0RG9tYWluU3BhblN0YXJ0KDApO1xuICAgICAgICAgIHBlcnNpc3RCYXNlVXNhZ2UoMCk7XG4gICAgICAgICAgcGVyc2lzdFRhYkFjdGl2ZU1zKDApO1xuICAgICAgICAgIGlzUmVzdHJpY3RlZFBhZ2UgPSBmYWxzZTtcbiAgICAgICAgICB2aXNpdFN0YXJ0ZWRBdCA9IDA7XG4gICAgICAgICAgZG9tYWluU3BhblN0YXJ0ZWRBdCA9IDA7XG4gICAgICAgICAgYmFzZVNpdGVVc2FnZU1zID0gMDtcbiAgICAgICAgICB1c2FnZVNuYXBzaG90U2VjID0gMDtcbiAgICAgICAgICB1c2FnZVNuYXBzaG90QXQgPSAwO1xuICAgICAgICAgIHNlc3Npb25TdGFydGVkQXQgPSAwO1xuICAgICAgICAgIGxhc3RWaXNpdFNlYyA9IC0xO1xuICAgICAgICAgIGxhc3RUb3RhbFNlYyA9IC0xO1xuICAgICAgICAgIGxhc3RTZXNzaW9uU2VjID0gLTE7XG4gICAgICAgICAgZGlzdEJhci5zdHlsZS5kaXNwbGF5ID0gXCJub25lXCI7XG4gICAgICAgIH1cblxuICAgICAgICB2b2lkIHN5bmNTaXRlKCk7XG4gICAgICB9XG4gICAgfSk7XG4gIH0sXG59KTtcblxuIiwiLy8jcmVnaW9uIHNyYy91dGlscy9pbnRlcm5hbC9sb2dnZXIudHNcbmZ1bmN0aW9uIHByaW50KG1ldGhvZCwgLi4uYXJncykge1xuXHRpZiAoaW1wb3J0Lm1ldGEuZW52Lk1PREUgPT09IFwicHJvZHVjdGlvblwiKSByZXR1cm47XG5cdGlmICh0eXBlb2YgYXJnc1swXSA9PT0gXCJzdHJpbmdcIikgbWV0aG9kKGBbd3h0XSAke2FyZ3Muc2hpZnQoKX1gLCAuLi5hcmdzKTtcblx0ZWxzZSBtZXRob2QoXCJbd3h0XVwiLCAuLi5hcmdzKTtcbn1cbi8qKiBXcmFwcGVyIGFyb3VuZCBgY29uc29sZWAgd2l0aCBhIFwiW3d4dF1cIiBwcmVmaXggKi9cbmNvbnN0IGxvZ2dlciA9IHtcblx0ZGVidWc6ICguLi5hcmdzKSA9PiBwcmludChjb25zb2xlLmRlYnVnLCAuLi5hcmdzKSxcblx0bG9nOiAoLi4uYXJncykgPT4gcHJpbnQoY29uc29sZS5sb2csIC4uLmFyZ3MpLFxuXHR3YXJuOiAoLi4uYXJncykgPT4gcHJpbnQoY29uc29sZS53YXJuLCAuLi5hcmdzKSxcblx0ZXJyb3I6ICguLi5hcmdzKSA9PiBwcmludChjb25zb2xlLmVycm9yLCAuLi5hcmdzKVxufTtcbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgbG9nZ2VyIH07XG4iLCJpbXBvcnQgeyBicm93c2VyIH0gZnJvbSBcInd4dC9icm93c2VyXCI7XG4vLyNyZWdpb24gc3JjL3V0aWxzL2ludGVybmFsL2N1c3RvbS1ldmVudHMudHNcbnZhciBXeHRMb2NhdGlvbkNoYW5nZUV2ZW50ID0gY2xhc3MgV3h0TG9jYXRpb25DaGFuZ2VFdmVudCBleHRlbmRzIEV2ZW50IHtcblx0c3RhdGljIEVWRU5UX05BTUUgPSBnZXRVbmlxdWVFdmVudE5hbWUoXCJ3eHQ6bG9jYXRpb25jaGFuZ2VcIik7XG5cdGNvbnN0cnVjdG9yKG5ld1VybCwgb2xkVXJsKSB7XG5cdFx0c3VwZXIoV3h0TG9jYXRpb25DaGFuZ2VFdmVudC5FVkVOVF9OQU1FLCB7fSk7XG5cdFx0dGhpcy5uZXdVcmwgPSBuZXdVcmw7XG5cdFx0dGhpcy5vbGRVcmwgPSBvbGRVcmw7XG5cdH1cbn07XG4vKipcbiogUmV0dXJucyBhbiBldmVudCBuYW1lIHVuaXF1ZSB0byB0aGUgZXh0ZW5zaW9uIGFuZCBjb250ZW50IHNjcmlwdCB0aGF0J3NcbiogcnVubmluZy5cbiovXG5mdW5jdGlvbiBnZXRVbmlxdWVFdmVudE5hbWUoZXZlbnROYW1lKSB7XG5cdHJldHVybiBgJHticm93c2VyPy5ydW50aW1lPy5pZH06JHtpbXBvcnQubWV0YS5lbnYuRU5UUllQT0lOVH06JHtldmVudE5hbWV9YDtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgV3h0TG9jYXRpb25DaGFuZ2VFdmVudCwgZ2V0VW5pcXVlRXZlbnROYW1lIH07XG4iLCJpbXBvcnQgeyBXeHRMb2NhdGlvbkNoYW5nZUV2ZW50IH0gZnJvbSBcIi4vY3VzdG9tLWV2ZW50cy5tanNcIjtcbi8vI3JlZ2lvbiBzcmMvdXRpbHMvaW50ZXJuYWwvbG9jYXRpb24td2F0Y2hlci50c1xuY29uc3Qgc3VwcG9ydHNOYXZpZ2F0aW9uQXBpID0gdHlwZW9mIGdsb2JhbFRoaXMubmF2aWdhdGlvbj8uYWRkRXZlbnRMaXN0ZW5lciA9PT0gXCJmdW5jdGlvblwiO1xuLyoqXG4qIENyZWF0ZSBhIHV0aWwgdGhhdCB3YXRjaGVzIGZvciBVUkwgY2hhbmdlcywgZGlzcGF0Y2hpbmcgdGhlIGN1c3RvbSBldmVudCB3aGVuXG4qIGRldGVjdGVkLiBTdG9wcyB3YXRjaGluZyB3aGVuIGNvbnRlbnQgc2NyaXB0IGlzIGludmFsaWRhdGVkLiBVc2VzIE5hdmlnYXRpb25cbiogQVBJIHdoZW4gYXZhaWxhYmxlLCBvdGhlcndpc2UgZmFsbHMgYmFjayB0byBwb2xsaW5nLlxuKi9cbmZ1bmN0aW9uIGNyZWF0ZUxvY2F0aW9uV2F0Y2hlcihjdHgpIHtcblx0bGV0IGxhc3RVcmw7XG5cdGxldCB3YXRjaGluZyA9IGZhbHNlO1xuXHRyZXR1cm4geyBydW4oKSB7XG5cdFx0aWYgKHdhdGNoaW5nKSByZXR1cm47XG5cdFx0d2F0Y2hpbmcgPSB0cnVlO1xuXHRcdGxhc3RVcmwgPSBuZXcgVVJMKGxvY2F0aW9uLmhyZWYpO1xuXHRcdGlmIChzdXBwb3J0c05hdmlnYXRpb25BcGkpIGdsb2JhbFRoaXMubmF2aWdhdGlvbi5hZGRFdmVudExpc3RlbmVyKFwibmF2aWdhdGVcIiwgKGV2ZW50KSA9PiB7XG5cdFx0XHRjb25zdCBuZXdVcmwgPSBuZXcgVVJMKGV2ZW50LmRlc3RpbmF0aW9uLnVybCk7XG5cdFx0XHRpZiAobmV3VXJsLmhyZWYgPT09IGxhc3RVcmwuaHJlZikgcmV0dXJuO1xuXHRcdFx0d2luZG93LmRpc3BhdGNoRXZlbnQobmV3IFd4dExvY2F0aW9uQ2hhbmdlRXZlbnQobmV3VXJsLCBsYXN0VXJsKSk7XG5cdFx0XHRsYXN0VXJsID0gbmV3VXJsO1xuXHRcdH0sIHsgc2lnbmFsOiBjdHguc2lnbmFsIH0pO1xuXHRcdGVsc2UgY3R4LnNldEludGVydmFsKCgpID0+IHtcblx0XHRcdGNvbnN0IG5ld1VybCA9IG5ldyBVUkwobG9jYXRpb24uaHJlZik7XG5cdFx0XHRpZiAobmV3VXJsLmhyZWYgIT09IGxhc3RVcmwuaHJlZikge1xuXHRcdFx0XHR3aW5kb3cuZGlzcGF0Y2hFdmVudChuZXcgV3h0TG9jYXRpb25DaGFuZ2VFdmVudChuZXdVcmwsIGxhc3RVcmwpKTtcblx0XHRcdFx0bGFzdFVybCA9IG5ld1VybDtcblx0XHRcdH1cblx0XHR9LCAxZTMpO1xuXHR9IH07XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IGNyZWF0ZUxvY2F0aW9uV2F0Y2hlciB9O1xuIiwiaW1wb3J0IHsgbG9nZ2VyIH0gZnJvbSBcIi4vaW50ZXJuYWwvbG9nZ2VyLm1qc1wiO1xuaW1wb3J0IHsgZ2V0VW5pcXVlRXZlbnROYW1lIH0gZnJvbSBcIi4vaW50ZXJuYWwvY3VzdG9tLWV2ZW50cy5tanNcIjtcbmltcG9ydCB7IGNyZWF0ZUxvY2F0aW9uV2F0Y2hlciB9IGZyb20gXCIuL2ludGVybmFsL2xvY2F0aW9uLXdhdGNoZXIubWpzXCI7XG5pbXBvcnQgeyBicm93c2VyIH0gZnJvbSBcInd4dC9icm93c2VyXCI7XG4vLyNyZWdpb24gc3JjL3V0aWxzL2NvbnRlbnQtc2NyaXB0LWNvbnRleHQudHNcbi8qKlxuKiBJbXBsZW1lbnRzXG4qIFtgQWJvcnRDb250cm9sbGVyYF0oaHR0cHM6Ly9kZXZlbG9wZXIubW96aWxsYS5vcmcvZW4tVVMvZG9jcy9XZWIvQVBJL0Fib3J0Q29udHJvbGxlcikuXG4qIFVzZWQgdG8gZGV0ZWN0IGFuZCBzdG9wIGNvbnRlbnQgc2NyaXB0IGNvZGUgd2hlbiB0aGUgc2NyaXB0IGlzIGludmFsaWRhdGVkLlxuKlxuKiBJdCBhbHNvIHByb3ZpZGVzIHNldmVyYWwgdXRpbGl0aWVzIGxpa2UgYGN0eC5zZXRUaW1lb3V0YCBhbmRcbiogYGN0eC5zZXRJbnRlcnZhbGAgdGhhdCBzaG91bGQgYmUgdXNlZCBpbiBjb250ZW50IHNjcmlwdHMgaW5zdGVhZCBvZlxuKiBgd2luZG93LnNldFRpbWVvdXRgIG9yIGB3aW5kb3cuc2V0SW50ZXJ2YWxgLlxuKlxuKiBUbyBjcmVhdGUgY29udGV4dCBmb3IgdGVzdGluZywgeW91IGNhbiB1c2UgdGhlIGNsYXNzJ3MgY29uc3RydWN0b3I6XG4qXG4qIGBgYHRzXG4qIGltcG9ydCB7IENvbnRlbnRTY3JpcHRDb250ZXh0IH0gZnJvbSAnd3h0L3V0aWxzL2NvbnRlbnQtc2NyaXB0cy1jb250ZXh0JztcbipcbiogdGVzdCgnc3RvcmFnZSBsaXN0ZW5lciBzaG91bGQgYmUgcmVtb3ZlZCB3aGVuIGNvbnRleHQgaXMgaW52YWxpZGF0ZWQnLCAoKSA9PiB7XG4qICAgY29uc3QgY3R4ID0gbmV3IENvbnRlbnRTY3JpcHRDb250ZXh0KCd0ZXN0Jyk7XG4qICAgY29uc3QgaXRlbSA9IHN0b3JhZ2UuZGVmaW5lSXRlbSgnbG9jYWw6Y291bnQnLCB7IGRlZmF1bHRWYWx1ZTogMCB9KTtcbiogICBjb25zdCB3YXRjaGVyID0gdmkuZm4oKTtcbipcbiogICBjb25zdCB1bndhdGNoID0gaXRlbS53YXRjaCh3YXRjaGVyKTtcbiogICBjdHgub25JbnZhbGlkYXRlZCh1bndhdGNoKTsgLy8gTGlzdGVuIGZvciBpbnZhbGlkYXRlIGhlcmVcbipcbiogICBhd2FpdCBpdGVtLnNldFZhbHVlKDEpO1xuKiAgIGV4cGVjdCh3YXRjaGVyKS50b0JlQ2FsbGVkVGltZXMoMSk7XG4qICAgZXhwZWN0KHdhdGNoZXIpLnRvQmVDYWxsZWRXaXRoKDEsIDApO1xuKlxuKiAgIGN0eC5ub3RpZnlJbnZhbGlkYXRlZCgpOyAvLyBVc2UgdGhpcyBmdW5jdGlvbiB0byBpbnZhbGlkYXRlIHRoZSBjb250ZXh0XG4qICAgYXdhaXQgaXRlbS5zZXRWYWx1ZSgyKTtcbiogICBleHBlY3Qod2F0Y2hlcikudG9CZUNhbGxlZFRpbWVzKDEpO1xuKiB9KTtcbiogYGBgXG4qL1xudmFyIENvbnRlbnRTY3JpcHRDb250ZXh0ID0gY2xhc3MgQ29udGVudFNjcmlwdENvbnRleHQge1xuXHRzdGF0aWMgU0NSSVBUX1NUQVJURURfTUVTU0FHRV9UWVBFID0gZ2V0VW5pcXVlRXZlbnROYW1lKFwid3h0OmNvbnRlbnQtc2NyaXB0LXN0YXJ0ZWRcIik7XG5cdGlkO1xuXHRhYm9ydENvbnRyb2xsZXI7XG5cdGxvY2F0aW9uV2F0Y2hlciA9IGNyZWF0ZUxvY2F0aW9uV2F0Y2hlcih0aGlzKTtcblx0Y29uc3RydWN0b3IoY29udGVudFNjcmlwdE5hbWUsIG9wdGlvbnMpIHtcblx0XHR0aGlzLmNvbnRlbnRTY3JpcHROYW1lID0gY29udGVudFNjcmlwdE5hbWU7XG5cdFx0dGhpcy5vcHRpb25zID0gb3B0aW9ucztcblx0XHR0aGlzLmlkID0gTWF0aC5yYW5kb20oKS50b1N0cmluZygzNikuc2xpY2UoMik7XG5cdFx0dGhpcy5hYm9ydENvbnRyb2xsZXIgPSBuZXcgQWJvcnRDb250cm9sbGVyKCk7XG5cdFx0dGhpcy5zdG9wT2xkU2NyaXB0cygpO1xuXHRcdHRoaXMubGlzdGVuRm9yTmV3ZXJTY3JpcHRzKCk7XG5cdH1cblx0Z2V0IHNpZ25hbCgpIHtcblx0XHRyZXR1cm4gdGhpcy5hYm9ydENvbnRyb2xsZXIuc2lnbmFsO1xuXHR9XG5cdGFib3J0KHJlYXNvbikge1xuXHRcdHJldHVybiB0aGlzLmFib3J0Q29udHJvbGxlci5hYm9ydChyZWFzb24pO1xuXHR9XG5cdGdldCBpc0ludmFsaWQoKSB7XG5cdFx0aWYgKGJyb3dzZXIucnVudGltZT8uaWQgPT0gbnVsbCkgdGhpcy5ub3RpZnlJbnZhbGlkYXRlZCgpO1xuXHRcdHJldHVybiB0aGlzLnNpZ25hbC5hYm9ydGVkO1xuXHR9XG5cdGdldCBpc1ZhbGlkKCkge1xuXHRcdHJldHVybiAhdGhpcy5pc0ludmFsaWQ7XG5cdH1cblx0LyoqXG5cdCogQWRkIGEgbGlzdGVuZXIgdGhhdCBpcyBjYWxsZWQgd2hlbiB0aGUgY29udGVudCBzY3JpcHQncyBjb250ZXh0IGlzXG5cdCogaW52YWxpZGF0ZWQuXG5cdCpcblx0KiBAZXhhbXBsZVxuXHQqICAgYnJvd3Nlci5ydW50aW1lLm9uTWVzc2FnZS5hZGRMaXN0ZW5lcihjYik7XG5cdCogICBjb25zdCByZW1vdmVJbnZhbGlkYXRlZExpc3RlbmVyID0gY3R4Lm9uSW52YWxpZGF0ZWQoKCkgPT4ge1xuXHQqICAgICBicm93c2VyLnJ1bnRpbWUub25NZXNzYWdlLnJlbW92ZUxpc3RlbmVyKGNiKTtcblx0KiAgIH0pO1xuXHQqICAgLy8gLi4uXG5cdCogICByZW1vdmVJbnZhbGlkYXRlZExpc3RlbmVyKCk7XG5cdCpcblx0KiBAcmV0dXJucyBBIGZ1bmN0aW9uIHRvIHJlbW92ZSB0aGUgbGlzdGVuZXIuXG5cdCovXG5cdG9uSW52YWxpZGF0ZWQoY2IpIHtcblx0XHR0aGlzLnNpZ25hbC5hZGRFdmVudExpc3RlbmVyKFwiYWJvcnRcIiwgY2IpO1xuXHRcdHJldHVybiAoKSA9PiB0aGlzLnNpZ25hbC5yZW1vdmVFdmVudExpc3RlbmVyKFwiYWJvcnRcIiwgY2IpO1xuXHR9XG5cdC8qKlxuXHQqIFJldHVybiBhIHByb21pc2UgdGhhdCBuZXZlciByZXNvbHZlcy4gVXNlZnVsIGlmIHlvdSBoYXZlIGFuIGFzeW5jIGZ1bmN0aW9uXG5cdCogdGhhdCBzaG91bGRuJ3QgcnVuIGFmdGVyIHRoZSBjb250ZXh0IGlzIGV4cGlyZWQuXG5cdCpcblx0KiBAZXhhbXBsZVxuXHQqICAgY29uc3QgZ2V0VmFsdWVGcm9tU3RvcmFnZSA9IGFzeW5jICgpID0+IHtcblx0KiAgICAgaWYgKGN0eC5pc0ludmFsaWQpIHJldHVybiBjdHguYmxvY2soKTtcblx0KlxuXHQqICAgICAvLyAuLi5cblx0KiAgIH07XG5cdCovXG5cdGJsb2NrKCkge1xuXHRcdHJldHVybiBuZXcgUHJvbWlzZSgoKSA9PiB7fSk7XG5cdH1cblx0LyoqXG5cdCogV3JhcHBlciBhcm91bmQgYHdpbmRvdy5zZXRJbnRlcnZhbGAgdGhhdCBhdXRvbWF0aWNhbGx5IGNsZWFycyB0aGUgaW50ZXJ2YWxcblx0KiB3aGVuIGludmFsaWRhdGVkLlxuXHQqXG5cdCogSW50ZXJ2YWxzIGNhbiBiZSBjbGVhcmVkIGJ5IGNhbGxpbmcgdGhlIG5vcm1hbCBgY2xlYXJJbnRlcnZhbGAgZnVuY3Rpb24uXG5cdCovXG5cdHNldEludGVydmFsKGhhbmRsZXIsIHRpbWVvdXQpIHtcblx0XHRjb25zdCBpZCA9IHNldEludGVydmFsKCgpID0+IHtcblx0XHRcdGlmICh0aGlzLmlzVmFsaWQpIGhhbmRsZXIoKTtcblx0XHR9LCB0aW1lb3V0KTtcblx0XHR0aGlzLm9uSW52YWxpZGF0ZWQoKCkgPT4gY2xlYXJJbnRlcnZhbChpZCkpO1xuXHRcdHJldHVybiBpZDtcblx0fVxuXHQvKipcblx0KiBXcmFwcGVyIGFyb3VuZCBgd2luZG93LnNldFRpbWVvdXRgIHRoYXQgYXV0b21hdGljYWxseSBjbGVhcnMgdGhlIGludGVydmFsXG5cdCogd2hlbiBpbnZhbGlkYXRlZC5cblx0KlxuXHQqIFRpbWVvdXRzIGNhbiBiZSBjbGVhcmVkIGJ5IGNhbGxpbmcgdGhlIG5vcm1hbCBgc2V0VGltZW91dGAgZnVuY3Rpb24uXG5cdCovXG5cdHNldFRpbWVvdXQoaGFuZGxlciwgdGltZW91dCkge1xuXHRcdGNvbnN0IGlkID0gc2V0VGltZW91dCgoKSA9PiB7XG5cdFx0XHRpZiAodGhpcy5pc1ZhbGlkKSBoYW5kbGVyKCk7XG5cdFx0fSwgdGltZW91dCk7XG5cdFx0dGhpcy5vbkludmFsaWRhdGVkKCgpID0+IGNsZWFyVGltZW91dChpZCkpO1xuXHRcdHJldHVybiBpZDtcblx0fVxuXHQvKipcblx0KiBXcmFwcGVyIGFyb3VuZCBgd2luZG93LnJlcXVlc3RBbmltYXRpb25GcmFtZWAgdGhhdCBhdXRvbWF0aWNhbGx5IGNhbmNlbHNcblx0KiB0aGUgcmVxdWVzdCB3aGVuIGludmFsaWRhdGVkLlxuXHQqXG5cdCogQ2FsbGJhY2tzIGNhbiBiZSBjYW5jZWxlZCBieSBjYWxsaW5nIHRoZSBub3JtYWwgYGNhbmNlbEFuaW1hdGlvbkZyYW1lYFxuXHQqIGZ1bmN0aW9uLlxuXHQqL1xuXHRyZXF1ZXN0QW5pbWF0aW9uRnJhbWUoY2FsbGJhY2spIHtcblx0XHRjb25zdCBpZCA9IHJlcXVlc3RBbmltYXRpb25GcmFtZSgoLi4uYXJncykgPT4ge1xuXHRcdFx0aWYgKHRoaXMuaXNWYWxpZCkgY2FsbGJhY2soLi4uYXJncyk7XG5cdFx0fSk7XG5cdFx0dGhpcy5vbkludmFsaWRhdGVkKCgpID0+IGNhbmNlbEFuaW1hdGlvbkZyYW1lKGlkKSk7XG5cdFx0cmV0dXJuIGlkO1xuXHR9XG5cdC8qKlxuXHQqIFdyYXBwZXIgYXJvdW5kIGB3aW5kb3cucmVxdWVzdElkbGVDYWxsYmFja2AgdGhhdCBhdXRvbWF0aWNhbGx5IGNhbmNlbHMgdGhlXG5cdCogcmVxdWVzdCB3aGVuIGludmFsaWRhdGVkLlxuXHQqXG5cdCogQ2FsbGJhY2tzIGNhbiBiZSBjYW5jZWxlZCBieSBjYWxsaW5nIHRoZSBub3JtYWwgYGNhbmNlbElkbGVDYWxsYmFja2Bcblx0KiBmdW5jdGlvbi5cblx0Ki9cblx0cmVxdWVzdElkbGVDYWxsYmFjayhjYWxsYmFjaywgb3B0aW9ucykge1xuXHRcdGNvbnN0IGlkID0gcmVxdWVzdElkbGVDYWxsYmFjaygoLi4uYXJncykgPT4ge1xuXHRcdFx0aWYgKCF0aGlzLnNpZ25hbC5hYm9ydGVkKSBjYWxsYmFjayguLi5hcmdzKTtcblx0XHR9LCBvcHRpb25zKTtcblx0XHR0aGlzLm9uSW52YWxpZGF0ZWQoKCkgPT4gY2FuY2VsSWRsZUNhbGxiYWNrKGlkKSk7XG5cdFx0cmV0dXJuIGlkO1xuXHR9XG5cdGFkZEV2ZW50TGlzdGVuZXIodGFyZ2V0LCB0eXBlLCBoYW5kbGVyLCBvcHRpb25zKSB7XG5cdFx0aWYgKHR5cGUgPT09IFwid3h0OmxvY2F0aW9uY2hhbmdlXCIpIHtcblx0XHRcdGlmICh0aGlzLmlzVmFsaWQpIHRoaXMubG9jYXRpb25XYXRjaGVyLnJ1bigpO1xuXHRcdH1cblx0XHR0YXJnZXQuYWRkRXZlbnRMaXN0ZW5lcj8uKHR5cGUuc3RhcnRzV2l0aChcInd4dDpcIikgPyBnZXRVbmlxdWVFdmVudE5hbWUodHlwZSkgOiB0eXBlLCBoYW5kbGVyLCB7XG5cdFx0XHQuLi5vcHRpb25zLFxuXHRcdFx0c2lnbmFsOiB0aGlzLnNpZ25hbFxuXHRcdH0pO1xuXHR9XG5cdC8qKlxuXHQqIEBpbnRlcm5hbFxuXHQqIEFib3J0IHRoZSBhYm9ydCBjb250cm9sbGVyIGFuZCBleGVjdXRlIGFsbCBgb25JbnZhbGlkYXRlZGAgbGlzdGVuZXJzLlxuXHQqL1xuXHRub3RpZnlJbnZhbGlkYXRlZCgpIHtcblx0XHR0aGlzLmFib3J0KFwiQ29udGVudCBzY3JpcHQgY29udGV4dCBpbnZhbGlkYXRlZFwiKTtcblx0XHRsb2dnZXIuZGVidWcoYENvbnRlbnQgc2NyaXB0IFwiJHt0aGlzLmNvbnRlbnRTY3JpcHROYW1lfVwiIGNvbnRleHQgaW52YWxpZGF0ZWRgKTtcblx0fVxuXHRzdG9wT2xkU2NyaXB0cygpIHtcblx0XHRkb2N1bWVudC5kaXNwYXRjaEV2ZW50KG5ldyBDdXN0b21FdmVudChDb250ZW50U2NyaXB0Q29udGV4dC5TQ1JJUFRfU1RBUlRFRF9NRVNTQUdFX1RZUEUsIHsgZGV0YWlsOiB7XG5cdFx0XHRjb250ZW50U2NyaXB0TmFtZTogdGhpcy5jb250ZW50U2NyaXB0TmFtZSxcblx0XHRcdG1lc3NhZ2VJZDogdGhpcy5pZFxuXHRcdH0gfSkpO1xuXHRcdGlmICghdGhpcy5vcHRpb25zPy5ub1NjcmlwdFN0YXJ0ZWRQb3N0TWVzc2FnZSkgd2luZG93LnBvc3RNZXNzYWdlKHtcblx0XHRcdHR5cGU6IENvbnRlbnRTY3JpcHRDb250ZXh0LlNDUklQVF9TVEFSVEVEX01FU1NBR0VfVFlQRSxcblx0XHRcdGNvbnRlbnRTY3JpcHROYW1lOiB0aGlzLmNvbnRlbnRTY3JpcHROYW1lLFxuXHRcdFx0bWVzc2FnZUlkOiB0aGlzLmlkXG5cdFx0fSwgXCIqXCIpO1xuXHR9XG5cdHZlcmlmeVNjcmlwdFN0YXJ0ZWRFdmVudChldmVudCkge1xuXHRcdGNvbnN0IGlzU2FtZUNvbnRlbnRTY3JpcHQgPSBldmVudC5kZXRhaWw/LmNvbnRlbnRTY3JpcHROYW1lID09PSB0aGlzLmNvbnRlbnRTY3JpcHROYW1lO1xuXHRcdGNvbnN0IGlzRnJvbVNlbGYgPSBldmVudC5kZXRhaWw/Lm1lc3NhZ2VJZCA9PT0gdGhpcy5pZDtcblx0XHRyZXR1cm4gaXNTYW1lQ29udGVudFNjcmlwdCAmJiAhaXNGcm9tU2VsZjtcblx0fVxuXHRsaXN0ZW5Gb3JOZXdlclNjcmlwdHMoKSB7XG5cdFx0Y29uc3QgY2IgPSAoZXZlbnQpID0+IHtcblx0XHRcdGlmICghKGV2ZW50IGluc3RhbmNlb2YgQ3VzdG9tRXZlbnQpIHx8ICF0aGlzLnZlcmlmeVNjcmlwdFN0YXJ0ZWRFdmVudChldmVudCkpIHJldHVybjtcblx0XHRcdHRoaXMubm90aWZ5SW52YWxpZGF0ZWQoKTtcblx0XHR9O1xuXHRcdGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoQ29udGVudFNjcmlwdENvbnRleHQuU0NSSVBUX1NUQVJURURfTUVTU0FHRV9UWVBFLCBjYik7XG5cdFx0dGhpcy5vbkludmFsaWRhdGVkKCgpID0+IGRvY3VtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoQ29udGVudFNjcmlwdENvbnRleHQuU0NSSVBUX1NUQVJURURfTUVTU0FHRV9UWVBFLCBjYikpO1xuXHR9XG59O1xuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBDb250ZW50U2NyaXB0Q29udGV4dCB9O1xuIl0sInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswLDEsMiw0LDUsNiw3XSwibWFwcGluZ3MiOiI7O0NBQ0EsU0FBUyxvQkFBb0IsWUFBWTtFQUN4QyxPQUFPO0NBQ1I7Ozs7Ozs7Ozs7Ozs7Ozs7O0NFYUEsSUFBTSxVRGZpQixXQUFXLFNBQVMsU0FBUyxLQUNoRCxXQUFXLFVBQ1gsV0FBVzs7O0NFSGYsSUFBQSxrQkFBZSxvQkFBb0I7RUFDakMsU0FBUyxDQUFDLFlBQVk7RUFDdEIsT0FBTztFQUVQLE9BQU87R0FFTCxJQUFJLE9BQU8sUUFBUSxPQUFPLE1BQ3hCO0dBR0YsU0FBUyxjQUFjLFVBQWtCO0lBQ3ZDLE1BQU0sSUFBSSxLQUFLLElBQUksR0FBRyxRQUFRO0lBQzlCLE1BQU0sVUFBVSxJQUFJO0lBQ3BCLE1BQU0sVUFBVSxLQUFLLE1BQU0sSUFBSSxFQUFFLElBQUk7SUFDckMsTUFBTSxRQUFRLEtBQUssTUFBTSxJQUFJLElBQUk7SUFFakMsT0FBTyxHQUFHLE9BQU8sS0FBSyxDQUFDLENBQUMsU0FBUyxHQUFHLEdBQUcsRUFBRSxHQUFHLE9BQU8sT0FBTyxDQUFDLENBQUMsU0FDMUQsR0FDQSxHQUNGLEVBQUUsR0FBRyxPQUFPLE9BQU8sQ0FBQyxDQUFDLFNBQVMsR0FBRyxHQUFHO0dBQ3RDO0dBRUEsTUFBTSxXQUFXLE9BQU8sU0FBUyxTQUFTLFFBQVEsVUFBVSxFQUFFO0dBRzlELE1BQU0sVUFBVSxTQUFTLGNBQWMsS0FBSztHQUM1QyxNQUFNLFVBQVUsU0FBUyxjQUFjLElBQUk7R0FDM0MsTUFBTSxRQUFRLFNBQVMsY0FBYyxHQUFHO0dBQ3hDLE1BQU0sYUFBYSxTQUFTLGNBQWMsR0FBRztHQUU3QyxRQUFRLFlBQVksT0FBTztHQUMzQixRQUFRLFlBQVksS0FBSztHQUN6QixRQUFRLFlBQVksVUFBVTtHQUU5QixRQUFRLE1BQU0sV0FBVztHQUN6QixRQUFRLE1BQU0sTUFBTTtHQUNwQixRQUFRLE1BQU0sT0FBTztHQUNyQixRQUFRLE1BQU0sUUFBUTtHQUN0QixRQUFRLE1BQU0sU0FBUztHQUN2QixRQUFRLE1BQU0sa0JBQWtCO0dBQ2hDLFFBQVEsTUFBTSxRQUFRO0dBQ3RCLFFBQVEsTUFBTSxVQUFVO0dBQ3hCLFFBQVEsTUFBTSxhQUFhO0dBQzNCLFFBQVEsTUFBTSxpQkFBaUI7R0FDL0IsUUFBUSxNQUFNLE1BQU07R0FDcEIsUUFBUSxNQUFNLFVBQVU7R0FDeEIsUUFBUSxNQUFNLFlBQVk7R0FDMUIsUUFBUSxNQUFNLFNBQVM7R0FDdkIsUUFBUSxNQUFNLGFBQWE7R0FFM0IsUUFBUSxjQUFjO0dBQ3RCLFFBQVEsTUFBTSxXQUFXO0dBQ3pCLFFBQVEsTUFBTSxhQUFhO0dBQzNCLFFBQVEsTUFBTSxTQUFTO0dBQ3ZCLFFBQVEsTUFBTSxVQUFVO0dBQ3hCLFFBQVEsTUFBTSxhQUFhO0dBQzNCLFFBQVEsTUFBTSxPQUFPO0dBQ3JCLFFBQVEsTUFBTSxZQUFZO0dBRTFCLE1BQU0sY0FBYztHQUNwQixNQUFNLE1BQU0sV0FBVztHQUN2QixNQUFNLE1BQU0sYUFBYTtHQUN6QixNQUFNLE1BQU0sU0FBUztHQUNyQixNQUFNLE1BQU0sVUFBVTtHQUN0QixNQUFNLE1BQU0sWUFBWTtHQUN4QixNQUFNLE1BQU0sYUFBYTtHQUN6QixNQUFNLE1BQU0sZ0JBQWdCO0dBQzVCLE1BQU0sTUFBTSxxQkFBcUI7R0FDakMsTUFBTSxNQUFNLFdBQVc7R0FDdkIsTUFBTSxNQUFNLE9BQU87R0FFbkIsV0FBVyxjQUFjO0dBQ3pCLFdBQVcsTUFBTSxXQUFXO0dBQzVCLFdBQVcsTUFBTSxTQUFTO0dBQzFCLFdBQVcsTUFBTSxVQUFVO0dBQzNCLFdBQVcsTUFBTSxhQUFhO0dBQzlCLFdBQVcsTUFBTSxVQUFVO0dBQzNCLFdBQVcsTUFBTSxxQkFBcUI7R0FDdEMsV0FBVyxNQUFNLFdBQVc7R0FDNUIsV0FBVyxNQUFNLE9BQU87R0FDeEIsV0FBVyxNQUFNLFlBQVk7R0FHN0IsTUFBTSxrQkFBa0IsU0FBUyxjQUFjLEtBQUs7R0FDcEQsZ0JBQWdCLE1BQU0sV0FBVztHQUNqQyxnQkFBZ0IsTUFBTSxTQUFTO0dBQy9CLGdCQUFnQixNQUFNLFFBQVE7R0FDOUIsZ0JBQWdCLE1BQU0sU0FBUztHQUMvQixnQkFBZ0IsTUFBTSxhQUFhO0dBQ25DLGdCQUFnQixNQUFNLGFBQWE7R0FHbkMsTUFBTSxhQUFhLFNBQVMsY0FBYyxLQUFLO0dBQy9DLFdBQVcsTUFBTSxXQUFXO0dBQzVCLFdBQVcsTUFBTSxTQUFTO0dBQzFCLFdBQVcsTUFBTSxRQUFRO0dBQ3pCLFdBQVcsTUFBTSxRQUFRO0dBQ3pCLFdBQVcsTUFBTSxhQUFhO0dBQzlCLFdBQVcsTUFBTSxpQkFBaUI7R0FDbEMsV0FBWSxNQUFjLHVCQUF1QjtHQUNqRCxXQUFXLE1BQU0sUUFBUTtHQUN6QixXQUFXLE1BQU0sZUFBZTtHQUNoQyxXQUFXLE1BQU0sVUFBVTtHQUMzQixXQUFXLE1BQU0sU0FBUztHQUMxQixXQUFXLE1BQU0sWUFBWTtHQUM3QixXQUFXLE1BQU0sWUFBWTtHQUM3QixXQUFXLE1BQU0sVUFBVTtHQUMzQixXQUFXLE1BQU0sWUFBWTtHQUM3QixXQUFXLE1BQU0sZ0JBQWdCO0dBQ2pDLFdBQVcsTUFBTSxhQUFhO0dBRzlCLE1BQU0sYUFBYSxTQUFTLGNBQWMsS0FBSztHQUMvQyxXQUFXLE1BQU0sVUFBVTtHQUMzQixXQUFXLE1BQU0sYUFBYTtHQUM5QixXQUFXLE1BQU0saUJBQWlCO0dBQ2xDLFdBQVcsTUFBTSxlQUFlO0dBRWhDLE1BQU0sYUFBYSxTQUFTLGNBQWMsTUFBTTtHQUNoRCxXQUFXLGNBQWM7R0FDekIsV0FBVyxNQUFNLFdBQVc7R0FDNUIsV0FBVyxNQUFNLGFBQWE7R0FDOUIsV0FBVyxNQUFNLGdCQUFnQjtHQUNqQyxXQUFXLE1BQU0sUUFBUTtHQUV6QixNQUFNLEtBQUssU0FBUyxjQUFjLE1BQU07R0FDeEMsR0FBRyxjQUFjO0dBQ2pCLEdBQUcsTUFBTSxXQUFXO0dBQ3BCLEdBQUcsTUFBTSxhQUFhO0dBQ3RCLEdBQUcsTUFBTSxVQUFVO0dBQ25CLEdBQUcsTUFBTSxlQUFlO0dBQ3hCLEdBQUcsTUFBTSxhQUFhO0dBQ3RCLEdBQUcsTUFBTSxRQUFRO0dBQ2pCLEdBQUcsTUFBTSxTQUFTO0dBQ2xCLEdBQUcsTUFBTSxnQkFBZ0I7R0FFekIsV0FBVyxZQUFZLFVBQVU7R0FDakMsV0FBVyxZQUFZLEVBQUU7R0FHekIsTUFBTSxhQUFhLFNBQVMsY0FBYyxLQUFLO0dBQy9DLFdBQVcsY0FBYztHQUN6QixXQUFXLE1BQU0sV0FBVztHQUM1QixXQUFXLE1BQU0sYUFBYTtHQUM5QixXQUFXLE1BQU0sZ0JBQWdCO0dBQ2pDLFdBQVcsTUFBTSxRQUFRO0dBQ3pCLFdBQVcsTUFBTSxlQUFlO0dBRWhDLE1BQU0sS0FBSyxTQUFTLGNBQWMsS0FBSztHQUN2QyxHQUFHLGNBQWM7R0FDakIsR0FBRyxNQUFNLFdBQVc7R0FDcEIsR0FBRyxNQUFNLGFBQWE7R0FDdEIsR0FBRyxNQUFNLHFCQUFxQjtHQUM5QixHQUFHLE1BQU0sUUFBUTtHQUNqQixHQUFHLE1BQU0sZ0JBQWdCO0dBQ3pCLEdBQUcsTUFBTSxlQUFlO0dBR3hCLE1BQU0sVUFBVSxTQUFTLGNBQWMsS0FBSztHQUM1QyxRQUFRLE1BQU0sU0FBUztHQUN2QixRQUFRLE1BQU0sYUFBYTtHQUMzQixRQUFRLE1BQU0sU0FBUztHQUd2QixNQUFNLFVBQVUsU0FBUyxjQUFjLFFBQVE7R0FDL0MsUUFBUSxZQUFZOzs7Ozs7Ozs7R0FTcEIsUUFBUSxNQUFNLFFBQVE7R0FDdEIsUUFBUSxNQUFNLFVBQVU7R0FDeEIsUUFBUSxNQUFNLFVBQVU7R0FDeEIsUUFBUSxNQUFNLGFBQWE7R0FDM0IsUUFBUSxNQUFNLGlCQUFpQjtHQUMvQixRQUFRLE1BQU0sYUFBYTtHQUMzQixRQUFRLE1BQU0sUUFBUTtHQUN0QixRQUFRLE1BQU0sV0FBVztHQUN6QixRQUFRLE1BQU0sYUFBYTtHQUMzQixRQUFRLE1BQU0sZUFBZTtHQUM3QixRQUFRLE1BQU0sU0FBUztHQUN2QixRQUFRLE1BQU0sU0FBUztHQUN2QixRQUFRLE1BQU0sWUFBWTtHQUMxQixRQUFRLE1BQU0sYUFBYTtHQUMzQixRQUFRLE1BQU0sVUFBVTtHQUV4QixRQUFRLGlCQUFpQixvQkFBb0I7SUFDM0MsUUFBUSxNQUFNLFlBQVk7SUFDMUIsUUFBUSxNQUFNLFNBQVM7SUFDdkIsUUFBUSxNQUFNLFlBQVk7R0FDNUIsQ0FBQztHQUVELFFBQVEsaUJBQWlCLG9CQUFvQjtJQUMzQyxRQUFRLE1BQU0sWUFBWTtJQUMxQixRQUFRLE1BQU0sU0FBUztJQUN2QixRQUFRLE1BQU0sWUFBWTtHQUM1QixDQUFDO0dBRUQsUUFBUSxpQkFBaUIsU0FBUyxPQUFPLE1BQU07SUFDN0MsRUFBRSxnQkFBZ0I7SUFDbEIsSUFBSTtLQUNGLE1BQU0sUUFBUSxRQUFRLFlBQVksRUFBRSxTQUFTLGlCQUFpQixDQUFDO0lBQ2pFLFNBQVMsS0FBSztLQUNaLFFBQVEsTUFBTSw2QkFBNkIsR0FBRztJQUNoRDtHQUNGLENBQUM7R0FFRCxXQUFXLFlBQVksVUFBVTtHQUNqQyxXQUFXLFlBQVksVUFBVTtHQUNqQyxXQUFXLFlBQVksRUFBRTtHQUN6QixXQUFXLFlBQVksT0FBTztHQUM5QixXQUFXLFlBQVksT0FBTztHQUc5QixNQUFNLFVBQVUsU0FBUyxjQUFjLEtBQUs7R0FDNUMsUUFBUSxNQUFNLFdBQVc7R0FDekIsUUFBUSxNQUFNLFFBQVE7R0FDdEIsUUFBUSxNQUFNLFNBQVM7R0FDdkIsUUFBUSxNQUFNLGVBQWU7R0FDN0IsUUFBUSxNQUFNLGFBQWE7R0FDM0IsUUFBUSxNQUFNLFNBQVM7R0FDdkIsUUFBUSxNQUFNLFlBQVk7R0FDMUIsUUFBUSxNQUFNLFVBQVU7R0FDeEIsUUFBUSxNQUFNLGFBQWE7R0FDM0IsUUFBUSxNQUFNLGlCQUFpQjtHQUMvQixRQUFRLE1BQU0sU0FBUztHQUN2QixRQUFRLE1BQU0sYUFBYTtHQUczQixNQUFNLFdBQVcsU0FBUyxjQUFjLE1BQU07R0FDOUMsU0FBUyxjQUFjO0dBQ3ZCLFNBQVMsTUFBTSxXQUFXO0dBQzFCLFNBQVMsTUFBTSxhQUFhO0dBQzVCLFNBQVMsTUFBTSxRQUFRO0dBR3ZCLE1BQU0sWUFBWSxTQUFTLGNBQWMsS0FBSztHQUM5QyxVQUFVLE1BQU0sV0FBVztHQUMzQixVQUFVLE1BQU0sTUFBTTtHQUN0QixVQUFVLE1BQU0sUUFBUTtHQUN4QixVQUFVLE1BQU0sUUFBUTtHQUN4QixVQUFVLE1BQU0sU0FBUztHQUN6QixVQUFVLE1BQU0sZUFBZTtHQUMvQixVQUFVLE1BQU0sYUFBYTtHQUM3QixVQUFVLE1BQU0sU0FBUztHQUN6QixVQUFVLE1BQU0sWUFBWTtHQUM1QixVQUFVLE1BQU0sYUFBYTtHQUU3QixRQUFRLFlBQVksUUFBUTtHQUM1QixRQUFRLFlBQVksU0FBUztHQUU3QixnQkFBZ0IsWUFBWSxVQUFVO0dBQ3RDLGdCQUFnQixZQUFZLE9BQU87R0FHbkMsSUFBSSxhQUFhO0dBQ2pCLElBQUksY0FBbUI7R0FFdkIsTUFBTSxpQkFBaUI7SUFDckIsSUFBSSxhQUFhLGFBQWEsV0FBVztJQUN6QyxhQUFhO0lBQ2IsV0FBVyxNQUFNLFVBQVU7SUFDM0IsV0FBVyxNQUFNLFlBQVk7SUFDN0IsV0FBVyxNQUFNLGdCQUFnQjtJQUNqQyxRQUFRLE1BQU0sWUFBWTtJQUMxQixRQUFRLE1BQU0sWUFBWTtHQUM1QjtHQUVBLE1BQU0sa0JBQWtCO0lBQ3RCLGFBQWE7SUFDYixXQUFXLE1BQU0sVUFBVTtJQUMzQixXQUFXLE1BQU0sWUFBWTtJQUM3QixXQUFXLE1BQU0sZ0JBQWdCO0lBQ2pDLFFBQVEsTUFBTSxZQUFZO0lBQzFCLFFBQVEsTUFBTSxZQUFZO0dBQzVCO0dBRUEsZ0JBQWdCLGlCQUFpQixvQkFBb0I7SUFDbkQsU0FBUztHQUNYLENBQUM7R0FFRCxnQkFBZ0IsaUJBQWlCLG9CQUFvQjtJQUNuRCxjQUFjLGlCQUFpQjtLQUM3QixVQUFVO0lBQ1osR0FBRyxHQUFHO0dBQ1IsQ0FBQztHQUVELFFBQVEsaUJBQWlCLFVBQVUsTUFBTTtJQUN2QyxFQUFFLGdCQUFnQjtJQUNsQixJQUFJLFlBQ0YsVUFBVTtTQUVWLFNBQVM7R0FFYixDQUFDO0dBR0QsTUFBTSxlQUFlLEtBQUssSUFBSTtHQU85QixNQUFNLGdCQUhKLE9BQU8sZ0JBQWdCLGVBQWUsT0FBTyxZQUFZLHFCQUFxQixhQUN6RSxZQUFZLGlCQUFpQixZQUFZLElBQzFDLENBQUMsRUFBQSxDQUN5QixFQUFFLEVBQUUsU0FBUztHQUc3QyxNQUFNLGtCQUFrQix5QkFBeUI7R0FDakQsTUFBTSxxQkFBcUIsc0JBQXNCO0dBQ2pELE1BQU0sdUJBQXVCLCtCQUErQjtHQUM1RCxNQUFNLHNCQUFzQix3QkFBd0I7R0FDcEQsTUFBTSxxQkFBcUIsdUJBQXVCO0dBQ2xELE1BQU0sa0JBQWtCLGdCQUFnQjtHQUN4QyxNQUFNLHNCQUFzQix1QkFBdUI7R0FhbkQsTUFBTSxzQkFBc0IsT0FBZTtJQUN6QyxJQUFJO0tBQ0YsSUFBSSxNQUFNLEdBQ1IsZUFBZSxRQUFRLHFCQUFxQixPQUFPLEVBQUUsQ0FBQztVQUV0RCxlQUFlLFdBQVcsbUJBQW1CO0lBRWpELFFBQVEsQ0FBQztHQUNYO0dBYUEsTUFBTSx1QkFBdUI7SUFDM0IsSUFBSTtLQUNGLGVBQWUsUUFBUSxvQkFBb0IsT0FBTyxLQUFLLElBQUksQ0FBQyxDQUFDO0lBQy9ELFFBQVEsQ0FBQztHQUNYO0dBRUEsTUFBTSw0QkFBb0M7SUFDeEMsSUFBSTtLQUNGLE1BQU0sTUFBTSxlQUFlLFFBQVEsZUFBZTtLQUNsRCxJQUFJLEtBQUs7TUFDUCxNQUFNLE1BQU0sU0FBUyxLQUFLLEVBQUU7TUFDNUIsSUFBSSxDQUFDLE1BQU0sR0FBRyxLQUFLLE1BQU0sR0FBRyxPQUFPO0tBQ3JDO0lBQ0YsUUFBUSxDQUFDO0lBQ1QsT0FBTztHQUNUO0dBRUEsTUFBTSxxQkFBcUIsVUFBa0I7SUFDM0MsSUFBSTtLQUNGLElBQUksUUFBUSxHQUNWLGVBQWUsUUFBUSxpQkFBaUIsT0FBTyxLQUFLLENBQUM7VUFFckQsZUFBZSxXQUFXLGVBQWU7SUFFN0MsUUFBUSxDQUFDO0dBQ1g7R0FFQSxNQUFNLGlDQUF5QztJQUM3QyxJQUFJO0tBQ0YsTUFBTSxNQUFNLGVBQWUsUUFBUSxvQkFBb0I7S0FDdkQsSUFBSSxLQUFLO01BQ1AsTUFBTSxNQUFNLFNBQVMsS0FBSyxFQUFFO01BQzVCLElBQUksQ0FBQyxNQUFNLEdBQUcsS0FBSyxNQUFNLEdBQUcsT0FBTztLQUNyQztJQUNGLFFBQVEsQ0FBQztJQUNULE9BQU87R0FDVDtHQUVBLE1BQU0sMEJBQTBCLFVBQWtCO0lBQ2hELElBQUk7S0FDRixJQUFJLFFBQVEsR0FDVixlQUFlLFFBQVEsc0JBQXNCLE9BQU8sS0FBSyxDQUFDO1VBRTFELGVBQWUsV0FBVyxvQkFBb0I7SUFFbEQsUUFBUSxDQUFDO0dBQ1g7R0FFQSxNQUFNLDJCQUFtQztJQUN2QyxJQUFJO0tBQ0YsTUFBTSxNQUFNLGVBQWUsUUFBUSxtQkFBbUI7S0FDdEQsSUFBSSxLQUFLO01BQ1AsTUFBTSxNQUFNLFNBQVMsS0FBSyxFQUFFO01BQzVCLElBQUksQ0FBQyxNQUFNLEdBQUcsS0FBSyxPQUFPLEdBQUcsT0FBTztLQUN0QztJQUNGLFFBQVEsQ0FBQztJQUNULE9BQU87R0FDVDtHQUVBLE1BQU0sb0JBQW9CLFVBQWtCO0lBQzFDLElBQUk7S0FDRixJQUFJLFNBQVMsR0FDWCxlQUFlLFFBQVEscUJBQXFCLE9BQU8sS0FBSyxDQUFDO1VBRXpELGVBQWUsV0FBVyxtQkFBbUI7SUFFakQsUUFBUSxDQUFDO0dBQ1g7R0FFQSxNQUFNLGlDQUF5QztJQUM3QyxPQUFPLFNBQVMsS0FBSyxJQUFJLElBQUksTUFBTSxLQUFLLE9BQU8sQ0FBQyxDQUFDLFNBQVMsRUFBRSxDQUFDLENBQUMsTUFBTSxHQUFHLENBQUM7R0FDMUU7R0FFQSxNQUFNLCtCQUF1QztJQUMzQyxJQUFJO0tBQ0YsTUFBTSxNQUFNLGVBQWUsUUFBUSxrQkFBa0I7S0FDckQsSUFBSSxLQUFLLE9BQU87SUFDbEIsUUFBUSxDQUFDO0lBQ1QsT0FBTztHQUNUO0dBS0EsSUFBSSxnQkFBZ0I7R0FDcEIsSUFBSSxpQkFBaUI7R0FDckIsSUFBSSxzQkFBc0I7R0FDMUIsSUFBSSxrQkFBa0I7R0FHdEIsSUFBSSxrQkFBa0I7R0FFdEIsTUFBTSxjQUFjLG9CQUFvQjtHQUN4QyxNQUFNLGlCQUFpQix1QkFBdUI7R0FHOUMsTUFBTSxvQkFBb0IsZ0JBQWdCLGNBQWM7R0FFeEQsSUFBSSxtQkFBbUI7SUFDckIsZ0JBQWdCLGtCQUFrQix5QkFBeUI7SUFDM0QsaUJBQWlCLGNBQWMsSUFBSSxjQUFjO0lBRWpELHNCQUFzQix5QkFBeUI7SUFDL0Msa0JBQWtCLG1CQUFtQjtJQUdyQyxrQkFBa0I7R0FDcEIsT0FBTztJQUVMLGdCQUFnQix5QkFBeUI7SUFDekMsaUJBQWlCO0lBQ2pCLHNCQUFzQjtJQUN0QixrQkFBa0I7SUFFbEIsa0JBQWtCO0lBQ2xCLGtCQUFrQixjQUFjO0lBQ2hDLHVCQUF1QixDQUFDO0lBQ3hCLGlCQUFpQixDQUFDO0lBQ2xCLG1CQUFtQixDQUFDO0dBQ3RCO0dBQ0EsSUFBSTtJQUNGLGVBQWUsUUFBUSxvQkFBb0IsYUFBYTtHQUMxRCxRQUFRLENBQUM7R0FFVCxJQUFJLG1CQUFtQjtHQUN2QixJQUFJLG1CQUFtQjtHQUN2QixJQUFJLGNBQWM7R0FDbEIsSUFBSSxZQUFZO0dBQ2hCLElBQUksZ0JBQWdCO0dBR3BCLE1BQU0sa0JBQWtCLHFCQUFxQjtHQUM3QyxNQUFNLDZCQUFzQztJQUMxQyxJQUFJO0tBQ0YsT0FBTyxlQUFlLFFBQVEsZUFBZSxNQUFNO0lBQ3JELFFBQVE7S0FDTixPQUFPO0lBQ1Q7R0FDRjtHQUVBLE1BQU0sdUJBQXVCLGNBQXVCO0lBQ2xELElBQUk7S0FDRixJQUFJLFdBQ0YsZUFBZSxRQUFRLGlCQUFpQixNQUFNO1VBRTlDLGVBQWUsV0FBVyxlQUFlO0lBRTdDLFFBQVEsQ0FBQztHQUNYO0dBR0EsSUFBSSxlQUFlO0dBQ25CLElBQUksZUFBZTtHQUNuQixJQUFJLGlCQUFpQjtHQUdyQixTQUFTLGNBQWMsTUFBYyxPQUEwQjtJQUM3RCxJQUFJLENBQUMsTUFBTSxPQUFPO0lBQ2xCLE1BQU0sWUFBWSxLQUFLLEtBQUssQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLFFBQVEsVUFBVSxFQUFFO0lBQ2hFLE1BQU0sYUFBYSxNQUNoQixLQUFLLE1BQ0osRUFDRyxLQUFLLENBQUMsQ0FDTixZQUFZLENBQUMsQ0FDYixRQUFRLGdCQUFnQixFQUFFLENBQUMsQ0FDM0IsUUFBUSxVQUFVLEVBQUUsQ0FBQyxDQUNyQixRQUFRLFlBQVksRUFBRSxDQUMzQixDQUFDLENBQ0EsT0FBTyxPQUFPO0lBRWpCLElBQUksV0FBVyxTQUFTLGFBQWEsS0FBSyxDQUFDLFdBQVcsU0FBUyxPQUFPLEdBQ3BFLFdBQVcsS0FBSyxPQUFPO0lBRXpCLElBQUksV0FBVyxTQUFTLE9BQU8sS0FBSyxDQUFDLFdBQVcsU0FBUyxhQUFhLEdBQ3BFLFdBQVcsS0FBSyxhQUFhO0lBRy9CLEtBQUssTUFBTSxRQUFRLFlBQ2pCLElBQUksY0FBYyxRQUFRLFVBQVUsU0FBUyxJQUFJLE1BQU0sR0FDckQsT0FBTztJQUdYLE9BQU87R0FDVDtHQUVBLFNBQVMsZ0JBQWdCLE1BQWMsT0FBZ0M7SUFDckUsSUFBSSxDQUFDLE1BQU0sT0FBTztJQUNsQixNQUFNLFlBQVksS0FBSyxLQUFLLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxRQUFRLFVBQVUsRUFBRTtJQUNoRSxNQUFNLGFBQWEsTUFDaEIsS0FBSyxNQUNKLEVBQ0csS0FBSyxDQUFDLENBQ04sWUFBWSxDQUFDLENBQ2IsUUFBUSxnQkFBZ0IsRUFBRSxDQUFDLENBQzNCLFFBQVEsVUFBVSxFQUFFLENBQUMsQ0FDckIsUUFBUSxZQUFZLEVBQUUsQ0FDM0IsQ0FBQyxDQUNBLE9BQU8sT0FBTztJQUVqQixJQUFJLFdBQVcsU0FBUyxhQUFhLEtBQUssQ0FBQyxXQUFXLFNBQVMsT0FBTyxHQUNwRSxXQUFXLEtBQUssT0FBTztJQUV6QixJQUFJLFdBQVcsU0FBUyxPQUFPLEtBQUssQ0FBQyxXQUFXLFNBQVMsYUFBYSxHQUNwRSxXQUFXLEtBQUssYUFBYTtJQUcvQixLQUFLLE1BQU0sUUFBUSxZQUNqQixJQUFJLGNBQWMsUUFBUSxVQUFVLFNBQVMsSUFBSSxNQUFNLEdBQ3JELE9BQU87SUFHWCxPQUFPO0dBQ1Q7R0FFQSxNQUFNLDBCQUEwQjtJQUM5QixJQUFJLGFBQWE7SUFDakIsTUFBTSxTQUFTLFNBQVM7SUFDeEIsSUFBSSxDQUFDLFFBQVE7S0FDWCxJQUFJLFNBQVMsZUFBZSxXQUMxQixTQUFTLGlCQUNQLDBCQUNNO01BQ0osa0JBQWtCO0tBQ3BCLEdBQ0EsRUFBRSxNQUFNLEtBQUssQ0FDZjtLQUVGO0lBQ0Y7SUFDQSxJQUFJLENBQUMsT0FBTyxTQUFTLE9BQU8sR0FDMUIsT0FBTyxZQUFZLE9BQU87SUFFNUIsSUFBSSxDQUFDLE9BQU8sU0FBUyxlQUFlLEdBQ2xDLE9BQU8sWUFBWSxlQUFlO0dBRXRDO0dBRUEsSUFBSSxnQkFBeUM7R0FFN0MsTUFBTSwwQkFBMEI7SUFDOUIsb0JBQW9CLEtBQUs7SUFDekIsSUFBSSxlQUFlO0tBQ2pCLGNBQWMsV0FBVztLQUN6QixnQkFBZ0I7SUFDbEI7R0FDRjtHQUdBLE1BQU0scUJBQXFCLGdCQUF3QjtJQUNqRCxjQUFjO0lBQ2QsbUJBQW1CO0lBQ25CLG9CQUFvQixJQUFJO0lBR3hCLElBQUk7S0FDRixPQUFPLEtBQUs7SUFDZCxRQUFRLENBQUM7SUFHVCxJQUFJO0tBQ0YsU0FBUyxpQkFBaUIsY0FBYyxDQUFDLENBQUMsU0FBUyxVQUFVO01BQzNELElBQUk7T0FDRixNQUFNLElBQUk7T0FDVixFQUFFLE1BQU07T0FDUixFQUFFLFFBQVE7T0FDVixFQUFFLGdCQUFnQixLQUFLO09BQ3ZCLEVBQUUsS0FBSztNQUNULFFBQVEsQ0FBQztLQUNYLENBQUM7SUFDSCxRQUFRLENBQUM7SUFHVCxRQUFRLE1BQU0sVUFBVTtJQUN4QixnQkFBZ0IsTUFBTSxVQUFVO0lBR2hDLFNBQVMsUUFBUSwwQkFBMEIsWUFBWTtJQUd2RCxNQUFNLGNBQWM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Z0JBdURWLFlBQVk7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztrQkE4QlYsbUJBQW1CLElBQUksY0FBYyxLQUFLLElBQUksR0FBRyxLQUFLLE9BQU8sS0FBSyxJQUFJLElBQUksb0JBQW9CLEdBQUksQ0FBQyxDQUFDLElBQUksV0FBVzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7SUFpRC9ILElBQUksU0FBUyxpQkFDWCxTQUFTLGdCQUFnQixZQUFZOzs7OzRDQUlELFlBQVk7Ozs7Ozs7Ozs7OztrQkFZdEMsWUFBWTs7U0FFakIsSUFBSSxTQUFTLE1BQU07S0FDeEIsU0FBUyxLQUFLLFlBQVk7S0FDMUIsU0FBUyxLQUFLLE1BQU0sVUFBVTtJQUNoQztJQUdBLE1BQU0sVUFBVSxTQUFTLGVBQWUsc0JBQXNCO0lBQzlELElBQUksU0FBUztLQUNYLFFBQVEscUJBQXFCO01BQzNCLFFBQVEsTUFBTSxhQUFhO01BQzNCLFFBQVEsTUFBTSxjQUFjO0tBQzlCO0tBQ0EsUUFBUSxxQkFBcUI7TUFDM0IsUUFBUSxNQUFNLGFBQWE7TUFDM0IsUUFBUSxNQUFNLGNBQWM7S0FDOUI7S0FDQSxRQUFRLFVBQVUsWUFBWTtNQUM1QixJQUFJLE9BQU8sUUFBUSxTQUFTLEdBQzFCLE9BQU8sUUFBUSxLQUFLO1dBRXBCLElBQUk7T0FDRixNQUFNLFFBQVEsUUFBUSxZQUFZLEVBQUUsU0FBUyxvQkFBb0IsQ0FBQztNQUNwRSxRQUFRO09BQ04sT0FBTyxNQUFNO01BQ2Y7S0FFSjtJQUNGO0lBRUEsTUFBTSxVQUFVLFNBQVMsZUFBZSxzQkFBc0I7SUFDOUQsSUFBSSxTQUFTO0tBQ1gsUUFBUSxxQkFBcUI7TUFDM0IsUUFBUSxNQUFNLGFBQWE7TUFDM0IsUUFBUSxNQUFNLFFBQVE7S0FDeEI7S0FDQSxRQUFRLHFCQUFxQjtNQUMzQixRQUFRLE1BQU0sYUFBYTtNQUMzQixRQUFRLE1BQU0sUUFBUTtLQUN4QjtLQUNBLFFBQVEsVUFBVSxZQUFZO01BQzVCLElBQUk7T0FDRixNQUFNLFFBQVEsUUFBUSxZQUFZLEVBQUUsU0FBUyxpQkFBaUIsQ0FBQztNQUNqRSxTQUFTLEdBQUc7T0FDVixRQUFRLE1BQU0sb0JBQW9CLENBQUM7TUFDckM7S0FDRjtJQUNGO0lBR0EsSUFBSSxDQUFDLGlCQUFpQixTQUFTLGlCQUFpQjtLQUM5QyxnQkFBZ0IsSUFBSSx1QkFBdUI7TUFDekMsSUFBSSxDQUFDLGFBQWE7TUFDbEIsSUFBSSxDQUFDLFNBQVMsZUFBZSx5QkFBeUIsR0FDcEQsa0JBQWtCLFdBQVc7S0FFakMsQ0FBQztLQUNELGNBQWMsUUFBUSxTQUFTLGlCQUFpQjtNQUM5QyxXQUFXO01BQ1gsU0FBUztLQUNYLENBQUM7SUFDSDtJQUdBLElBQUksU0FBUyxlQUFlLFdBQzFCLFNBQVMsaUJBQ1AsMEJBQ007S0FDSixJQUFJLGVBQWUsQ0FBQyxTQUFTLGVBQWUseUJBQXlCLEdBQ25FLGtCQUFrQixXQUFXO0lBRWpDLEdBQ0EsRUFBRSxNQUFNLEtBQUssQ0FDZjtHQUVKO0dBR0EsSUFBSSxxQkFBcUIsR0FBRztJQUMxQixjQUFjO0lBQ2Qsa0JBQWtCLFFBQVE7R0FDNUI7R0FHQSxNQUFNLHNCQUFzQixZQUFZO0lBQ3RDLElBQUk7S0FDRixNQUFNLE9BQVEsTUFBTSxRQUFRLFFBQVEsTUFBTSxJQUFJO01BQzVDO01BQ0E7TUFDQTtNQUNBO0tBQ0YsQ0FBQztLQU9ELElBQUksS0FBSyxZQUFZLEtBQUssU0FBUyxTQUFTO01BQzFDLE1BQU0sUUFBa0IsTUFBTSxRQUFRLEtBQUssWUFBWSxJQUFJLEtBQUssZUFBZSxDQUFDO01BRWhGLElBQUksY0FBYyxVQUFVLEtBQUssR0FBRztPQUNsQyxJQUFJLE9BQU8sS0FBSyxjQUFjLFlBQVksS0FBSyxZQUFZLEdBQ3pELG1CQUFtQixLQUFLO09BRTFCLGNBQWM7T0FDZCxtQkFBbUI7T0FDbkIsb0JBQW9CLElBQUk7T0FDeEIsa0JBQWtCLFFBQVE7T0FDMUIsT0FBTztNQUNULE9BQU8sSUFBSSxhQUFhO09BQ3RCLGNBQWM7T0FDZCxrQkFBa0I7T0FDbEIsT0FBTyxTQUFTLE9BQU87T0FDdkIsT0FBTztNQUNUO0tBQ0YsT0FBTyxJQUFJLGFBQWE7TUFDdEIsY0FBYztNQUNkLGtCQUFrQjtNQUNsQixPQUFPLFNBQVMsT0FBTztNQUN2QixPQUFPO0tBQ1Q7SUFDRixTQUFTLEtBQUs7S0FDWixRQUFRLEtBQUssMEJBQTBCLEdBQUc7SUFDNUM7SUFDQSxPQUFPO0dBQ1Q7R0FHQSxNQUFNLDJCQUEyQixZQUFZO0lBQzNDLElBQUk7S0FDRixNQUFNLE9BQVEsTUFBTSxRQUFRLFFBQVEsTUFBTSxJQUFJO01BQzVDO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO0tBQ0YsQ0FBQztLQVVELElBQUksS0FBSyxhQUFhLEtBQUssU0FBUyxjQUFjLEtBQUssU0FBUyxVQUFVO01BQ3hFLE1BQU0sUUFBa0IsTUFBTSxRQUFRLEtBQUssZUFBZSxJQUFJLEtBQUssa0JBQWtCLENBQUM7TUFFdEYsSUFBSSxjQUFjLFVBQVUsS0FBSyxHQUFHO09BQ2xDLE1BQU0sU0FBUyxPQUFPLEtBQUssY0FBYyxZQUFZLEtBQUssWUFBWSxJQUFJLEtBQUssWUFBWTtPQUMzRixtQkFBbUI7T0FDbkIsbUJBQW1CO09BRW5CLE1BQU0sVUFBVSxnQkFBZ0IsVUFBVSxLQUFLLEtBQUs7T0FHcEQsTUFBTSxRQUFRLEtBQUssb0JBQW9CLENBQUM7T0FDeEMsSUFBSSxPQUFPLE1BQU0sYUFBYSxVQUFVO1FBQ3RDLGtCQUFrQixNQUFNO1FBQ3hCLGlCQUFpQixlQUFlO09BQ2xDO09BR0EsTUFBTSxtQkFBbUIsS0FBSyxjQUFjO09BQzVDLElBQUksa0JBQWtCLGNBQWMsV0FBVyxLQUFLLGlCQUFpQixhQUFhLFNBQ2hGLHNCQUFzQixpQkFBaUI7WUFFdkMsc0JBQXNCO09BRXhCLHVCQUF1QixtQkFBbUI7T0FFMUMsTUFBTSxXQUFXLEtBQUssSUFBSTtPQUMxQixNQUFNLGdCQUFnQixzQkFBc0IsSUFBSSxzQkFBc0I7T0FDdEUsTUFBTSxxQkFDSixnQkFBZ0IsS0FBSyxTQUFTLElBQUksS0FBSyxJQUFJLGVBQWUsTUFBTSxJQUFJO09BQ3RFLE1BQU0sYUFDSix3QkFBd0IsS0FBSyxrQkFBa0IsSUFDM0MsS0FBSyxJQUFJLG9CQUFvQixZQUFZLElBQ3pDO09BQ04sTUFBTSxTQUFTLGFBQWEsSUFBSSxLQUFLLElBQUksR0FBRyxXQUFXLFVBQVUsSUFBSTtPQUNyRSxNQUFNLGtCQUFrQixrQkFBa0I7T0FDMUMsS0FBd0IsTUFBTSxrQkFBa0IsR0FBSTtPQUNwRCxrQkFBa0IsV0FBWSxrQkFBa0I7T0FHaEQsSUFBSSxtQkFBbUI7UUFDckIsTUFBTSxjQUFjLG9CQUFvQjtRQUN4QyxJQUFJLGNBQWMsTUFBTSxXQUFXLEtBQUssZUFBZSxTQUNyRCxpQkFBaUI7T0FFckIsT0FBTyxJQUFJLENBQUMsa0JBQWtCLG1CQUFtQixHQUFHO1FBQ2xELGlCQUFpQjtRQUNqQixrQkFBa0IsY0FBYztPQUNsQztPQUVBLElBQUksS0FBSyxTQUFTLFNBQVM7UUFDekIsUUFBUSxjQUFjO1FBQ3RCLFFBQVEsTUFBTSxrQkFBa0I7T0FDbEMsT0FBTztRQUNMLFFBQVEsY0FBYztRQUN0QixRQUFRLE1BQU0sa0JBQWtCO09BQ2xDO09BRUEsa0JBQWtCO09BQ2xCLFFBQVEsTUFBTSxVQUFVO09BQ3hCLG9CQUFvQjtNQUN0QixPQUFPO09BRUwsbUJBQW1CO09BQ25CLFFBQVEsTUFBTSxVQUFVO01BQzFCO0tBQ0YsT0FBTztNQUNMLG1CQUFtQjtNQUNuQixRQUFRLE1BQU0sVUFBVTtLQUMxQjtJQUNGLFNBQVMsS0FBSztLQUNaLFFBQVEsS0FBSywrQkFBK0IsR0FBRztJQUNqRDtHQUNGO0dBS0EsTUFBTSw0QkFBNEI7SUFDaEMsTUFBTSxNQUFNLEtBQUssSUFBSTtJQUdyQixJQUFJLG1CQUFtQixHQUFHO0tBQ3hCLE1BQU0sb0JBQW9CLEtBQUssSUFBSSxHQUFHLEtBQUssT0FBTyxNQUFNLG9CQUFvQixHQUFJLENBQUM7S0FDakYsSUFBSSxzQkFBc0IsZ0JBQWdCO01BQ3hDLGlCQUFpQjtNQUNqQixHQUFHLGNBQWMsY0FBYyxpQkFBaUI7TUFFaEQsSUFBSSxhQUFhO09BQ2YsTUFBTSxlQUFlLFNBQVMsZUFBZSxxQkFBcUI7T0FDbEUsSUFBSSxjQUNGLGFBQWEsY0FBYyxjQUFjLGlCQUFpQjtZQUUxRCxrQkFBa0IsUUFBUTtNQUU5QjtLQUNGO0lBQ0Y7SUFHQSxJQUFJLG9CQUFvQixpQkFBaUIsR0FBRztLQUUxQyxNQUFNLGdCQUFnQixzQkFBc0IsSUFBSSxzQkFBc0I7S0FDdEUsTUFBTSxxQkFDSixtQkFBbUIsSUFDZixLQUFLLElBQUksZUFBZSxnQkFBZ0IsSUFDeEM7S0FDTixNQUFNLGFBQ0osd0JBQXdCLEtBQUssa0JBQWtCLElBQzNDLEtBQUssSUFBSSxvQkFBb0IsWUFBWSxJQUN6QztLQUNOLE1BQU0sU0FBUyxhQUFhLElBQUksS0FBSyxJQUFJLEdBQUcsTUFBTSxVQUFVLElBQUk7S0FDaEUsSUFBSSxrQkFBa0Isa0JBQWtCO0tBQ3hDLElBQUksbUJBQW1CLEdBQUc7TUFDeEIsTUFBTSxlQUFlLEtBQUssSUFBSSxHQUFHLE1BQU0sZ0JBQWdCO01BQ3ZELElBQUksa0JBQWtCLGNBQ3BCLGtCQUFrQjtLQUV0QjtLQUNBLElBQUksZUFBZSxLQUFLLE1BQU0sa0JBQWtCLEdBQUk7S0FHcEQsSUFBSSxnQkFBZ0IsS0FBSyxlQUFlLGNBQ3RDLGVBQWU7S0FRakIsSUFBSSxrQkFBa0IsS0FBSyxJQUN6QixHQUNBLEtBQUssT0FBTyxPQUxaLG1CQUFtQixJQUNmLEtBQUssSUFBSSxnQkFBZ0IsZ0JBQWdCLElBQ3pDLG1CQUdxQyxHQUFJLENBQy9DO0tBR0EsSUFBSSxnQkFBZ0IsS0FBSyxrQkFBa0IsY0FDekMsa0JBQWtCO0tBR3BCLElBQUksb0JBQW9CLGNBQWM7TUFDcEMsZUFBZTtNQUNmLE1BQU0sY0FBYyxjQUFjLGVBQWU7S0FDbkQ7S0FFQSxJQUFJLGlCQUFpQixjQUFjO01BQ2pDLGVBQWU7TUFDZixXQUFXLGNBQWMsa0JBQWtCLGNBQWMsWUFBWSxFQUFFO0tBQ3pFO0tBRUEsZUFBZTtJQUNqQjtHQUNGO0dBR0EsTUFBTSxXQUFXLFlBQVk7SUFDM0IsSUFBSSxXQUFXO0lBQ2YsWUFBWTtJQUNaLE1BQU0sVUFBVSxFQUFFO0lBRWxCLElBQUk7S0FDRixNQUFNLFlBQVksU0FBUyxvQkFBb0I7S0FDL0MsTUFBTSxXQUFXLE1BQU0sUUFBUSxRQUFRLFlBQVk7TUFDakQsU0FBUztNQUNUO01BQ0E7TUFDQSxtQkFBbUI7TUFDbkI7S0FDRixDQUFDO0tBR0QsSUFBSSxDQUFDLFlBQVksWUFBWSxlQUMzQjtLQUdGLElBQUksQ0FBQyxTQUFTLFVBQVU7TUFDdEIsb0JBQW9CLEtBQUs7TUFDekIsSUFBSSxhQUFhO09BQ2YsY0FBYztPQUNkLGtCQUFrQjtPQUNsQixPQUFPLFNBQVMsT0FBTztPQUN2QjtNQUNGO01BRUEsa0JBQWtCLENBQUM7TUFDbkIsdUJBQXVCLENBQUM7TUFDeEIsaUJBQWlCLENBQUM7TUFDbEIsbUJBQW1CLENBQUM7TUFDcEIsbUJBQW1CO01BQ25CLGlCQUFpQjtNQUNqQixzQkFBc0I7TUFDdEIsa0JBQWtCO01BRWxCLGtCQUFrQjtNQUNsQixtQkFBbUI7TUFDbkIsZUFBZTtNQUNmLGVBQWU7TUFDZixpQkFBaUI7TUFFakIsUUFBUSxNQUFNLFVBQVU7TUFDeEIsR0FBRyxjQUFjO01BQ2pCLEdBQUcsY0FBYztNQUNqQixHQUFHLE1BQU0sYUFBYTtNQUN0QixHQUFHLE1BQU0sUUFBUTtNQUNqQixHQUFHLE1BQU0sU0FBUztNQUNsQixVQUFVLE1BQU0sYUFBYTtNQUM3QixVQUFVLE1BQU0sWUFBWTtNQUM1QjtLQUNGO0tBRUEsbUJBQW1CLFNBQVMsb0JBQW9CO0tBR2hELElBQUksU0FBUyxVQUFVLEtBQUEsR0FDckIsSUFBSTtNQUNGLE1BQU0sY0FBYyxlQUFlLFFBQVEsZUFBZTtNQUMxRCxJQUFJLGVBQWUsZ0JBQWdCLE9BQU8sU0FBUyxLQUFLLEdBQUc7T0FFekQsZ0JBQWdCLHlCQUF5QjtPQUN6QyxlQUFlLFFBQVEsb0JBQW9CLGFBQWE7T0FDeEQsa0JBQWtCLFNBQVMsa0JBQWtCLFlBQVk7TUFDM0Q7TUFDQSxlQUFlLFFBQVEsaUJBQWlCLE9BQU8sU0FBUyxLQUFLLENBQUM7S0FDaEUsUUFBUSxDQUFDO0tBSVgsVUFBVSxNQUFNLGFBQWE7S0FDN0IsVUFBVSxNQUFNLFlBQVk7S0FFNUIsTUFBTSxVQUFVLFNBQVMsUUFBUTtLQUNqQyxHQUFHLGNBQWMsVUFBVSxRQUFRLE9BQU8sQ0FBQyxDQUFDLENBQUMsWUFBWSxJQUFJLFFBQVEsTUFBTSxDQUFDLElBQUk7S0FDaEYsSUFBSSxZQUFZLFlBQVk7TUFDMUIsR0FBRyxNQUFNLGFBQWE7TUFDdEIsR0FBRyxNQUFNLFFBQVE7TUFDakIsR0FBRyxNQUFNLFNBQVM7S0FDcEIsT0FBTyxJQUFJLFlBQVksU0FBUztNQUM5QixHQUFHLE1BQU0sYUFBYTtNQUN0QixHQUFHLE1BQU0sUUFBUTtNQUNqQixHQUFHLE1BQU0sU0FBUztLQUNwQjtLQUdBLElBQUksU0FBUyxXQUFXO01BQ3RCLGNBQWM7TUFDZCxtQkFBbUI7TUFDbkIsSUFBSSxTQUFTLGtCQUNYLG1CQUFtQixTQUFTO01BRTlCLFFBQVEsTUFBTSxVQUFVO01BQ3hCLGdCQUFnQixNQUFNLFVBQVU7TUFDaEMsa0JBQWtCLFFBQVE7TUFDMUI7S0FDRixPQUFPLElBQUksZ0JBQWdCLENBQUMsU0FBUyxZQUFZLFNBQVMsU0FBUyxVQUFVO01BQzNFLGNBQWM7TUFDZCxrQkFBa0I7TUFDbEIsT0FBTyxTQUFTLE9BQU87TUFDdkI7S0FDRixPQUFPLElBQUksYUFBYTtNQUV0QixrQkFBa0IsUUFBUTtNQUMxQjtLQUNGO0tBR0EsSUFBSSxTQUFTLGNBQWM7TUFDekIsbUJBQW1CO01BRW5CLE1BQU0sU0FBUyxTQUFTLG9CQUFvQjtNQUM1QyxtQkFBbUI7TUFHbkIsSUFBSSxPQUFPLFNBQVMsbUJBQW1CLFlBQVksU0FBUyxpQkFBaUIsR0FDdkU7V0FBQSxtQkFBbUIsS0FBSyxTQUFTLGtCQUFrQixnQkFBZ0I7UUFDckUsaUJBQWlCLFNBQVM7UUFDMUIsa0JBQWtCLGNBQWM7T0FDbEM7O01BSUYsSUFBSSxPQUFPLFNBQVMsd0JBQXdCLFlBQVksU0FBUyxzQkFBc0IsR0FDckYsc0JBQXNCLFNBQVM7V0FDMUIsSUFBSSxPQUFPLFNBQVMsb0JBQW9CLFlBQVksU0FBUyxrQkFBa0IsR0FDcEYsc0JBQXNCLFNBQVM7V0FFL0Isc0JBQXNCO01BRXhCLHVCQUF1QixtQkFBbUI7TUFPMUMsa0JBSEUsT0FBTyxTQUFTLG9CQUFvQixXQUNoQyxTQUFTLGtCQUNSLE9BQU8sU0FBUyxrQkFBa0IsV0FBVyxTQUFTLGdCQUFnQjtNQUU3RSxpQkFBaUIsZUFBZTtNQUdoQyxNQUFNLGFBQ0osT0FBTyxTQUFTLG9CQUFvQixZQUFZLFNBQVMsa0JBQWtCLElBQ3ZFLFNBQVMsa0JBQ1QsS0FBSyxJQUFJO01BQ2YsSUFBSSxPQUFPLFNBQVMsc0JBQXNCLFlBQVksU0FBUyxxQkFBcUIsR0FFOUU7V0FBQSxjQUFjLGlCQUFpQjtRQUNqQyxTQUE0QjtRQUM1QixrQkFBa0I7T0FDcEI7YUFDSztPQUNMLE1BQU0scUJBQ0osc0JBQXNCLEtBQUssU0FBUyxJQUNoQyxLQUFLLElBQUkscUJBQXFCLE1BQU0sSUFDcEM7T0FDTixNQUFNLFNBQ0oscUJBQXFCLElBQUksS0FBSyxJQUFJLEdBQUcsYUFBYSxrQkFBa0IsSUFBSTtPQUMxRSxNQUFNLFVBQVUsa0JBQWtCO09BQ2xDLEtBQXdCLE1BQU0sVUFBVSxHQUFJO09BQzVDLGtCQUFrQixhQUFjLFVBQVU7TUFDNUM7TUFFQSxJQUFJLFNBQVMsU0FBUyxTQUFTO09BQzdCLFFBQVEsY0FBYztPQUN0QixRQUFRLE1BQU0sa0JBQWtCO01BQ2xDLE9BQU87T0FDTCxRQUFRLGNBQWM7T0FDdEIsUUFBUSxNQUFNLGtCQUFrQjtNQUNsQztNQUVBLGtCQUFrQjtNQUNsQixRQUFRLE1BQU0sVUFBVTtNQUN4QixvQkFBb0I7S0FDdEIsT0FBTztNQUVMLG1CQUFtQjtNQUNuQixpQkFBaUI7TUFDakIsc0JBQXNCO01BQ3RCLGtCQUFrQjtNQUVsQixrQkFBa0I7TUFDbEIsa0JBQWtCLENBQUM7TUFDbkIsdUJBQXVCLENBQUM7TUFDeEIsaUJBQWlCLENBQUM7TUFDbEIsbUJBQW1CLENBQUM7TUFDcEIsZUFBZTtNQUNmLGVBQWU7TUFDZixRQUFRLE1BQU0sVUFBVTtNQUN4QixvQkFBb0I7S0FDdEI7SUFDRixTQUFTLE9BQU87S0FDZCxRQUFRLE1BQU0scUJBQXFCLEtBQUs7SUFDMUMsVUFBVTtLQUNSLFlBQVk7SUFDZDtHQUNGO0dBR0Esb0JBQXlCO0dBQ3pCLHlCQUE4QjtHQUM5QixTQUFjO0dBR2QsWUFBWSxxQkFBcUIsR0FBRztHQUdwQyxrQkFBa0I7SUFDaEIsU0FBYztHQUNoQixHQUFHLEdBQUk7R0FJUCxTQUFTLGlCQUFpQiwwQkFBMEI7SUFDbEQsU0FBYztHQUNoQixDQUFDO0dBR0QsTUFBTSx5QkFBeUI7SUFDN0IsU0FBYztHQUNoQjtHQUVBLE9BQU8saUJBQWlCLFlBQVksZ0JBQWdCO0dBR3BELE9BQU8saUJBQWlCLGFBQWEsVUFBVTtJQUM3QyxxQkFBcUI7SUFDckIsSUFBSSxNQUFNLFdBQVc7S0FDbkIsb0JBQXlCO0tBQ3pCLHlCQUE4QjtLQUM5QixTQUFjO0lBQ2hCO0dBQ0YsQ0FBQztHQUdELElBQUk7SUFDRixNQUFNLFdBQVcsUUFBUTtJQUN6QixRQUFRLFlBQVksU0FBeUIsR0FBRyxNQUF3QztLQUN0RixNQUFNLE1BQU0sU0FBUyxNQUFNLE1BQU0sSUFBSTtLQUNyQyxPQUFPLGNBQWMsSUFBSSxNQUFNLHVCQUF1QixDQUFDO0tBQ3ZELE9BQU87SUFDVDtJQUNBLE1BQU0sY0FBYyxRQUFRO0lBQzVCLFFBQVEsZUFBZSxTQUF5QixHQUFHLE1BQTJDO0tBQzVGLE1BQU0sTUFBTSxZQUFZLE1BQU0sTUFBTSxJQUFJO0tBQ3hDLE9BQU8sY0FBYyxJQUFJLE1BQU0sdUJBQXVCLENBQUM7S0FDdkQsT0FBTztJQUNUO0lBQ0EsT0FBTyxpQkFBaUIseUJBQXlCLGdCQUFnQjtHQUNuRSxRQUFRLENBQUM7R0FHVCxJQUFJLHFCQUFxQjtHQUN6QixNQUFNLHlCQUF5QjtJQUM3QixJQUFJLENBQUMsb0JBQW9CLG9CQUFvQjtJQUM3QyxxQkFBcUI7SUFDckIsSUFBSTtLQUNGLFFBQVEsUUFBUSxZQUFZO01BQzFCLFNBQVM7TUFDVDtNQUNBO0tBQ0YsQ0FBQztJQUNILFFBQVEsQ0FBQztHQUNYO0dBRUEsT0FBTyxpQkFBaUIsWUFBWSxnQkFBZ0I7R0FDcEQsT0FBTyxpQkFBaUIsZ0JBQWdCLGdCQUFnQjtHQUd4RCxRQUFRLFFBQVEsVUFBVSxhQUFhLFNBQVMsU0FBUztJQUN2RCxJQUFJLFNBQVMsU0FBUztJQUV0QixJQUNFLFFBQVEsWUFDUixRQUFRLFFBQ1IsUUFBUSxnQkFDUixRQUFRLG1CQUNSLFFBQVEsYUFDUixRQUFRLGVBQ1IsUUFBUSxrQkFDUjtLQUNBLElBQ0UsZ0JBQ0MsUUFBUSxVQUFVLGFBQWEsU0FDOUIsUUFBUSxNQUFNLGFBQWEsVUFDN0I7TUFDQSxjQUFjO01BQ2Qsa0JBQWtCO01BQ2xCLE9BQU8sU0FBUyxPQUFPO01BQ3ZCO0tBQ0Y7S0FFQSxJQUFJLFFBQVEsYUFBYSxPQUFPLFFBQVEsVUFBVSxhQUFhLFVBQVU7TUFDdkUsTUFBTSxXQUFXLFFBQVEsVUFBVSxXQUFXLElBQUksUUFBUSxVQUFVLFdBQVc7TUFDL0UsSUFBSSxhQUFhLGtCQUFrQjtPQUNqQyxtQkFBbUI7T0FFbkIsSUFBSSxXQUFXLEdBQUc7UUFDaEIsa0JBQWtCO1FBQ2xCLGlCQUFpQixDQUFDO1FBQ2xCLG1CQUFtQixDQUFDO1FBQ3BCLGlCQUFpQixnQkFBZ0IsV0FBVyxlQUFlO1FBQzNELGtCQUFrQixjQUFjO1FBQ2hDLHNCQUFzQjtRQUN0Qix1QkFBdUIsQ0FBQztRQUV4QixrQkFBa0I7UUFDbEIsZUFBZTtRQUNmLGVBQWU7UUFDZixpQkFBaUI7T0FDbkI7TUFDRjtLQUNGO0tBR0EsSUFBSSxRQUFRLG1CQUFtQixNQUFNLFFBQVEsUUFBUSxnQkFBZ0IsUUFBUSxHQUFHO01BQzlFLE1BQU0sV0FBcUIsUUFBUSxnQkFBZ0I7TUFDbkQsSUFBSSxDQUFDLGNBQWMsVUFBVSxRQUFRLEdBQUc7T0FDdEMsbUJBQW1CO09BQ25CLGlCQUFpQjtPQUNqQixzQkFBc0I7T0FDdEIsa0JBQWtCO09BRWxCLGtCQUFrQjtPQUNsQixrQkFBa0IsQ0FBQztPQUNuQix1QkFBdUIsQ0FBQztPQUN4QixpQkFBaUIsQ0FBQztPQUNsQixtQkFBbUIsQ0FBQztPQUNwQixlQUFlO09BQ2YsZUFBZTtPQUNmLFFBQVEsTUFBTSxVQUFVO01BQzFCO0tBQ0Y7S0FHQSxvQkFBeUI7S0FDekIseUJBQThCO0tBRzlCLElBQUksUUFBUSxVQUFVLGFBQWEsT0FBTztNQUN4QyxrQkFBa0IsQ0FBQztNQUNuQix1QkFBdUIsQ0FBQztNQUN4QixpQkFBaUIsQ0FBQztNQUNsQixtQkFBbUIsQ0FBQztNQUNwQixtQkFBbUI7TUFDbkIsaUJBQWlCO01BQ2pCLHNCQUFzQjtNQUN0QixrQkFBa0I7TUFFbEIsa0JBQWtCO01BQ2xCLG1CQUFtQjtNQUNuQixlQUFlO01BQ2YsZUFBZTtNQUNmLGlCQUFpQjtNQUNqQixRQUFRLE1BQU0sVUFBVTtLQUMxQjtLQUVBLFNBQWM7SUFDaEI7R0FDRixDQUFDO0VBQ0g7Q0FDRixDQUFDOzs7Q0N6NkNELFNBQVNDLFFBQU0sUUFBUSxHQUFHLE1BQU07RUFFL0IsSUFBSSxPQUFPLEtBQUssT0FBTyxVQUFVLE9BQU8sU0FBUyxLQUFLLE1BQU0sS0FBSyxHQUFHLElBQUk7T0FDbkUsT0FBTyxTQUFTLEdBQUcsSUFBSTtDQUM3Qjs7Q0FFQSxJQUFNQyxXQUFTO0VBQ2QsUUFBUSxHQUFHLFNBQVNELFFBQU0sUUFBUSxPQUFPLEdBQUcsSUFBSTtFQUNoRCxNQUFNLEdBQUcsU0FBU0EsUUFBTSxRQUFRLEtBQUssR0FBRyxJQUFJO0VBQzVDLE9BQU8sR0FBRyxTQUFTQSxRQUFNLFFBQVEsTUFBTSxHQUFHLElBQUk7RUFDOUMsUUFBUSxHQUFHLFNBQVNBLFFBQU0sUUFBUSxPQUFPLEdBQUcsSUFBSTtDQUNqRDs7O0NDVkEsSUFBSSx5QkFBeUIsTUFBTSwrQkFBK0IsTUFBTTtFQUN2RSxPQUFPLGFBQWEsbUJBQW1CLG9CQUFvQjtFQUMzRCxZQUFZLFFBQVEsUUFBUTtHQUMzQixNQUFNLHVCQUF1QixZQUFZLENBQUMsQ0FBQztHQUMzQyxLQUFLLFNBQVM7R0FDZCxLQUFLLFNBQVM7RUFDZjtDQUNEOzs7OztDQUtBLFNBQVMsbUJBQW1CLFdBQVc7RUFDdEMsT0FBTyxHQUFHLFNBQVMsU0FBUyxHQUFHLFdBQWlDO0NBQ2pFOzs7Q0NkQSxJQUFNLHdCQUF3QixPQUFPLFdBQVcsWUFBWSxxQkFBcUI7Ozs7OztDQU1qRixTQUFTLHNCQUFzQixLQUFLO0VBQ25DLElBQUk7RUFDSixJQUFJLFdBQVc7RUFDZixPQUFPLEVBQUUsTUFBTTtHQUNkLElBQUksVUFBVTtHQUNkLFdBQVc7R0FDWCxVQUFVLElBQUksSUFBSSxTQUFTLElBQUk7R0FDL0IsSUFBSSx1QkFBdUIsV0FBVyxXQUFXLGlCQUFpQixhQUFhLFVBQVU7SUFDeEYsTUFBTSxTQUFTLElBQUksSUFBSSxNQUFNLFlBQVksR0FBRztJQUM1QyxJQUFJLE9BQU8sU0FBUyxRQUFRLE1BQU07SUFDbEMsT0FBTyxjQUFjLElBQUksdUJBQXVCLFFBQVEsT0FBTyxDQUFDO0lBQ2hFLFVBQVU7R0FDWCxHQUFHLEVBQUUsUUFBUSxJQUFJLE9BQU8sQ0FBQztRQUNwQixJQUFJLGtCQUFrQjtJQUMxQixNQUFNLFNBQVMsSUFBSSxJQUFJLFNBQVMsSUFBSTtJQUNwQyxJQUFJLE9BQU8sU0FBUyxRQUFRLE1BQU07S0FDakMsT0FBTyxjQUFjLElBQUksdUJBQXVCLFFBQVEsT0FBTyxDQUFDO0tBQ2hFLFVBQVU7SUFDWDtHQUNELEdBQUcsR0FBRztFQUNQLEVBQUU7Q0FDSDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0NRQSxJQUFJLHVCQUF1QixNQUFNLHFCQUFxQjtFQUNyRCxPQUFPLDhCQUE4QixtQkFBbUIsNEJBQTRCO0VBQ3BGO0VBQ0E7RUFDQSxrQkFBa0Isc0JBQXNCLElBQUk7RUFDNUMsWUFBWSxtQkFBbUIsU0FBUztHQUN2QyxLQUFLLG9CQUFvQjtHQUN6QixLQUFLLFVBQVU7R0FDZixLQUFLLEtBQUssS0FBSyxPQUFPLENBQUMsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQztHQUM1QyxLQUFLLGtCQUFrQixJQUFJLGdCQUFnQjtHQUMzQyxLQUFLLGVBQWU7R0FDcEIsS0FBSyxzQkFBc0I7RUFDNUI7RUFDQSxJQUFJLFNBQVM7R0FDWixPQUFPLEtBQUssZ0JBQWdCO0VBQzdCO0VBQ0EsTUFBTSxRQUFRO0dBQ2IsT0FBTyxLQUFLLGdCQUFnQixNQUFNLE1BQU07RUFDekM7RUFDQSxJQUFJLFlBQVk7R0FDZixJQUFJLFFBQVEsU0FBUyxNQUFNLE1BQU0sS0FBSyxrQkFBa0I7R0FDeEQsT0FBTyxLQUFLLE9BQU87RUFDcEI7RUFDQSxJQUFJLFVBQVU7R0FDYixPQUFPLENBQUMsS0FBSztFQUNkOzs7Ozs7Ozs7Ozs7Ozs7RUFlQSxjQUFjLElBQUk7R0FDakIsS0FBSyxPQUFPLGlCQUFpQixTQUFTLEVBQUU7R0FDeEMsYUFBYSxLQUFLLE9BQU8sb0JBQW9CLFNBQVMsRUFBRTtFQUN6RDs7Ozs7Ozs7Ozs7O0VBWUEsUUFBUTtHQUNQLE9BQU8sSUFBSSxjQUFjLENBQUMsQ0FBQztFQUM1Qjs7Ozs7OztFQU9BLFlBQVksU0FBUyxTQUFTO0dBQzdCLE1BQU0sS0FBSyxrQkFBa0I7SUFDNUIsSUFBSSxLQUFLLFNBQVMsUUFBUTtHQUMzQixHQUFHLE9BQU87R0FDVixLQUFLLG9CQUFvQixjQUFjLEVBQUUsQ0FBQztHQUMxQyxPQUFPO0VBQ1I7Ozs7Ozs7RUFPQSxXQUFXLFNBQVMsU0FBUztHQUM1QixNQUFNLEtBQUssaUJBQWlCO0lBQzNCLElBQUksS0FBSyxTQUFTLFFBQVE7R0FDM0IsR0FBRyxPQUFPO0dBQ1YsS0FBSyxvQkFBb0IsYUFBYSxFQUFFLENBQUM7R0FDekMsT0FBTztFQUNSOzs7Ozs7OztFQVFBLHNCQUFzQixVQUFVO0dBQy9CLE1BQU0sS0FBSyx1QkFBdUIsR0FBRyxTQUFTO0lBQzdDLElBQUksS0FBSyxTQUFTLFNBQVMsR0FBRyxJQUFJO0dBQ25DLENBQUM7R0FDRCxLQUFLLG9CQUFvQixxQkFBcUIsRUFBRSxDQUFDO0dBQ2pELE9BQU87RUFDUjs7Ozs7Ozs7RUFRQSxvQkFBb0IsVUFBVSxTQUFTO0dBQ3RDLE1BQU0sS0FBSyxxQkFBcUIsR0FBRyxTQUFTO0lBQzNDLElBQUksQ0FBQyxLQUFLLE9BQU8sU0FBUyxTQUFTLEdBQUcsSUFBSTtHQUMzQyxHQUFHLE9BQU87R0FDVixLQUFLLG9CQUFvQixtQkFBbUIsRUFBRSxDQUFDO0dBQy9DLE9BQU87RUFDUjtFQUNBLGlCQUFpQixRQUFRLE1BQU0sU0FBUyxTQUFTO0dBQ2hELElBQUksU0FBUyxzQkFDUjtRQUFBLEtBQUssU0FBUyxLQUFLLGdCQUFnQixJQUFJO0dBQUE7R0FFNUMsT0FBTyxtQkFBbUIsS0FBSyxXQUFXLE1BQU0sSUFBSSxtQkFBbUIsSUFBSSxJQUFJLE1BQU0sU0FBUztJQUM3RixHQUFHO0lBQ0gsUUFBUSxLQUFLO0dBQ2QsQ0FBQztFQUNGOzs7OztFQUtBLG9CQUFvQjtHQUNuQixLQUFLLE1BQU0sb0NBQW9DO0dBQy9DLFNBQU8sTUFBTSxtQkFBbUIsS0FBSyxrQkFBa0Isc0JBQXNCO0VBQzlFO0VBQ0EsaUJBQWlCO0dBQ2hCLFNBQVMsY0FBYyxJQUFJLFlBQVkscUJBQXFCLDZCQUE2QixFQUFFLFFBQVE7SUFDbEcsbUJBQW1CLEtBQUs7SUFDeEIsV0FBVyxLQUFLO0dBQ2pCLEVBQUUsQ0FBQyxDQUFDO0dBQ0osSUFBSSxDQUFDLEtBQUssU0FBUyw0QkFBNEIsT0FBTyxZQUFZO0lBQ2pFLE1BQU0scUJBQXFCO0lBQzNCLG1CQUFtQixLQUFLO0lBQ3hCLFdBQVcsS0FBSztHQUNqQixHQUFHLEdBQUc7RUFDUDtFQUNBLHlCQUF5QixPQUFPO0dBQy9CLE1BQU0sc0JBQXNCLE1BQU0sUUFBUSxzQkFBc0IsS0FBSztHQUNyRSxNQUFNLGFBQWEsTUFBTSxRQUFRLGNBQWMsS0FBSztHQUNwRCxPQUFPLHVCQUF1QixDQUFDO0VBQ2hDO0VBQ0Esd0JBQXdCO0dBQ3ZCLE1BQU0sTUFBTSxVQUFVO0lBQ3JCLElBQUksRUFBRSxpQkFBaUIsZ0JBQWdCLENBQUMsS0FBSyx5QkFBeUIsS0FBSyxHQUFHO0lBQzlFLEtBQUssa0JBQWtCO0dBQ3hCO0dBQ0EsU0FBUyxpQkFBaUIscUJBQXFCLDZCQUE2QixFQUFFO0dBQzlFLEtBQUssb0JBQW9CLFNBQVMsb0JBQW9CLHFCQUFxQiw2QkFBNkIsRUFBRSxDQUFDO0VBQzVHO0NBQ0QifQ==