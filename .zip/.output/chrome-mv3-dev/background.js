var background = (function() {
	//#region node_modules/wxt/dist/utils/define-background.mjs
	function defineBackground(arg) {
		if (arg == null || typeof arg === "function") return { main: arg };
		return arg;
	}
	//#endregion
	//#region node_modules/wxt/dist/browser.mjs
	/**
	* Contains the `browser` export which you should use to access the extension
	* APIs in your project:
	*
	* ```ts
	* import { browser } from 'wxt/browser';
	*
	* browser.runtime.onInstalled.addListener(() => {
	*   // ...
	* });
	* ```
	*
	* @module wxt/browser
	*/
	var browser = globalThis.browser?.runtime?.id ? globalThis.browser : globalThis.chrome;
	//#endregion
	//#region entrypoints/background.ts
	var DEFAULT_BLOCKED_SITES = [];
	var DEFAULT_RESTRICTED_SITES = [];
	var THIRTY_DAYS_MS = 2592e6;
	var HEARTBEAT_TIMEOUT_MS = 6e4;
	function normalizeHost(host) {
		if (!host) return "";
		return host.trim().toLowerCase().replace(/^https?:\/\//, "").replace(/^www\./, "").replace(/[/?#].*$/, "").trim();
	}
	function findMatchingSite(hostname, sites) {
		const host = normalizeHost(hostname);
		if (!host) return null;
		const normalizedSites = sites.map((s) => normalizeHost(s)).filter(Boolean);
		const configuredTwitterAlias = normalizedSites.find((s) => s === "twitter.com" || s === "x.com");
		for (const domain of normalizedSites) {
			if (!domain) continue;
			if (host === domain || host.endsWith(`.${domain}`)) {
				if ((domain === "twitter.com" || domain === "x.com") && configuredTwitterAlias) return configuredTwitterAlias;
				return domain;
			}
		}
		if (configuredTwitterAlias) {
			if (host === "twitter.com" || host.endsWith(".twitter.com") || host === "x.com" || host.endsWith(".x.com")) return configuredTwitterAlias;
		}
		return null;
	}
	function safeExtractHost(urlStr) {
		if (!urlStr) return null;
		try {
			const parsed = new URL(urlStr);
			if (parsed.protocol !== "http:" && parsed.protocol !== "https:") return null;
			if (!parsed.hostname) return null;
			return normalizeHost(parsed.hostname);
		} catch {
			return null;
		}
	}
	function extractOpenDomains(tabs, sites) {
		const domains = /* @__PURE__ */ new Set();
		if (!Array.isArray(tabs) || !Array.isArray(sites)) return domains;
		for (const tab of tabs) {
			const host = safeExtractHost(tab.url);
			if (host) {
				const match = findMatchingSite(host, sites);
				if (match) domains.add(match);
			}
		}
		return domains;
	}
	function isVisitEligible(visit, now, openTabIds) {
		if (visit.tabId !== void 0 && openTabIds) return openTabIds.has(String(visit.tabId));
		if (visit.tabId !== void 0 && !openTabIds) return now - visit.lastHeartbeat <= HEARTBEAT_TIMEOUT_MS;
		return now - visit.lastHeartbeat <= HEARTBEAT_TIMEOUT_MS;
	}
	function hasEligibleVisitForDomain(activeVisits, domain, now, openTabIds, openDomains) {
		if (openDomains && openDomains.has(domain)) return true;
		return Object.values(activeVisits).some((v) => v.domain === domain && isVisitEligible(v, now, openTabIds));
	}
	function finalizeDomainSpan(domainSpans, usage, domain, now, fallbackTime, sessionStart) {
		const span = domainSpans[domain];
		if (!span) return false;
		const endTime = fallbackTime !== void 0 ? Math.max(span.startedAt, fallbackTime) : now;
		const effectiveStart = sessionStart && sessionStart > 0 ? Math.max(span.startedAt, sessionStart) : span.startedAt;
		const duration = Math.max(0, endTime - effectiveStart);
		if (duration > 0) usage[domain] = (usage[domain] ?? 0) + duration;
		delete domainSpans[domain];
		return true;
	}
	function finalizeVisit(activeVisits, domainSpans, usage, tabIdentifier, now, openTabIds, sessionStart, openDomains) {
		if (!tabIdentifier) return false;
		let changed = false;
		const domainsToRecheck = /* @__PURE__ */ new Set();
		for (const [key, visit] of Object.entries(activeVisits)) if (key === tabIdentifier || visit.instanceId === tabIdentifier || visit.tabId !== void 0 && String(visit.tabId) === tabIdentifier) {
			domainsToRecheck.add(visit.domain);
			delete activeVisits[key];
			changed = true;
		}
		for (const domain of domainsToRecheck) {
			const span = domainSpans[domain];
			if (span) {
				if (!hasEligibleVisitForDomain(activeVisits, domain, now, openTabIds, openDomains)) {
					finalizeDomainSpan(domainSpans, usage, domain, now, void 0, sessionStart);
					changed = true;
				} else span.tabKeys = Object.keys(activeVisits).filter((k) => {
					const v = activeVisits[k];
					return v !== void 0 && v.domain === domain && isVisitEligible(v, now, openTabIds);
				});
			}
		}
		return changed;
	}
	var stateQueue = Promise.resolve();
	function runSerial(task) {
		const result = stateQueue.then(() => task(), () => task());
		stateQueue = result.then(() => void 0, () => void 0);
		return result;
	}
	var background_default = defineBackground(() => {
		runSerial(async () => {
			try {
				const data = await browser.storage.local.get([
					"activeVisits",
					"sessionSiteUsage",
					"domainSpans",
					"isActive",
					"blockedSites",
					"restrictedSites"
				]);
				const updates = {};
				if (data.blockedSites === void 0) updates.blockedSites = [];
				else if (Array.isArray(data.blockedSites) && data.blockedSites.length === 2 && data.blockedSites.includes("x.com") && data.blockedSites.includes("twitter.com")) updates.blockedSites = [];
				if (data.restrictedSites === void 0) updates.restrictedSites = [];
				else if (Array.isArray(data.restrictedSites) && data.restrictedSites.length === 2 && data.restrictedSites.includes("youtube.com") && data.restrictedSites.includes("instagram.com")) updates.restrictedSites = [];
				if (data.activeVisits && Object.keys(data.activeVisits).length > 0) {
					const openTabs = await browser.tabs.query({});
					const openTabIds = new Set(openTabs.map((t) => String(t.id)));
					const openDomains = extractOpenDomains(openTabs, data.restrictedSites ?? []);
					const activeVisits = { ...data.activeVisits ?? {} };
					const usage = { ...data.sessionSiteUsage ?? {} };
					const domainSpans = { ...data.domainSpans ?? {} };
					const now = Date.now();
					let changed = false;
					for (const [tabKey, visit] of Object.entries(activeVisits)) {
						const tabIdStr = visit.tabId !== void 0 ? String(visit.tabId) : tabKey;
						if (!openTabIds.has(tabIdStr)) {
							finalizeVisit(activeVisits, domainSpans, usage, tabKey, visit.lastHeartbeat || now, openTabIds, void 0, openDomains);
							changed = true;
						}
					}
					for (const [domain, span] of Object.entries(domainSpans)) if (!hasEligibleVisitForDomain(activeVisits, domain, now, openTabIds, openDomains)) {
						finalizeDomainSpan(domainSpans, usage, domain, now, span.lastHeartbeat);
						changed = true;
					}
					if (changed) {
						updates.activeVisits = activeVisits;
						updates.sessionSiteUsage = usage;
						updates.domainSpans = domainSpans;
					}
				}
				if (Object.keys(updates).length > 0) await browser.storage.local.set(updates);
			} catch (e) {
				console.warn("Nudge startup cleanup & init error:", e);
			}
		});
		browser.runtime.onMessage.addListener((msg, sender) => runSerial(async () => {
			const now = Date.now();
			if (msg.message === "start_session") {
				if (msg.mode !== "block" && msg.mode !== "restrict") return {
					success: false,
					error: "Invalid session mode"
				};
				const stored = await browser.storage.local.get([
					"sessions",
					"blockedSites",
					"restrictedSites",
					"isActive"
				]);
				if (stored.isActive) return {
					success: false,
					error: "A session is already active"
				};
				const sessionUpdates = {
					isActive: true,
					mode: msg.mode,
					startedAt: now,
					activeVisits: {},
					sessionSiteUsage: {},
					domainSpans: {}
				};
				if (stored.blockedSites === void 0) sessionUpdates.blockedSites = DEFAULT_BLOCKED_SITES;
				if (stored.restrictedSites === void 0) sessionUpdates.restrictedSites = DEFAULT_RESTRICTED_SITES;
				await browser.storage.local.set(sessionUpdates);
				return {
					success: true,
					startedAt: now
				};
			}
			if (msg.message === "stop_session") {
				const data = await browser.storage.local.get([
					"isActive",
					"mode",
					"startedAt",
					"sessions",
					"activeVisits",
					"sessionSiteUsage",
					"domainSpans"
				]);
				if (!data.isActive || !data.startedAt) return {
					success: false,
					error: "No active session"
				};
				const usage = { ...data.sessionSiteUsage ?? {} };
				const domainSpans = { ...data.domainSpans ?? {} };
				for (const domain of Object.keys(domainSpans)) finalizeDomainSpan(domainSpans, usage, domain, now, now, data.startedAt);
				const record = {
					mode: data.mode ?? "",
					startedAt: data.startedAt,
					endedAt: now,
					duration: now - data.startedAt,
					siteUsage: usage
				};
				const cutoff = now - THIRTY_DAYS_MS;
				const sessions = [...data.sessions ?? [], record].filter((s) => s.startedAt >= cutoff);
				await browser.storage.local.set({
					isActive: false,
					startedAt: 0,
					mode: "",
					sessions,
					activeVisits: {},
					sessionSiteUsage: {},
					domainSpans: {}
				});
				return { success: true };
			}
			if (msg.message === "get_session") {
				const data = await browser.storage.local.get([
					"isActive",
					"startedAt",
					"mode"
				]);
				return {
					isActive: Boolean(data.isActive),
					startedAt: data.isActive && data.startedAt ? data.startedAt : 0,
					elapsedTime: data.isActive && data.startedAt ? Math.max(0, now - data.startedAt) : 0,
					mode: data.mode ?? ""
				};
			}
			if (msg.message === "check_site") {
				sender.tab?.id;
				const host = normalizeHost(msg.hostname ?? "");
				const data = await browser.storage.local.get([
					"blockedSites",
					"restrictedSites",
					"isActive",
					"mode",
					"startedAt",
					"activeVisits",
					"sessionSiteUsage",
					"domainSpans"
				]);
				if (!data.isActive) return {
					isActive: false,
					mode: "",
					sessionStartedAt: 0,
					isBlocked: false,
					isRestricted: false,
					visitStartedAt: 0,
					domainStartedAt: 0,
					domainSpanStartedAt: 0,
					baseSiteUsage: 0,
					baseSiteUsageMs: 0,
					baseSiteUsageSec: 0,
					totalSiteUsageSec: 0
				};
				const sessionStart = typeof data.startedAt === "number" && data.startedAt > 0 ? data.startedAt : now;
				if (!data.startedAt) await browser.storage.local.set({ startedAt: sessionStart });
				const blockedSites = data.blockedSites ?? [];
				const restrictedSites = data.restrictedSites ?? [];
				const blockedDomain = data.mode === "block" ? findMatchingSite(host, blockedSites) : null;
				const restrictedDomain = !blockedDomain ? findMatchingSite(host, restrictedSites) : null;
				if (blockedDomain) return {
					isActive: true,
					mode: data.mode ?? "",
					sessionStartedAt: sessionStart,
					isBlocked: true,
					isRestricted: false,
					visitStartedAt: 0,
					domainStartedAt: 0,
					domainSpanStartedAt: 0,
					baseSiteUsage: 0,
					baseSiteUsageMs: 0,
					baseSiteUsageSec: 0,
					totalSiteUsageSec: 0
				};
				const activeVisits = { ...data.activeVisits ?? {} };
				const usage = { ...data.sessionSiteUsage ?? {} };
				const domainSpans = { ...data.domainSpans ?? {} };
				const rawTabId = sender.tab?.id;
				const instanceId = msg.tabInstanceId || "";
				const isVisible = msg.isVisible !== false;
				const tabKey = rawTabId !== void 0 ? String(rawTabId) : instanceId || (host ? `tab_${host}` : "main_tab");
				let hasStateChange = false;
				if (rawTabId !== void 0 && instanceId) {
					for (const [k, v] of Object.entries(activeVisits)) if (k !== tabKey && (k === instanceId || v.tabId === void 0) && v.instanceId === instanceId) {
						delete activeVisits[k];
						hasStateChange = true;
					}
				}
				let openTabIds = /* @__PURE__ */ new Set();
				let openDomains = /* @__PURE__ */ new Set();
				try {
					const openTabs = await browser.tabs.query({});
					openTabIds = new Set(openTabs.map((t) => String(t.id)));
					openDomains = extractOpenDomains(openTabs, restrictedSites);
					if (rawTabId !== void 0 && openTabIds.size > 0 && !openTabIds.has(String(rawTabId))) return {
						isActive: true,
						mode: data.mode ?? "",
						sessionStartedAt: sessionStart,
						isBlocked: false,
						isRestricted: false,
						visitStartedAt: 0,
						domainStartedAt: 0,
						domainSpanStartedAt: 0,
						baseSiteUsage: 0,
						baseSiteUsageMs: 0,
						baseSiteUsageSec: 0,
						totalSiteUsageSec: 0
					};
					for (const [k, v] of Object.entries(activeVisits)) {
						const vTabId = v.tabId !== void 0 ? String(v.tabId) : k;
						if (k !== tabKey && v.tabId !== void 0 && !openTabIds.has(vTabId)) {
							finalizeVisit(activeVisits, domainSpans, usage, k, v.lastHeartbeat || now, openTabIds, sessionStart, openDomains);
							hasStateChange = true;
						}
					}
				} catch {}
				for (const [k, v] of Object.entries(activeVisits)) {
					if (k === tabKey) continue;
					const vTabId = v.tabId !== void 0 ? String(v.tabId) : k;
					const isOpenTab = v.tabId !== void 0 && openTabIds.has(vTabId);
					if (!isOpenTab && now - v.lastHeartbeat > 6e4) {
						finalizeVisit(activeVisits, domainSpans, usage, k, v.lastHeartbeat || now, openTabIds, sessionStart, openDomains);
						hasStateChange = true;
					} else if (isOpenTab && now - v.lastHeartbeat > 6e4) {
						if (v.isVisible) {
							v.isVisible = false;
							hasStateChange = true;
						}
					}
				}
				for (const [domain, span] of Object.entries(domainSpans)) if (!hasEligibleVisitForDomain(activeVisits, domain, now, openTabIds, openDomains)) {
					finalizeDomainSpan(domainSpans, usage, domain, now, span.lastHeartbeat, sessionStart);
					hasStateChange = true;
				}
				let existing = activeVisits[tabKey];
				if (existing && existing.startedAt < sessionStart) {
					delete activeVisits[tabKey];
					existing = void 0;
				}
				if (restrictedDomain) {
					const staleSpan = domainSpans[restrictedDomain];
					if (staleSpan && staleSpan.startedAt < sessionStart) {
						delete domainSpans[restrictedDomain];
						hasStateChange = true;
					}
				}
				if (existing && existing.domain !== restrictedDomain) {
					if (finalizeVisit(activeVisits, domainSpans, usage, tabKey, now, openTabIds, sessionStart, openDomains)) hasStateChange = true;
				}
				if (restrictedDomain) {
					const isTabContinuing = existing !== void 0 && existing.domain === restrictedDomain && existing.startedAt >= sessionStart;
					let currentVisit;
					if (!isTabContinuing || !existing) {
						if (existing) finalizeVisit(activeVisits, domainSpans, usage, tabKey, existing.lastHeartbeat || now, openTabIds, sessionStart, openDomains);
						const isInheritedFromSibling = typeof msg.tabVisitStartedAt === "number" && Object.values(activeVisits).some((v) => v.startedAt === msg.tabVisitStartedAt && (rawTabId === void 0 || v.tabId !== rawTabId));
						currentVisit = {
							domain: restrictedDomain,
							hostname: host,
							tabId: rawTabId,
							instanceId,
							startedAt: typeof msg.tabVisitStartedAt === "number" && msg.tabVisitStartedAt >= sessionStart && msg.tabVisitStartedAt <= now && !isInheritedFromSibling && typeof msg.tabVisitStartedAt === "number" ? msg.tabVisitStartedAt : Math.max(now, sessionStart),
							lastHeartbeat: now,
							isVisible
						};
						activeVisits[tabKey] = currentVisit;
						hasStateChange = true;
					} else {
						currentVisit = existing;
						currentVisit.lastHeartbeat = now;
						currentVisit.isVisible = isVisible;
						if (instanceId) currentVisit.instanceId = instanceId;
						if (rawTabId !== void 0 && currentVisit.tabId === void 0) {
							currentVisit.tabId = rawTabId;
							hasStateChange = true;
						}
					}
					let span = domainSpans[restrictedDomain];
					if (!span) {
						span = {
							startedAt: (usage[restrictedDomain] ?? 0) > 0 ? Math.max(now, sessionStart) : Math.max(sessionStart, currentVisit.startedAt),
							tabKeys: [tabKey],
							lastHeartbeat: now
						};
						domainSpans[restrictedDomain] = span;
						hasStateChange = true;
					} else {
						span.lastHeartbeat = now;
						if (!span.tabKeys.includes(tabKey)) {
							span.tabKeys.push(tabKey);
							hasStateChange = true;
						}
					}
					await browser.storage.local.set({
						activeVisits,
						sessionSiteUsage: usage,
						domainSpans
					});
					const snapshotNow = Date.now();
					currentVisit.lastHeartbeat = snapshotNow;
					span.lastHeartbeat = snapshotNow;
					const effectiveSpanStart = Math.max(span.startedAt, sessionStart);
					const activeDuration = Math.max(0, snapshotNow - effectiveSpanStart);
					const rawTotalDuration = (usage[restrictedDomain] ?? 0) + activeDuration;
					const maxSessionMs = Math.max(0, snapshotNow - sessionStart);
					const totalDurationMs = Math.min(maxSessionMs, rawTotalDuration);
					const totalSiteUsageSec = Math.floor(totalDurationMs / 1e3);
					const usageSnapshotAt = snapshotNow - totalDurationMs % 1e3;
					return {
						isActive: true,
						mode: data.mode ?? "",
						sessionStartedAt: sessionStart,
						isBlocked: false,
						isRestricted: true,
						domain: restrictedDomain,
						tabId: rawTabId,
						visitStartedAt: currentVisit.startedAt,
						domainSpanStartedAt: span.startedAt,
						domainStartedAt: span.startedAt,
						baseSiteUsage: usage[restrictedDomain] ?? 0,
						baseSiteUsageMs: usage[restrictedDomain] ?? 0,
						baseSiteUsageSec: Math.floor((usage[restrictedDomain] ?? 0) / 1e3),
						totalSiteUsageSec,
						totalSiteUsageMs: totalDurationMs,
						usageSnapshotAt
					};
				}
				if (hasStateChange) await browser.storage.local.set({
					activeVisits,
					sessionSiteUsage: usage,
					domainSpans
				});
				return {
					isActive: true,
					mode: data.mode ?? "",
					sessionStartedAt: sessionStart,
					isBlocked: false,
					isRestricted: false,
					visitStartedAt: 0,
					domainStartedAt: 0,
					domainSpanStartedAt: 0,
					baseSiteUsage: 0,
					baseSiteUsageMs: 0,
					baseSiteUsageSec: 0,
					totalSiteUsageSec: 0
				};
			}
			if (msg.message === "tab_leaving") {
				const rawTabId = sender.tab?.id;
				const instanceId = msg.tabInstanceId || "";
				const tabIdentifier = rawTabId !== void 0 ? String(rawTabId) : instanceId;
				const data = await browser.storage.local.get([
					"activeVisits",
					"sessionSiteUsage",
					"domainSpans",
					"isActive",
					"startedAt"
				]);
				if (!data.isActive) return { success: true };
				const activeVisits = { ...data.activeVisits ?? {} };
				const usage = { ...data.sessionSiteUsage ?? {} };
				const domainSpans = { ...data.domainSpans ?? {} };
				const sessionStart = data.startedAt && data.startedAt > 0 ? data.startedAt : now;
				let isTabStillOpen = false;
				if (rawTabId !== void 0) try {
					const tab = await browser.tabs.get(rawTabId);
					isTabStillOpen = Boolean(tab);
				} catch {
					isTabStillOpen = false;
				}
				let changed = false;
				let openTabIds;
				let openDomains;
				try {
					const openTabs = await browser.tabs.query({});
					openTabIds = new Set(openTabs.map((t) => String(t.id)));
					openDomains = extractOpenDomains(openTabs, data.restrictedSites ?? []);
				} catch {}
				if (!isTabStillOpen) {
					if (tabIdentifier) {
						if (finalizeVisit(activeVisits, domainSpans, usage, tabIdentifier, now, openTabIds, sessionStart, openDomains)) changed = true;
					}
				} else for (const [key, visit] of Object.entries(activeVisits)) if (key === tabIdentifier || visit.tabId !== void 0 && String(visit.tabId) === tabIdentifier) visit.lastHeartbeat = now;
				for (const [domain, span] of Object.entries(domainSpans)) if (!hasEligibleVisitForDomain(activeVisits, domain, now, openTabIds, openDomains)) {
					finalizeDomainSpan(domainSpans, usage, domain, now, span.lastHeartbeat, sessionStart);
					changed = true;
				}
				if (changed) await browser.storage.local.set({
					activeVisits,
					sessionSiteUsage: usage,
					domainSpans
				});
				return { success: true };
			}
			if (msg.message === "get_site_usage") {
				const host = normalizeHost(msg.hostname ?? "");
				const data = await browser.storage.local.get([
					"restrictedSites",
					"sessionSiteUsage",
					"domainSpans"
				]);
				const matchedDomain = findMatchingSite(host, data.restrictedSites ?? []) ?? host;
				const usage = data.sessionSiteUsage ?? {};
				const span = (data.domainSpans ?? {})[matchedDomain];
				const activeDuration = span ? Math.max(0, now - span.startedAt) : 0;
				return { totalDuration: (usage[matchedDomain] ?? 0) + activeDuration };
			}
			if (msg.message === "open_dashboard") {
				const url = browser.runtime.getURL("/dashboard.html");
				await browser.tabs.create({ url });
				return { success: true };
			}
			if (msg.message === "close_current_tab") {
				if (sender.tab?.id !== void 0) await browser.tabs.remove(sender.tab.id);
				return { success: true };
			}
		}));
		browser.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
			const candidateUrl = changeInfo.url || tab.url;
			if (!candidateUrl) return;
			const topHost = safeExtractHost(candidateUrl);
			if (!topHost) return;
			runSerial(async () => {
				const data = await browser.storage.local.get([
					"activeVisits",
					"sessionSiteUsage",
					"domainSpans",
					"restrictedSites",
					"isActive",
					"startedAt"
				]);
				if (!data.isActive) return;
				const tabKey = String(tabId);
				const activeVisits = { ...data.activeVisits ?? {} };
				const visitKey = Object.keys(activeVisits).find((k) => k === tabKey || activeVisits[k]?.tabId === tabId);
				if (!visitKey) return;
				const visit = activeVisits[visitKey];
				if (!visit) return;
				const restrictedSites = data.restrictedSites ?? [];
				if (findMatchingSite(topHost, restrictedSites) !== visit.domain) {
					const usage = { ...data.sessionSiteUsage ?? {} };
					const domainSpans = { ...data.domainSpans ?? {} };
					const now = Date.now();
					const sessionStart = data.startedAt && data.startedAt > 0 ? data.startedAt : now;
					let openTabIds;
					let openDomains;
					try {
						const openTabs = await browser.tabs.query({});
						openTabIds = new Set(openTabs.map((t) => String(t.id)));
						openDomains = extractOpenDomains(openTabs, restrictedSites);
					} catch {}
					if (finalizeVisit(activeVisits, domainSpans, usage, visitKey, now, openTabIds, sessionStart, openDomains)) await browser.storage.local.set({
						activeVisits,
						sessionSiteUsage: usage,
						domainSpans
					});
				}
			});
		});
		browser.tabs.onRemoved.addListener((tabId) => runSerial(async () => {
			const data = await browser.storage.local.get([
				"activeVisits",
				"sessionSiteUsage",
				"domainSpans",
				"isActive",
				"startedAt",
				"restrictedSites"
			]);
			if (!data.isActive) return;
			const tabKey = String(tabId);
			const activeVisits = { ...data.activeVisits ?? {} };
			const usage = { ...data.sessionSiteUsage ?? {} };
			const domainSpans = { ...data.domainSpans ?? {} };
			const now = Date.now();
			const sessionStart = data.startedAt && data.startedAt > 0 ? data.startedAt : now;
			let openTabIds = /* @__PURE__ */ new Set();
			let openDomains = /* @__PURE__ */ new Set();
			try {
				const openTabs = await browser.tabs.query({});
				openTabIds = new Set(openTabs.map((t) => String(t.id)));
				openDomains = extractOpenDomains(openTabs, data.restrictedSites ?? []);
			} catch {}
			let changed = finalizeVisit(activeVisits, domainSpans, usage, tabKey, now, openTabIds, sessionStart, openDomains);
			try {
				for (const [key, visit] of Object.entries(activeVisits)) {
					const vTabId = visit.tabId !== void 0 ? String(visit.tabId) : key;
					if (!openTabIds.has(vTabId)) {
						if (finalizeVisit(activeVisits, domainSpans, usage, key, now, openTabIds, sessionStart, openDomains)) changed = true;
					}
				}
				for (const [domain, span] of Object.entries(domainSpans)) if (!hasEligibleVisitForDomain(activeVisits, domain, now, openTabIds, openDomains)) {
					finalizeDomainSpan(domainSpans, usage, domain, now, span.lastHeartbeat, sessionStart);
					changed = true;
				}
			} catch (err) {
				console.warn("Reconcile error in onRemoved:", err);
			}
			if (changed) await browser.storage.local.set({
				activeVisits,
				sessionSiteUsage: usage,
				domainSpans
			});
		}));
		browser.tabs.onActivated.addListener((activeInfo) => runSerial(async () => {
			const data = await browser.storage.local.get(["activeVisits", "isActive"]);
			if (!data.isActive) return;
			const activeVisits = { ...data.activeVisits ?? {} };
			const now = Date.now();
			let changed = false;
			const activatedTabKey = String(activeInfo.tabId);
			for (const [key, visit] of Object.entries(activeVisits)) if (key === activatedTabKey || visit.tabId === activeInfo.tabId) {
				if (!visit.isVisible) {
					visit.isVisible = true;
					visit.lastHeartbeat = now;
					changed = true;
				}
			} else if (visit.isVisible) {
				visit.isVisible = false;
				changed = true;
			}
			if (changed) await browser.storage.local.set({ activeVisits });
		}));
		browser.storage.onChanged.addListener((changes, area) => {
			if (area !== "local") return;
			const restrictedSitesChange = changes.restrictedSites;
			if (restrictedSitesChange) runSerial(async () => {
				const data = await browser.storage.local.get([
					"activeVisits",
					"sessionSiteUsage",
					"domainSpans",
					"isActive",
					"startedAt"
				]);
				if (!data.isActive) return;
				const newRestrictedSites = Array.isArray(restrictedSitesChange.newValue) ? restrictedSitesChange.newValue : [];
				const activeVisits = { ...data.activeVisits ?? {} };
				const usage = { ...data.sessionSiteUsage ?? {} };
				const domainSpans = { ...data.domainSpans ?? {} };
				const now = Date.now();
				const sessionStart = data.startedAt && data.startedAt > 0 ? data.startedAt : now;
				let changed = false;
				for (const [key, visit] of Object.entries(activeVisits)) if (!findMatchingSite(visit.domain, newRestrictedSites)) {
					finalizeVisit(activeVisits, domainSpans, usage, key, now);
					changed = true;
				}
				for (const [domain, span] of Object.entries(domainSpans)) if (!findMatchingSite(domain, newRestrictedSites)) {
					finalizeDomainSpan(domainSpans, usage, domain, now, now, sessionStart);
					changed = true;
				}
				if (changed) await browser.storage.local.set({
					activeVisits,
					sessionSiteUsage: usage,
					domainSpans
				});
			});
		});
	});
	//#endregion
	//#region node_modules/@webext-core/match-patterns/dist/index.mjs
	/**
	* Class for parsing and performing operations on match patterns.
	*
	* @example
	*   const pattern = new MatchPattern('*://google.com/*');
	*
	*   pattern.includes('https://google.com'); // true
	*   pattern.includes('http://youtube.com/watch?v=123'); // false
	*/
	var MatchPattern = class MatchPattern {
		static {
			this.PROTOCOLS = [
				"http",
				"https",
				"file",
				"ftp",
				"urn",
				"ws",
				"wss"
			];
		}
		/**
		* Parse a match pattern string. If it is invalid, the constructor will throw an
		* `InvalidMatchPattern` error.
		*
		* @param matchPattern The match pattern to parse.
		*/
		constructor(matchPattern) {
			if (matchPattern === "<all_urls>") {
				this.isAllUrls = true;
				this.protocolMatches = [...MatchPattern.PROTOCOLS];
				this.hostnameMatch = "*";
				this.pathnameMatch = "*";
			} else {
				const groups = /(.*):\/\/(.*?)(\/.*)/.exec(matchPattern);
				if (groups == null) throw new InvalidMatchPattern(matchPattern, "Incorrect format");
				const [_, protocol, hostname, pathname] = groups;
				validateProtocol(matchPattern, protocol);
				validateHostname(matchPattern, hostname);
				this.protocolMatches = protocol === "*" ? ["http", "https"] : [protocol];
				this.hostnameMatch = hostname;
				this.pathnameMatch = pathname;
			}
		}
		/** Check if a URL is included in a pattern. */
		includes(url) {
			const u = typeof url === "string" ? new URL(url) : url instanceof Location ? new URL(url.href) : url;
			if (this.isAllUrls) return !this.isUnknownProtocol(u);
			return !!this.protocolMatches.find((protocol) => {
				if (protocol === "http") return this.isHttpMatch(u);
				if (protocol === "https") return this.isHttpsMatch(u);
				if (protocol === "file") return this.isFileMatch(u);
				if (protocol === "ftp") return this.isFtpMatch(u);
				if (protocol === "urn") return this.isUrnMatch(u);
			});
		}
		isHttpMatch(url) {
			return url.protocol === "http:" && this.isHostPathMatch(url);
		}
		isHttpsMatch(url) {
			return url.protocol === "https:" && this.isHostPathMatch(url);
		}
		isHostPathMatch(url) {
			if (!this.hostnameMatch || !this.pathnameMatch) return false;
			const hostnameMatchRegexs = [this.convertPatternToRegex(this.hostnameMatch), this.convertPatternToRegex(this.hostnameMatch.replace(/^\*\./, ""))];
			const pathnameMatchRegex = this.convertPatternToRegex(this.pathnameMatch);
			return !!hostnameMatchRegexs.find((regex) => regex.test(url.hostname)) && pathnameMatchRegex.test(url.pathname);
		}
		isUnknownProtocol(url) {
			return !this.protocolMatches.includes(url.protocol.slice(0, -1));
		}
		isPathMatch(url) {
			if (!this.pathnameMatch) return false;
			return this.convertPatternToRegex(this.pathnameMatch).test(url.pathname);
		}
		isFileMatch(url) {
			return url.protocol === "file:" && this.isPathMatch(url);
		}
		isFtpMatch(_url) {
			throw Error("Not implemented: ftp:// pattern matching. Open a PR to add support");
		}
		isUrnMatch(_url) {
			throw Error("Not implemented: urn:// pattern matching. Open a PR to add support");
		}
		convertPatternToRegex(pattern) {
			const starsReplaced = this.escapeForRegex(pattern).replace(/\\\*/g, ".*");
			return RegExp(`^${starsReplaced}$`);
		}
		escapeForRegex(string) {
			return string.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
		}
	};
	var InvalidMatchPattern = class extends Error {
		constructor(matchPattern, reason) {
			super(`Invalid match pattern "${matchPattern}": ${reason}`);
		}
	};
	function validateProtocol(matchPattern, protocol) {
		if (!MatchPattern.PROTOCOLS.includes(protocol) && protocol !== "*") throw new InvalidMatchPattern(matchPattern, `${protocol} not a valid protocol (${MatchPattern.PROTOCOLS.join(", ")})`);
	}
	function validateHostname(matchPattern, hostname) {
		if (hostname.includes(":")) throw new InvalidMatchPattern(matchPattern, `Hostname cannot include a port`);
		if (hostname.includes("*") && hostname.length > 1 && !hostname.startsWith("*.")) throw new InvalidMatchPattern(matchPattern, `If using a wildcard (*), it must go at the start of the hostname`);
	}
	//#endregion
	//#region \0virtual:wxt-background-entrypoint?C:/Users/Deepti/Downloads/Projects/Nudge/entrypoints/background.ts
	function print(method, ...args) {
		if (typeof args[0] === "string") method(`[wxt] ${args.shift()}`, ...args);
		else method("[wxt]", ...args);
	}
	/** Wrapper around `console` with a "[wxt]" prefix */
	var logger = {
		debug: (...args) => print(console.debug, ...args),
		log: (...args) => print(console.log, ...args),
		warn: (...args) => print(console.warn, ...args),
		error: (...args) => print(console.error, ...args)
	};
	var ws;
	/** Connect to the websocket and listen for messages. */
	function getDevServerWebSocket() {
		if (ws == null) {
			const serverUrl = "ws://localhost:3000";
			logger.debug("Connecting to dev server @", serverUrl);
			ws = new WebSocket(serverUrl, "vite-hmr");
			ws.addWxtEventListener = ws.addEventListener.bind(ws);
			ws.sendCustom = (event, payload) => ws?.send(JSON.stringify({
				type: "custom",
				event,
				payload
			}));
			ws.addEventListener("open", () => {
				logger.debug("Connected to dev server");
			});
			ws.addEventListener("close", () => {
				logger.debug("Disconnected from dev server");
			});
			ws.addEventListener("error", (event) => {
				logger.error("Failed to connect to dev server", event);
			});
			ws.addEventListener("message", (e) => {
				try {
					const message = JSON.parse(e.data);
					if (message.type === "custom") ws?.dispatchEvent(new CustomEvent(message.event, { detail: message.data }));
				} catch (err) {
					logger.error("Failed to handle message", err);
				}
			});
		}
		return ws;
	}
	/** https://developer.chrome.com/blog/longer-esw-lifetimes/ */
	function keepServiceWorkerAlive() {
		setInterval(async () => {
			await browser.runtime.getPlatformInfo();
		}, 5e3);
	}
	function reloadContentScript(payload) {
		if (browser.runtime.getManifest().manifest_version == 2) reloadContentScriptMv2(payload);
		else reloadContentScriptMv3(payload);
	}
	async function reloadContentScriptMv3({ registration, contentScript }) {
		if (registration === "runtime") await reloadRuntimeContentScriptMv3(contentScript);
		else await reloadManifestContentScriptMv3(contentScript);
	}
	async function reloadManifestContentScriptMv3(contentScript) {
		const id = `wxt:${contentScript.js[0]}`;
		logger.log("Reloading content script:", contentScript);
		const registered = await browser.scripting.getRegisteredContentScripts();
		logger.debug("Existing scripts:", registered);
		const existing = registered.find((cs) => cs.id === id);
		if (existing) {
			logger.debug("Updating content script", existing);
			await browser.scripting.updateContentScripts([{
				...contentScript,
				id,
				css: contentScript.css ?? []
			}]);
		} else {
			logger.debug("Registering new content script...");
			await browser.scripting.registerContentScripts([{
				...contentScript,
				id,
				css: contentScript.css ?? []
			}]);
		}
		await reloadTabsForContentScript(contentScript);
	}
	async function reloadRuntimeContentScriptMv3(contentScript) {
		logger.log("Reloading content script:", contentScript);
		const registered = await browser.scripting.getRegisteredContentScripts();
		logger.debug("Existing scripts:", registered);
		const matches = registered.filter((cs) => {
			const hasJs = contentScript.js?.find((js) => cs.js?.includes(js));
			const hasCss = contentScript.css?.find((css) => cs.css?.includes(css));
			return hasJs || hasCss;
		});
		if (matches.length === 0) {
			logger.log("Content script is not registered yet, nothing to reload", contentScript);
			return;
		}
		await browser.scripting.updateContentScripts(matches);
		await reloadTabsForContentScript(contentScript);
	}
	async function reloadTabsForContentScript(contentScript) {
		const allTabs = await browser.tabs.query({});
		const matchPatterns = contentScript.matches.map((match) => new MatchPattern(match));
		const matchingTabs = allTabs.filter((tab) => {
			const url = tab.url;
			if (!url) return false;
			return !!matchPatterns.find((pattern) => pattern.includes(url));
		});
		await Promise.all(matchingTabs.map(async (tab) => {
			try {
				await browser.tabs.reload(tab.id);
			} catch (err) {
				logger.warn("Failed to reload tab:", err);
			}
		}));
	}
	async function reloadContentScriptMv2(_payload) {
		throw Error("TODO: reloadContentScriptMv2");
	}
	try {
		const ws = getDevServerWebSocket();
		ws.addWxtEventListener("wxt:reload-extension", () => {
			browser.runtime.reload();
		});
		ws.addWxtEventListener("wxt:reload-content-script", (event) => {
			reloadContentScript(event.detail);
		});
		ws.addEventListener("open", () => ws.sendCustom("wxt:background-initialized"));
		keepServiceWorkerAlive();
	} catch (err) {
		logger.error("Failed to setup web socket connection with dev server", err);
	}
	browser.commands.onCommand.addListener((command) => {
		if (command === "wxt:reload-extension") browser.runtime.reload();
	});
	var result;
	try {
		result = background_default.main();
		if (result instanceof Promise) console.warn("The background's main() function return a promise, but it must be synchronous");
	} catch (err) {
		logger.error("The background crashed on startup!");
		throw err;
	}
	//#endregion
	return result;
})();

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYmFja2dyb3VuZC5qcyIsIm5hbWVzIjpbImJyb3dzZXIiLCJiYWNrZ3JvdW5kX2VudHJ5cG9pbnRfZGVmYXVsdCJdLCJzb3VyY2VzIjpbIi4uLy4uL25vZGVfbW9kdWxlcy93eHQvZGlzdC91dGlscy9kZWZpbmUtYmFja2dyb3VuZC5tanMiLCIuLi8uLi9ub2RlX21vZHVsZXMvQHd4dC1kZXYvYnJvd3Nlci9zcmMvaW5kZXgubWpzIiwiLi4vLi4vbm9kZV9tb2R1bGVzL3d4dC9kaXN0L2Jyb3dzZXIubWpzIiwiLi4vLi4vZW50cnlwb2ludHMvYmFja2dyb3VuZC50cyIsIi4uLy4uL25vZGVfbW9kdWxlcy9Ad2ViZXh0LWNvcmUvbWF0Y2gtcGF0dGVybnMvZGlzdC9pbmRleC5tanMiXSwic291cmNlc0NvbnRlbnQiOlsiLy8jcmVnaW9uIHNyYy91dGlscy9kZWZpbmUtYmFja2dyb3VuZC50c1xuZnVuY3Rpb24gZGVmaW5lQmFja2dyb3VuZChhcmcpIHtcblx0aWYgKGFyZyA9PSBudWxsIHx8IHR5cGVvZiBhcmcgPT09IFwiZnVuY3Rpb25cIikgcmV0dXJuIHsgbWFpbjogYXJnIH07XG5cdHJldHVybiBhcmc7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IGRlZmluZUJhY2tncm91bmQgfTtcbiIsIi8vICNyZWdpb24gc25pcHBldFxuZXhwb3J0IGNvbnN0IGJyb3dzZXIgPSBnbG9iYWxUaGlzLmJyb3dzZXI/LnJ1bnRpbWU/LmlkXG4gID8gZ2xvYmFsVGhpcy5icm93c2VyXG4gIDogZ2xvYmFsVGhpcy5jaHJvbWU7XG4vLyAjZW5kcmVnaW9uIHNuaXBwZXRcbiIsImltcG9ydCB7IGJyb3dzZXIgYXMgYnJvd3NlciQxIH0gZnJvbSBcIkB3eHQtZGV2L2Jyb3dzZXJcIjtcbi8vI3JlZ2lvbiBzcmMvYnJvd3Nlci50c1xuLyoqXG4qIENvbnRhaW5zIHRoZSBgYnJvd3NlcmAgZXhwb3J0IHdoaWNoIHlvdSBzaG91bGQgdXNlIHRvIGFjY2VzcyB0aGUgZXh0ZW5zaW9uXG4qIEFQSXMgaW4geW91ciBwcm9qZWN0OlxuKlxuKiBgYGB0c1xuKiBpbXBvcnQgeyBicm93c2VyIH0gZnJvbSAnd3h0L2Jyb3dzZXInO1xuKlxuKiBicm93c2VyLnJ1bnRpbWUub25JbnN0YWxsZWQuYWRkTGlzdGVuZXIoKCkgPT4ge1xuKiAgIC8vIC4uLlxuKiB9KTtcbiogYGBgXG4qXG4qIEBtb2R1bGUgd3h0L2Jyb3dzZXJcbiovXG5jb25zdCBicm93c2VyID0gYnJvd3NlciQxO1xuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBicm93c2VyIH07XG4iLCIvLyBOdWRnZSBCYWNrZ3JvdW5kIFNlcnZpY2UgV29ya2VyIChNYW5pZmVzdCBWMylcbmludGVyZmFjZSBNZXNzYWdlIHtcbiAgbWVzc2FnZTogc3RyaW5nO1xuICBtb2RlPzogc3RyaW5nO1xuICBob3N0bmFtZT86IHN0cmluZztcbiAgdGFiSW5zdGFuY2VJZD86IHN0cmluZztcbiAgdGFiVmlzaXRTdGFydGVkQXQ/OiBudW1iZXI7XG4gIGlzVmlzaWJsZT86IGJvb2xlYW47XG59XG5cbmludGVyZmFjZSBBY3RpdmVWaXNpdCB7XG4gIGRvbWFpbjogc3RyaW5nO1xuICBob3N0bmFtZTogc3RyaW5nO1xuICBzdGFydGVkQXQ6IG51bWJlcjtcbiAgbGFzdEhlYXJ0YmVhdDogbnVtYmVyO1xuICB0YWJJZD86IG51bWJlcjtcbiAgaW5zdGFuY2VJZD86IHN0cmluZztcbiAgaXNWaXNpYmxlPzogYm9vbGVhbjtcbn1cblxuaW50ZXJmYWNlIERvbWFpblNwYW4ge1xuICBzdGFydGVkQXQ6IG51bWJlcjtcbiAgdGFiS2V5czogc3RyaW5nW107XG4gIGxhc3RIZWFydGJlYXQ/OiBudW1iZXI7XG59XG5cbmludGVyZmFjZSBTZXNzaW9uUmVjb3JkIHtcbiAgbW9kZTogc3RyaW5nO1xuICBzdGFydGVkQXQ6IG51bWJlcjtcbiAgZW5kZWRBdDogbnVtYmVyO1xuICBkdXJhdGlvbjogbnVtYmVyO1xuICBzaXRlVXNhZ2U6IFJlY29yZDxzdHJpbmcsIG51bWJlcj47XG59XG5cbmludGVyZmFjZSBCYWNrZ3JvdW5kRGF0YSB7XG4gIGlzQWN0aXZlPzogYm9vbGVhbjtcbiAgbW9kZT86IHN0cmluZztcbiAgc3RhcnRlZEF0PzogbnVtYmVyO1xuICBzZXNzaW9ucz86IFNlc3Npb25SZWNvcmRbXTtcbiAgYmxvY2tlZFNpdGVzPzogc3RyaW5nW107XG4gIHJlc3RyaWN0ZWRTaXRlcz86IHN0cmluZ1tdO1xuICBhY3RpdmVWaXNpdHM/OiBSZWNvcmQ8c3RyaW5nLCBBY3RpdmVWaXNpdD47XG4gIHNlc3Npb25TaXRlVXNhZ2U/OiBSZWNvcmQ8c3RyaW5nLCBudW1iZXI+O1xuICBkb21haW5TcGFucz86IFJlY29yZDxzdHJpbmcsIERvbWFpblNwYW4+O1xufVxuXG5jb25zdCBERUZBVUxUX0JMT0NLRURfU0lURVM6IHN0cmluZ1tdID0gW107XG5jb25zdCBERUZBVUxUX1JFU1RSSUNURURfU0lURVM6IHN0cmluZ1tdID0gW107XG5leHBvcnQgY29uc3QgVEhJUlRZX0RBWVNfTVMgPSAzMCAqIDI0ICogNjAgKiA2MCAqIDEwMDA7XG5leHBvcnQgY29uc3QgSEVBUlRCRUFUX1RJTUVPVVRfTVMgPSA2MDAwMDtcblxuZXhwb3J0IGZ1bmN0aW9uIG5vcm1hbGl6ZUhvc3QoaG9zdDogc3RyaW5nKTogc3RyaW5nIHtcbiAgaWYgKCFob3N0KSByZXR1cm4gXCJcIjtcbiAgcmV0dXJuIGhvc3RcbiAgICAudHJpbSgpXG4gICAgLnRvTG93ZXJDYXNlKClcbiAgICAucmVwbGFjZSgvXmh0dHBzPzpcXC9cXC8vLCBcIlwiKVxuICAgIC5yZXBsYWNlKC9ed3d3XFwuLywgXCJcIilcbiAgICAucmVwbGFjZSgvWy8/I10uKiQvLCBcIlwiKVxuICAgIC50cmltKCk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBmaW5kTWF0Y2hpbmdTaXRlKGhvc3RuYW1lOiBzdHJpbmcsIHNpdGVzOiBzdHJpbmdbXSk6IHN0cmluZyB8IG51bGwge1xuICBjb25zdCBob3N0ID0gbm9ybWFsaXplSG9zdChob3N0bmFtZSk7XG4gIGlmICghaG9zdCkgcmV0dXJuIG51bGw7XG5cbiAgY29uc3Qgbm9ybWFsaXplZFNpdGVzID0gc2l0ZXMubWFwKChzKSA9PiBub3JtYWxpemVIb3N0KHMpKS5maWx0ZXIoQm9vbGVhbik7XG4gIGNvbnN0IGNvbmZpZ3VyZWRUd2l0dGVyQWxpYXMgPSBub3JtYWxpemVkU2l0ZXMuZmluZCgocykgPT4gcyA9PT0gXCJ0d2l0dGVyLmNvbVwiIHx8IHMgPT09IFwieC5jb21cIik7XG5cbiAgZm9yIChjb25zdCBkb21haW4gb2Ygbm9ybWFsaXplZFNpdGVzKSB7XG4gICAgaWYgKCFkb21haW4pIGNvbnRpbnVlO1xuICAgIGlmIChob3N0ID09PSBkb21haW4gfHwgaG9zdC5lbmRzV2l0aChgLiR7ZG9tYWlufWApKSB7XG4gICAgICAvLyBJZiBtYXRjaGluZyB0d2l0dGVyIG9yIHgsIG5vcm1hbGl6ZSB0byB0aGUgcHJpbWFyeSBjb25maWd1cmVkIGFsaWFzXG4gICAgICBpZiAoKGRvbWFpbiA9PT0gXCJ0d2l0dGVyLmNvbVwiIHx8IGRvbWFpbiA9PT0gXCJ4LmNvbVwiKSAmJiBjb25maWd1cmVkVHdpdHRlckFsaWFzKSB7XG4gICAgICAgIHJldHVybiBjb25maWd1cmVkVHdpdHRlckFsaWFzO1xuICAgICAgfVxuICAgICAgcmV0dXJuIGRvbWFpbjtcbiAgICB9XG4gIH1cblxuICAvLyBDcm9zcy1hbGlhcyByZXNvbHV0aW9uOiByZXNvbHZlIHJlYnJhbmQgYWxpYXNlcyB0byB0aGUgY2Fub25pY2FsIGNvbmZpZ3VyZWQgZW50cnlcbiAgaWYgKGNvbmZpZ3VyZWRUd2l0dGVyQWxpYXMpIHtcbiAgICBpZiAoaG9zdCA9PT0gXCJ0d2l0dGVyLmNvbVwiIHx8IGhvc3QuZW5kc1dpdGgoXCIudHdpdHRlci5jb21cIikgfHwgaG9zdCA9PT0gXCJ4LmNvbVwiIHx8IGhvc3QuZW5kc1dpdGgoXCIueC5jb21cIikpIHtcbiAgICAgIHJldHVybiBjb25maWd1cmVkVHdpdHRlckFsaWFzO1xuICAgIH1cbiAgfVxuXG4gIHJldHVybiBudWxsO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gc2FmZUV4dHJhY3RIb3N0KHVybFN0cj86IHN0cmluZyk6IHN0cmluZyB8IG51bGwge1xuICBpZiAoIXVybFN0cikgcmV0dXJuIG51bGw7XG4gIHRyeSB7XG4gICAgY29uc3QgcGFyc2VkID0gbmV3IFVSTCh1cmxTdHIpO1xuICAgIGlmIChwYXJzZWQucHJvdG9jb2wgIT09IFwiaHR0cDpcIiAmJiBwYXJzZWQucHJvdG9jb2wgIT09IFwiaHR0cHM6XCIpIHJldHVybiBudWxsO1xuICAgIGlmICghcGFyc2VkLmhvc3RuYW1lKSByZXR1cm4gbnVsbDtcbiAgICByZXR1cm4gbm9ybWFsaXplSG9zdChwYXJzZWQuaG9zdG5hbWUpO1xuICB9IGNhdGNoIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gZXh0cmFjdE9wZW5Eb21haW5zKFxuICB0YWJzPzogQXJyYXk8eyB1cmw/OiBzdHJpbmc7IGlkPzogbnVtYmVyIH0+LFxuICBzaXRlcz86IHN0cmluZ1tdLFxuKTogU2V0PHN0cmluZz4ge1xuICBjb25zdCBkb21haW5zID0gbmV3IFNldDxzdHJpbmc+KCk7XG4gIGlmICghQXJyYXkuaXNBcnJheSh0YWJzKSB8fCAhQXJyYXkuaXNBcnJheShzaXRlcykpIHJldHVybiBkb21haW5zO1xuICBmb3IgKGNvbnN0IHRhYiBvZiB0YWJzKSB7XG4gICAgY29uc3QgaG9zdCA9IHNhZmVFeHRyYWN0SG9zdCh0YWIudXJsKTtcbiAgICBpZiAoaG9zdCkge1xuICAgICAgY29uc3QgbWF0Y2ggPSBmaW5kTWF0Y2hpbmdTaXRlKGhvc3QsIHNpdGVzKTtcbiAgICAgIGlmIChtYXRjaCkge1xuICAgICAgICBkb21haW5zLmFkZChtYXRjaCk7XG4gICAgICB9XG4gICAgfVxuICB9XG4gIHJldHVybiBkb21haW5zO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gaXNWaXNpdEVsaWdpYmxlKFxuICB2aXNpdDogQWN0aXZlVmlzaXQsXG4gIG5vdzogbnVtYmVyLFxuICBvcGVuVGFiSWRzPzogU2V0PHN0cmluZz4sXG4pOiBib29sZWFuIHtcbiAgLy8gQW4gb3BlbiBicm93c2VyIHRhYiByZW1haW5zIGVsaWdpYmxlIGV2ZW4gaWYgQ2hyb21lIHRocm90dGxlZCBpdHMgaGVhcnRiZWF0LlxuICBpZiAodmlzaXQudGFiSWQgIT09IHVuZGVmaW5lZCAmJiBvcGVuVGFiSWRzKSB7XG4gICAgcmV0dXJuIG9wZW5UYWJJZHMuaGFzKFN0cmluZyh2aXNpdC50YWJJZCkpO1xuICB9XG4gIGlmICh2aXNpdC50YWJJZCAhPT0gdW5kZWZpbmVkICYmICFvcGVuVGFiSWRzKSB7XG4gICAgLy8gV2l0aG91dCBhbiBvcGVuLXRhYiBzbmFwc2hvdCwga2VlcCB0aGUgdmlzaXQgaWYgaGVhcnRiZWF0IGlzIHJlY2VudC5cbiAgICByZXR1cm4gbm93IC0gdmlzaXQubGFzdEhlYXJ0YmVhdCA8PSBIRUFSVEJFQVRfVElNRU9VVF9NUztcbiAgfVxuICByZXR1cm4gbm93IC0gdmlzaXQubGFzdEhlYXJ0YmVhdCA8PSBIRUFSVEJFQVRfVElNRU9VVF9NUztcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGhhc0VsaWdpYmxlVmlzaXRGb3JEb21haW4oXG4gIGFjdGl2ZVZpc2l0czogUmVjb3JkPHN0cmluZywgQWN0aXZlVmlzaXQ+LFxuICBkb21haW46IHN0cmluZyxcbiAgbm93OiBudW1iZXIsXG4gIG9wZW5UYWJJZHM/OiBTZXQ8c3RyaW5nPixcbiAgb3BlbkRvbWFpbnM/OiBTZXQ8c3RyaW5nPixcbik6IGJvb2xlYW4ge1xuICBpZiAob3BlbkRvbWFpbnMgJiYgb3BlbkRvbWFpbnMuaGFzKGRvbWFpbikpIHtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICByZXR1cm4gT2JqZWN0LnZhbHVlcyhhY3RpdmVWaXNpdHMpLnNvbWUoXG4gICAgKHYpID0+IHYuZG9tYWluID09PSBkb21haW4gJiYgaXNWaXNpdEVsaWdpYmxlKHYsIG5vdywgb3BlblRhYklkcyksXG4gICk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBmaW5hbGl6ZURvbWFpblNwYW4oXG4gIGRvbWFpblNwYW5zOiBSZWNvcmQ8c3RyaW5nLCBEb21haW5TcGFuPixcbiAgdXNhZ2U6IFJlY29yZDxzdHJpbmcsIG51bWJlcj4sXG4gIGRvbWFpbjogc3RyaW5nLFxuICBub3c6IG51bWJlcixcbiAgZmFsbGJhY2tUaW1lPzogbnVtYmVyLFxuICBzZXNzaW9uU3RhcnQ/OiBudW1iZXIsXG4pOiBib29sZWFuIHtcbiAgY29uc3Qgc3BhbiA9IGRvbWFpblNwYW5zW2RvbWFpbl07XG4gIGlmICghc3BhbikgcmV0dXJuIGZhbHNlO1xuICAvLyBJZiBmYWxsYmFja1RpbWUgaXMgcHJvdmlkZWQgKGUuZy4gZHVyaW5nIHN0YXJ0dXAgY2xlYW51cCBvciBvcnBoYW4gc3dlZXApLCB1c2UgaXQgYXMgdGhlIGVuZCB0aW1lLlxuICAvLyBPdGhlcndpc2UsIHRoZSBpbnRlcnZhbCBlbmRlZCBjbGVhbmx5IGF0ICdub3cnIChlLmcuIG5vcm1hbCB0YWIgY2xvc2UsIG5hdmlnYXRpb24sIG9yIHNlc3Npb24gc3RvcCkuXG4gIGNvbnN0IGVuZFRpbWUgPVxuICAgIGZhbGxiYWNrVGltZSAhPT0gdW5kZWZpbmVkID8gTWF0aC5tYXgoc3Bhbi5zdGFydGVkQXQsIGZhbGxiYWNrVGltZSkgOiBub3c7XG4gIGNvbnN0IGVmZmVjdGl2ZVN0YXJ0ID1cbiAgICBzZXNzaW9uU3RhcnQgJiYgc2Vzc2lvblN0YXJ0ID4gMFxuICAgICAgPyBNYXRoLm1heChzcGFuLnN0YXJ0ZWRBdCwgc2Vzc2lvblN0YXJ0KVxuICAgICAgOiBzcGFuLnN0YXJ0ZWRBdDtcbiAgY29uc3QgZHVyYXRpb24gPSBNYXRoLm1heCgwLCBlbmRUaW1lIC0gZWZmZWN0aXZlU3RhcnQpO1xuICBpZiAoZHVyYXRpb24gPiAwKSB7XG4gICAgdXNhZ2VbZG9tYWluXSA9ICh1c2FnZVtkb21haW5dID8/IDApICsgZHVyYXRpb247XG4gIH1cbiAgZGVsZXRlIGRvbWFpblNwYW5zW2RvbWFpbl07XG4gIHJldHVybiB0cnVlO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gZmluYWxpemVWaXNpdChcbiAgYWN0aXZlVmlzaXRzOiBSZWNvcmQ8c3RyaW5nLCBBY3RpdmVWaXNpdD4sXG4gIGRvbWFpblNwYW5zOiBSZWNvcmQ8c3RyaW5nLCBEb21haW5TcGFuPixcbiAgdXNhZ2U6IFJlY29yZDxzdHJpbmcsIG51bWJlcj4sXG4gIHRhYklkZW50aWZpZXI6IHN0cmluZyxcbiAgbm93OiBudW1iZXIsXG4gIG9wZW5UYWJJZHM/OiBTZXQ8c3RyaW5nPixcbiAgc2Vzc2lvblN0YXJ0PzogbnVtYmVyLFxuICBvcGVuRG9tYWlucz86IFNldDxzdHJpbmc+LFxuKTogYm9vbGVhbiB7XG4gIGlmICghdGFiSWRlbnRpZmllcikgcmV0dXJuIGZhbHNlO1xuICBsZXQgY2hhbmdlZCA9IGZhbHNlO1xuICBjb25zdCBkb21haW5zVG9SZWNoZWNrID0gbmV3IFNldDxzdHJpbmc+KCk7XG5cbiAgZm9yIChjb25zdCBba2V5LCB2aXNpdF0gb2YgT2JqZWN0LmVudHJpZXMoYWN0aXZlVmlzaXRzKSkge1xuICAgIGlmIChcbiAgICAgIGtleSA9PT0gdGFiSWRlbnRpZmllciB8fFxuICAgICAgdmlzaXQuaW5zdGFuY2VJZCA9PT0gdGFiSWRlbnRpZmllciB8fFxuICAgICAgKHZpc2l0LnRhYklkICE9PSB1bmRlZmluZWQgJiYgU3RyaW5nKHZpc2l0LnRhYklkKSA9PT0gdGFiSWRlbnRpZmllcilcbiAgICApIHtcbiAgICAgIGRvbWFpbnNUb1JlY2hlY2suYWRkKHZpc2l0LmRvbWFpbik7XG4gICAgICBkZWxldGUgYWN0aXZlVmlzaXRzW2tleV07XG4gICAgICBjaGFuZ2VkID0gdHJ1ZTtcbiAgICB9XG4gIH1cblxuICBmb3IgKGNvbnN0IGRvbWFpbiBvZiBkb21haW5zVG9SZWNoZWNrKSB7XG4gICAgY29uc3Qgc3BhbiA9IGRvbWFpblNwYW5zW2RvbWFpbl07XG4gICAgaWYgKHNwYW4pIHtcbiAgICAgIC8vIEF1dGhvcml0YXRpdmUgY29uZGl0aW9uOiBkb2VzIGFueSBlbGlnaWJsZSB2aXNpdCByZW1haW4gZm9yIHRoaXMgZG9tYWluP1xuICAgICAgY29uc3QgcmVtYWluaW5nVmlzaXRzRm9yRG9tYWluID0gaGFzRWxpZ2libGVWaXNpdEZvckRvbWFpbihcbiAgICAgICAgYWN0aXZlVmlzaXRzLFxuICAgICAgICBkb21haW4sXG4gICAgICAgIG5vdyxcbiAgICAgICAgb3BlblRhYklkcyxcbiAgICAgICAgb3BlbkRvbWFpbnMsXG4gICAgICApO1xuXG4gICAgICBpZiAoIXJlbWFpbmluZ1Zpc2l0c0ZvckRvbWFpbikge1xuICAgICAgICBmaW5hbGl6ZURvbWFpblNwYW4oXG4gICAgICAgICAgZG9tYWluU3BhbnMsXG4gICAgICAgICAgdXNhZ2UsXG4gICAgICAgICAgZG9tYWluLFxuICAgICAgICAgIG5vdyxcbiAgICAgICAgICB1bmRlZmluZWQsXG4gICAgICAgICAgc2Vzc2lvblN0YXJ0LFxuICAgICAgICApO1xuICAgICAgICBjaGFuZ2VkID0gdHJ1ZTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIC8vIEtlZXAgdGFiS2V5cyBzeW5jaHJvbml6ZWQgd2l0aCByZW1haW5pbmcgZWxpZ2libGUgdmlzaXRzXG4gICAgICAgIHNwYW4udGFiS2V5cyA9IE9iamVjdC5rZXlzKGFjdGl2ZVZpc2l0cykuZmlsdGVyKChrKSA9PiB7XG4gICAgICAgICAgY29uc3QgdiA9IGFjdGl2ZVZpc2l0c1trXTtcbiAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgdiAhPT0gdW5kZWZpbmVkICYmXG4gICAgICAgICAgICB2LmRvbWFpbiA9PT0gZG9tYWluICYmXG4gICAgICAgICAgICBpc1Zpc2l0RWxpZ2libGUodiwgbm93LCBvcGVuVGFiSWRzKVxuICAgICAgICAgICk7XG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIHJldHVybiBjaGFuZ2VkO1xufVxuXG5cbmxldCBzdGF0ZVF1ZXVlOiBQcm9taXNlPHZvaWQ+ID0gUHJvbWlzZS5yZXNvbHZlKCk7XG5cbmZ1bmN0aW9uIHJ1blNlcmlhbDxUPih0YXNrOiAoKSA9PiBQcm9taXNlPFQ+KTogUHJvbWlzZTxUPiB7XG4gIGNvbnN0IHJlc3VsdCA9IHN0YXRlUXVldWUudGhlbihcbiAgICAoKSA9PiB0YXNrKCksXG4gICAgKCkgPT4gdGFzaygpLFxuICApO1xuXG4gIHN0YXRlUXVldWUgPSByZXN1bHQudGhlbihcbiAgICAoKSA9PiB1bmRlZmluZWQsXG4gICAgKCkgPT4gdW5kZWZpbmVkLFxuICApO1xuXG4gIHJldHVybiByZXN1bHQ7XG59XG5cbmV4cG9ydCBkZWZhdWx0IGRlZmluZUJhY2tncm91bmQoKCkgPT4ge1xuICAvLyBDTEVBTlVQIE9SUEhBTkVEIFZJU0lUUyAmIElOSVRJQUxJWkUgREVGQVVMVFMgT04gU1RBUlRVUFxuICBydW5TZXJpYWwoYXN5bmMgKCkgPT4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBkYXRhID0gKGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5nZXQoW1xuICAgICAgICBcImFjdGl2ZVZpc2l0c1wiLFxuICAgICAgICBcInNlc3Npb25TaXRlVXNhZ2VcIixcbiAgICAgICAgXCJkb21haW5TcGFuc1wiLFxuICAgICAgICBcImlzQWN0aXZlXCIsXG4gICAgICAgIFwiYmxvY2tlZFNpdGVzXCIsXG4gICAgICAgIFwicmVzdHJpY3RlZFNpdGVzXCIsXG4gICAgICBdKSkgYXMgQmFja2dyb3VuZERhdGE7XG5cbiAgICAgIGNvbnN0IHVwZGF0ZXM6IFJlY29yZDxzdHJpbmcsIGFueT4gPSB7fTtcblxuICAgICAgaWYgKGRhdGEuYmxvY2tlZFNpdGVzID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgdXBkYXRlcy5ibG9ja2VkU2l0ZXMgPSBbXTtcbiAgICAgIH0gZWxzZSBpZiAoXG4gICAgICAgIEFycmF5LmlzQXJyYXkoZGF0YS5ibG9ja2VkU2l0ZXMpICYmXG4gICAgICAgIGRhdGEuYmxvY2tlZFNpdGVzLmxlbmd0aCA9PT0gMiAmJlxuICAgICAgICBkYXRhLmJsb2NrZWRTaXRlcy5pbmNsdWRlcyhcInguY29tXCIpICYmXG4gICAgICAgIGRhdGEuYmxvY2tlZFNpdGVzLmluY2x1ZGVzKFwidHdpdHRlci5jb21cIilcbiAgICAgICkge1xuICAgICAgICB1cGRhdGVzLmJsb2NrZWRTaXRlcyA9IFtdO1xuICAgICAgfVxuXG4gICAgICBpZiAoZGF0YS5yZXN0cmljdGVkU2l0ZXMgPT09IHVuZGVmaW5lZCkge1xuICAgICAgICB1cGRhdGVzLnJlc3RyaWN0ZWRTaXRlcyA9IFtdO1xuICAgICAgfSBlbHNlIGlmIChcbiAgICAgICAgQXJyYXkuaXNBcnJheShkYXRhLnJlc3RyaWN0ZWRTaXRlcykgJiZcbiAgICAgICAgZGF0YS5yZXN0cmljdGVkU2l0ZXMubGVuZ3RoID09PSAyICYmXG4gICAgICAgIGRhdGEucmVzdHJpY3RlZFNpdGVzLmluY2x1ZGVzKFwieW91dHViZS5jb21cIikgJiZcbiAgICAgICAgZGF0YS5yZXN0cmljdGVkU2l0ZXMuaW5jbHVkZXMoXCJpbnN0YWdyYW0uY29tXCIpXG4gICAgICApIHtcbiAgICAgICAgdXBkYXRlcy5yZXN0cmljdGVkU2l0ZXMgPSBbXTtcbiAgICAgIH1cblxuICAgICAgaWYgKGRhdGEuYWN0aXZlVmlzaXRzICYmIE9iamVjdC5rZXlzKGRhdGEuYWN0aXZlVmlzaXRzKS5sZW5ndGggPiAwKSB7XG4gICAgICAgIGNvbnN0IG9wZW5UYWJzID0gYXdhaXQgYnJvd3Nlci50YWJzLnF1ZXJ5KHt9KTtcbiAgICAgICAgY29uc3Qgb3BlblRhYklkcyA9IG5ldyBTZXQob3BlblRhYnMubWFwKCh0KSA9PiBTdHJpbmcodC5pZCkpKTtcbiAgICAgICAgY29uc3QgcmVzdHJpY3RlZFNpdGVzID0gZGF0YS5yZXN0cmljdGVkU2l0ZXMgPz8gW107XG4gICAgICAgIGNvbnN0IG9wZW5Eb21haW5zID0gZXh0cmFjdE9wZW5Eb21haW5zKG9wZW5UYWJzLCByZXN0cmljdGVkU2l0ZXMpO1xuICAgICAgICBjb25zdCBhY3RpdmVWaXNpdHMgPSB7IC4uLihkYXRhLmFjdGl2ZVZpc2l0cyA/PyB7fSkgfTtcbiAgICAgICAgY29uc3QgdXNhZ2UgPSB7IC4uLihkYXRhLnNlc3Npb25TaXRlVXNhZ2UgPz8ge30pIH07XG4gICAgICAgIGNvbnN0IGRvbWFpblNwYW5zID0geyAuLi4oZGF0YS5kb21haW5TcGFucyA/PyB7fSkgfTtcbiAgICAgICAgY29uc3Qgbm93ID0gRGF0ZS5ub3coKTtcbiAgICAgICAgbGV0IGNoYW5nZWQgPSBmYWxzZTtcblxuICAgICAgICBmb3IgKGNvbnN0IFt0YWJLZXksIHZpc2l0XSBvZiBPYmplY3QuZW50cmllcyhhY3RpdmVWaXNpdHMpKSB7XG4gICAgICAgICAgY29uc3QgdGFiSWRTdHIgPSB2aXNpdC50YWJJZCAhPT0gdW5kZWZpbmVkID8gU3RyaW5nKHZpc2l0LnRhYklkKSA6IHRhYktleTtcbiAgICAgICAgICBpZiAoIW9wZW5UYWJJZHMuaGFzKHRhYklkU3RyKSkge1xuICAgICAgICAgICAgZmluYWxpemVWaXNpdChcbiAgICAgICAgICAgICAgYWN0aXZlVmlzaXRzLFxuICAgICAgICAgICAgICBkb21haW5TcGFucyxcbiAgICAgICAgICAgICAgdXNhZ2UsXG4gICAgICAgICAgICAgIHRhYktleSxcbiAgICAgICAgICAgICAgdmlzaXQubGFzdEhlYXJ0YmVhdCB8fCBub3csXG4gICAgICAgICAgICAgIG9wZW5UYWJJZHMsXG4gICAgICAgICAgICAgIHVuZGVmaW5lZCxcbiAgICAgICAgICAgICAgb3BlbkRvbWFpbnMsXG4gICAgICAgICAgICApO1xuICAgICAgICAgICAgY2hhbmdlZCA9IHRydWU7XG4gICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgZm9yIChjb25zdCBbZG9tYWluLCBzcGFuXSBvZiBPYmplY3QuZW50cmllcyhkb21haW5TcGFucykpIHtcbiAgICAgICAgICBpZiAoIWhhc0VsaWdpYmxlVmlzaXRGb3JEb21haW4oYWN0aXZlVmlzaXRzLCBkb21haW4sIG5vdywgb3BlblRhYklkcywgb3BlbkRvbWFpbnMpKSB7XG4gICAgICAgICAgICBmaW5hbGl6ZURvbWFpblNwYW4oZG9tYWluU3BhbnMsIHVzYWdlLCBkb21haW4sIG5vdywgc3Bhbi5sYXN0SGVhcnRiZWF0KTtcbiAgICAgICAgICAgIGNoYW5nZWQgPSB0cnVlO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChjaGFuZ2VkKSB7XG4gICAgICAgICAgdXBkYXRlcy5hY3RpdmVWaXNpdHMgPSBhY3RpdmVWaXNpdHM7XG4gICAgICAgICAgdXBkYXRlcy5zZXNzaW9uU2l0ZVVzYWdlID0gdXNhZ2U7XG4gICAgICAgICAgdXBkYXRlcy5kb21haW5TcGFucyA9IGRvbWFpblNwYW5zO1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIGlmIChPYmplY3Qua2V5cyh1cGRhdGVzKS5sZW5ndGggPiAwKSB7XG4gICAgICAgIGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5zZXQodXBkYXRlcyk7XG4gICAgICB9XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgY29uc29sZS53YXJuKFwiTnVkZ2Ugc3RhcnR1cCBjbGVhbnVwICYgaW5pdCBlcnJvcjpcIiwgZSk7XG4gICAgfVxuICB9KTtcblxuICBicm93c2VyLnJ1bnRpbWUub25NZXNzYWdlLmFkZExpc3RlbmVyKChtc2c6IE1lc3NhZ2UsIHNlbmRlcikgPT5cbiAgICBydW5TZXJpYWwoYXN5bmMgKCkgPT4ge1xuICAgICAgY29uc3Qgbm93ID0gRGF0ZS5ub3coKTtcblxuICAgICAgLy8gMS4gU1RBUlQgU0VTU0lPTlxuICAgICAgaWYgKG1zZy5tZXNzYWdlID09PSBcInN0YXJ0X3Nlc3Npb25cIikge1xuICAgICAgICBpZiAobXNnLm1vZGUgIT09IFwiYmxvY2tcIiAmJiBtc2cubW9kZSAhPT0gXCJyZXN0cmljdFwiKSB7XG4gICAgICAgICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiBcIkludmFsaWQgc2Vzc2lvbiBtb2RlXCIgfTtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IHN0b3JlZCA9IChhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuZ2V0KFtcbiAgICAgICAgICBcInNlc3Npb25zXCIsXG4gICAgICAgICAgXCJibG9ja2VkU2l0ZXNcIixcbiAgICAgICAgICBcInJlc3RyaWN0ZWRTaXRlc1wiLFxuICAgICAgICAgIFwiaXNBY3RpdmVcIixcbiAgICAgICAgXSkpIGFzIEJhY2tncm91bmREYXRhO1xuXG4gICAgICAgIGlmIChzdG9yZWQuaXNBY3RpdmUpIHtcbiAgICAgICAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IFwiQSBzZXNzaW9uIGlzIGFscmVhZHkgYWN0aXZlXCIgfTtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IHNlc3Npb25VcGRhdGVzOiBSZWNvcmQ8c3RyaW5nLCBhbnk+ID0ge1xuICAgICAgICAgIGlzQWN0aXZlOiB0cnVlLFxuICAgICAgICAgIG1vZGU6IG1zZy5tb2RlLFxuICAgICAgICAgIHN0YXJ0ZWRBdDogbm93LFxuICAgICAgICAgIGFjdGl2ZVZpc2l0czoge30sXG4gICAgICAgICAgc2Vzc2lvblNpdGVVc2FnZToge30sXG4gICAgICAgICAgZG9tYWluU3BhbnM6IHt9LFxuICAgICAgICB9O1xuICAgICAgICBpZiAoc3RvcmVkLmJsb2NrZWRTaXRlcyA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgc2Vzc2lvblVwZGF0ZXMuYmxvY2tlZFNpdGVzID0gREVGQVVMVF9CTE9DS0VEX1NJVEVTO1xuICAgICAgICB9XG4gICAgICAgIGlmIChzdG9yZWQucmVzdHJpY3RlZFNpdGVzID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICBzZXNzaW9uVXBkYXRlcy5yZXN0cmljdGVkU2l0ZXMgPSBERUZBVUxUX1JFU1RSSUNURURfU0lURVM7XG4gICAgICAgIH1cbiAgICAgICAgYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLnNldChzZXNzaW9uVXBkYXRlcyk7XG5cbiAgICAgICAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSwgc3RhcnRlZEF0OiBub3cgfTtcbiAgICAgIH1cblxuICAgICAgLy8gMi4gU1RPUCBTRVNTSU9OXG4gICAgICBpZiAobXNnLm1lc3NhZ2UgPT09IFwic3RvcF9zZXNzaW9uXCIpIHtcbiAgICAgICAgY29uc3QgZGF0YSA9IChhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuZ2V0KFtcbiAgICAgICAgICBcImlzQWN0aXZlXCIsXG4gICAgICAgICAgXCJtb2RlXCIsXG4gICAgICAgICAgXCJzdGFydGVkQXRcIixcbiAgICAgICAgICBcInNlc3Npb25zXCIsXG4gICAgICAgICAgXCJhY3RpdmVWaXNpdHNcIixcbiAgICAgICAgICBcInNlc3Npb25TaXRlVXNhZ2VcIixcbiAgICAgICAgICBcImRvbWFpblNwYW5zXCIsXG4gICAgICAgIF0pKSBhcyBCYWNrZ3JvdW5kRGF0YTtcblxuICAgICAgICBpZiAoIWRhdGEuaXNBY3RpdmUgfHwgIWRhdGEuc3RhcnRlZEF0KSB7XG4gICAgICAgICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiBcIk5vIGFjdGl2ZSBzZXNzaW9uXCIgfTtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IHVzYWdlID0geyAuLi4oZGF0YS5zZXNzaW9uU2l0ZVVzYWdlID8/IHt9KSB9O1xuICAgICAgICBjb25zdCBkb21haW5TcGFucyA9IHsgLi4uKGRhdGEuZG9tYWluU3BhbnMgPz8ge30pIH07XG5cbiAgICAgICAgLy8gRmluYWxpemUgYWxsIGFjdGl2ZSBkb21haW4gc3BhbnMgb25jZSBpbnRvIGFjY3VtdWxhdGVkIHVzYWdlXG4gICAgICAgIGZvciAoY29uc3QgZG9tYWluIG9mIE9iamVjdC5rZXlzKGRvbWFpblNwYW5zKSkge1xuICAgICAgICAgIGZpbmFsaXplRG9tYWluU3BhbihcbiAgICAgICAgICAgIGRvbWFpblNwYW5zLFxuICAgICAgICAgICAgdXNhZ2UsXG4gICAgICAgICAgICBkb21haW4sXG4gICAgICAgICAgICBub3csXG4gICAgICAgICAgICBub3csXG4gICAgICAgICAgICBkYXRhLnN0YXJ0ZWRBdCxcbiAgICAgICAgICApO1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgcmVjb3JkOiBTZXNzaW9uUmVjb3JkID0ge1xuICAgICAgICAgIG1vZGU6IGRhdGEubW9kZSA/PyBcIlwiLFxuICAgICAgICAgIHN0YXJ0ZWRBdDogZGF0YS5zdGFydGVkQXQsXG4gICAgICAgICAgZW5kZWRBdDogbm93LFxuICAgICAgICAgIGR1cmF0aW9uOiBub3cgLSBkYXRhLnN0YXJ0ZWRBdCxcbiAgICAgICAgICBzaXRlVXNhZ2U6IHVzYWdlLFxuICAgICAgICB9O1xuXG4gICAgICAgIGNvbnN0IGN1dG9mZiA9IG5vdyAtIFRISVJUWV9EQVlTX01TO1xuICAgICAgICBjb25zdCBhbGxTZXNzaW9ucyA9IFsuLi4oZGF0YS5zZXNzaW9ucyA/PyBbXSksIHJlY29yZF07XG4gICAgICAgIC8vIEVuZm9yY2UgMzAtZGF5IHJldGVudGlvbiBwb2xpY3lcbiAgICAgICAgY29uc3Qgc2Vzc2lvbnMgPSBhbGxTZXNzaW9ucy5maWx0ZXIoKHMpID0+IHMuc3RhcnRlZEF0ID49IGN1dG9mZik7XG5cbiAgICAgICAgYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLnNldCh7XG4gICAgICAgICAgaXNBY3RpdmU6IGZhbHNlLFxuICAgICAgICAgIHN0YXJ0ZWRBdDogMCxcbiAgICAgICAgICBtb2RlOiBcIlwiLFxuICAgICAgICAgIHNlc3Npb25zLFxuICAgICAgICAgIGFjdGl2ZVZpc2l0czoge30sXG4gICAgICAgICAgc2Vzc2lvblNpdGVVc2FnZToge30sXG4gICAgICAgICAgZG9tYWluU3BhbnM6IHt9LFxuICAgICAgICB9KTtcblxuICAgICAgICByZXR1cm4geyBzdWNjZXNzOiB0cnVlIH07XG4gICAgICB9XG5cbiAgICAgIC8vIDMuIEdFVCBDVVJSRU5UIFNFU1NJT05cbiAgICAgIGlmIChtc2cubWVzc2FnZSA9PT0gXCJnZXRfc2Vzc2lvblwiKSB7XG4gICAgICAgIGNvbnN0IGRhdGEgPSAoYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLmdldChbXG4gICAgICAgICAgXCJpc0FjdGl2ZVwiLFxuICAgICAgICAgIFwic3RhcnRlZEF0XCIsXG4gICAgICAgICAgXCJtb2RlXCIsXG4gICAgICAgIF0pKSBhcyBCYWNrZ3JvdW5kRGF0YTtcblxuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgIGlzQWN0aXZlOiBCb29sZWFuKGRhdGEuaXNBY3RpdmUpLFxuICAgICAgICAgIHN0YXJ0ZWRBdDogZGF0YS5pc0FjdGl2ZSAmJiBkYXRhLnN0YXJ0ZWRBdCA/IGRhdGEuc3RhcnRlZEF0IDogMCxcbiAgICAgICAgICBlbGFwc2VkVGltZTpcbiAgICAgICAgICAgIGRhdGEuaXNBY3RpdmUgJiYgZGF0YS5zdGFydGVkQXQgPyBNYXRoLm1heCgwLCBub3cgLSBkYXRhLnN0YXJ0ZWRBdCkgOiAwLFxuICAgICAgICAgIG1vZGU6IGRhdGEubW9kZSA/PyBcIlwiLFxuICAgICAgICB9O1xuICAgICAgfVxuXG4gICAgICAvLyA0LiBDSEVDSyBTSVRFICYgSEVBUlRCRUFUIChBVE9NSUMgJiBDQU5PTklDQUxMWSBBTkNIT1JFRClcbiAgICAgIGlmIChtc2cubWVzc2FnZSA9PT0gXCJjaGVja19zaXRlXCIpIHtcbiAgICAgICAgY29uc3QgdGFiSWQgPSBzZW5kZXIudGFiPy5pZDtcbiAgICAgICAgY29uc3QgcmF3SG9zdG5hbWUgPSBtc2cuaG9zdG5hbWUgPz8gXCJcIjtcbiAgICAgICAgY29uc3QgaG9zdCA9IG5vcm1hbGl6ZUhvc3QocmF3SG9zdG5hbWUpO1xuXG4gICAgICAgIGNvbnN0IGRhdGEgPSAoYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLmdldChbXG4gICAgICAgICAgXCJibG9ja2VkU2l0ZXNcIixcbiAgICAgICAgICBcInJlc3RyaWN0ZWRTaXRlc1wiLFxuICAgICAgICAgIFwiaXNBY3RpdmVcIixcbiAgICAgICAgICBcIm1vZGVcIixcbiAgICAgICAgICBcInN0YXJ0ZWRBdFwiLFxuICAgICAgICAgIFwiYWN0aXZlVmlzaXRzXCIsXG4gICAgICAgICAgXCJzZXNzaW9uU2l0ZVVzYWdlXCIsXG4gICAgICAgICAgXCJkb21haW5TcGFuc1wiLFxuICAgICAgICBdKSkgYXMgQmFja2dyb3VuZERhdGE7XG5cbiAgICAgICAgaWYgKCFkYXRhLmlzQWN0aXZlKSB7XG4gICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIGlzQWN0aXZlOiBmYWxzZSxcbiAgICAgICAgICAgIG1vZGU6IFwiXCIsXG4gICAgICAgICAgICBzZXNzaW9uU3RhcnRlZEF0OiAwLFxuICAgICAgICAgICAgaXNCbG9ja2VkOiBmYWxzZSxcbiAgICAgICAgICAgIGlzUmVzdHJpY3RlZDogZmFsc2UsXG4gICAgICAgICAgICB2aXNpdFN0YXJ0ZWRBdDogMCxcbiAgICAgICAgICAgIGRvbWFpblN0YXJ0ZWRBdDogMCxcbiAgICAgICAgICAgIGRvbWFpblNwYW5TdGFydGVkQXQ6IDAsXG4gICAgICAgICAgICBiYXNlU2l0ZVVzYWdlOiAwLFxuICAgICAgICAgICAgYmFzZVNpdGVVc2FnZU1zOiAwLFxuICAgICAgICAgICAgYmFzZVNpdGVVc2FnZVNlYzogMCxcbiAgICAgICAgICAgIHRvdGFsU2l0ZVVzYWdlU2VjOiAwLFxuICAgICAgICAgIH07XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBzZXNzaW9uU3RhcnQgPVxuICAgICAgICAgIHR5cGVvZiBkYXRhLnN0YXJ0ZWRBdCA9PT0gXCJudW1iZXJcIiAmJiBkYXRhLnN0YXJ0ZWRBdCA+IDBcbiAgICAgICAgICAgID8gZGF0YS5zdGFydGVkQXRcbiAgICAgICAgICAgIDogbm93O1xuXG4gICAgICAgIGlmICghZGF0YS5zdGFydGVkQXQpIHtcbiAgICAgICAgICBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuc2V0KHsgc3RhcnRlZEF0OiBzZXNzaW9uU3RhcnQgfSk7XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBibG9ja2VkU2l0ZXMgPSBkYXRhLmJsb2NrZWRTaXRlcyA/PyBbXTtcbiAgICAgICAgY29uc3QgcmVzdHJpY3RlZFNpdGVzID0gZGF0YS5yZXN0cmljdGVkU2l0ZXMgPz8gW107XG5cbiAgICAgICAgY29uc3QgYmxvY2tlZERvbWFpbiA9XG4gICAgICAgICAgZGF0YS5tb2RlID09PSBcImJsb2NrXCIgPyBmaW5kTWF0Y2hpbmdTaXRlKGhvc3QsIGJsb2NrZWRTaXRlcykgOiBudWxsO1xuICAgICAgICBjb25zdCByZXN0cmljdGVkRG9tYWluID1cbiAgICAgICAgICAhYmxvY2tlZERvbWFpbiA/IGZpbmRNYXRjaGluZ1NpdGUoaG9zdCwgcmVzdHJpY3RlZFNpdGVzKSA6IG51bGw7XG5cbiAgICAgICAgaWYgKGJsb2NrZWREb21haW4pIHtcbiAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgaXNBY3RpdmU6IHRydWUsXG4gICAgICAgICAgICBtb2RlOiBkYXRhLm1vZGUgPz8gXCJcIixcbiAgICAgICAgICAgIHNlc3Npb25TdGFydGVkQXQ6IHNlc3Npb25TdGFydCxcbiAgICAgICAgICAgIGlzQmxvY2tlZDogdHJ1ZSxcbiAgICAgICAgICAgIGlzUmVzdHJpY3RlZDogZmFsc2UsXG4gICAgICAgICAgICB2aXNpdFN0YXJ0ZWRBdDogMCxcbiAgICAgICAgICAgIGRvbWFpblN0YXJ0ZWRBdDogMCxcbiAgICAgICAgICAgIGRvbWFpblNwYW5TdGFydGVkQXQ6IDAsXG4gICAgICAgICAgICBiYXNlU2l0ZVVzYWdlOiAwLFxuICAgICAgICAgICAgYmFzZVNpdGVVc2FnZU1zOiAwLFxuICAgICAgICAgICAgYmFzZVNpdGVVc2FnZVNlYzogMCxcbiAgICAgICAgICAgIHRvdGFsU2l0ZVVzYWdlU2VjOiAwLFxuICAgICAgICAgIH07XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBhY3RpdmVWaXNpdHMgPSB7IC4uLihkYXRhLmFjdGl2ZVZpc2l0cyA/PyB7fSkgfTtcbiAgICAgICAgY29uc3QgdXNhZ2UgPSB7IC4uLihkYXRhLnNlc3Npb25TaXRlVXNhZ2UgPz8ge30pIH07XG4gICAgICAgIGNvbnN0IGRvbWFpblNwYW5zID0geyAuLi4oZGF0YS5kb21haW5TcGFucyA/PyB7fSkgfTtcbiAgICAgICAgY29uc3QgcmF3VGFiSWQgPSBzZW5kZXIudGFiPy5pZDtcbiAgICAgICAgY29uc3QgaW5zdGFuY2VJZCA9IG1zZy50YWJJbnN0YW5jZUlkIHx8IFwiXCI7XG4gICAgICAgIGNvbnN0IGlzVmlzaWJsZSA9IG1zZy5pc1Zpc2libGUgIT09IGZhbHNlO1xuICAgICAgICBjb25zdCB0YWJLZXkgPVxuICAgICAgICAgIHJhd1RhYklkICE9PSB1bmRlZmluZWRcbiAgICAgICAgICAgID8gU3RyaW5nKHJhd1RhYklkKVxuICAgICAgICAgICAgOiAoaW5zdGFuY2VJZCB8fCAoaG9zdCA/IGB0YWJfJHtob3N0fWAgOiBcIm1haW5fdGFiXCIpKTtcbiAgICAgICAgbGV0IGhhc1N0YXRlQ2hhbmdlID0gZmFsc2U7XG5cbiAgICAgICAgLy8gUHJldmVudCBnaG9zdCB2aXNpdHM6IGlmIG5hdGl2ZSByYXdUYWJJZCBpcyBrbm93biwgcHVyZ2UgYW55IHRlbXBvcmFyeSB1bm1hcHBlZCB2aXNpdCBrZXllZCB1bmRlciBpbnN0YW5jZUlkXG4gICAgICAgIGlmIChyYXdUYWJJZCAhPT0gdW5kZWZpbmVkICYmIGluc3RhbmNlSWQpIHtcbiAgICAgICAgICBmb3IgKGNvbnN0IFtrLCB2XSBvZiBPYmplY3QuZW50cmllcyhhY3RpdmVWaXNpdHMpKSB7XG4gICAgICAgICAgICBpZiAoayAhPT0gdGFiS2V5ICYmIChrID09PSBpbnN0YW5jZUlkIHx8IHYudGFiSWQgPT09IHVuZGVmaW5lZCkgJiYgdi5pbnN0YW5jZUlkID09PSBpbnN0YW5jZUlkKSB7XG4gICAgICAgICAgICAgIGRlbGV0ZSBhY3RpdmVWaXNpdHNba107XG4gICAgICAgICAgICAgIGhhc1N0YXRlQ2hhbmdlID0gdHJ1ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICAvLyBSZWNvbmNpbGUgd2l0aCBjdXJyZW50bHkgb3BlbiBicm93c2VyIHRhYnM6IGlmIHRhYiBpcyBjbG9zZWQgaW4gYnJvd3NlciwgZmluYWxpemUgaW1tZWRpYXRlbHlcbiAgICAgICAgbGV0IG9wZW5UYWJJZHMgPSBuZXcgU2V0PHN0cmluZz4oKTtcbiAgICAgICAgbGV0IG9wZW5Eb21haW5zID0gbmV3IFNldDxzdHJpbmc+KCk7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgY29uc3Qgb3BlblRhYnMgPSBhd2FpdCBicm93c2VyLnRhYnMucXVlcnkoe30pO1xuICAgICAgICAgIG9wZW5UYWJJZHMgPSBuZXcgU2V0KG9wZW5UYWJzLm1hcCgodCkgPT4gU3RyaW5nKHQuaWQpKSk7XG4gICAgICAgICAgb3BlbkRvbWFpbnMgPSBleHRyYWN0T3BlbkRvbWFpbnMob3BlblRhYnMsIHJlc3RyaWN0ZWRTaXRlcyk7XG5cbiAgICAgICAgICAvLyBJZiB0aGUgc2VuZGVyIHRhYiB3YXMgYWxyZWFkeSBjbG9zZWQgaW4gQ2hyb21lIGJlZm9yZSB0aGlzIG1lc3NhZ2UgcHJvY2Vzc2VkLCBkbyBub3QgcmVnaXN0ZXIgYSBnaG9zdCB2aXNpdFxuICAgICAgICAgIGlmIChyYXdUYWJJZCAhPT0gdW5kZWZpbmVkICYmIG9wZW5UYWJJZHMuc2l6ZSA+IDAgJiYgIW9wZW5UYWJJZHMuaGFzKFN0cmluZyhyYXdUYWJJZCkpKSB7XG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICBpc0FjdGl2ZTogdHJ1ZSxcbiAgICAgICAgICAgICAgbW9kZTogZGF0YS5tb2RlID8/IFwiXCIsXG4gICAgICAgICAgICAgIHNlc3Npb25TdGFydGVkQXQ6IHNlc3Npb25TdGFydCxcbiAgICAgICAgICAgICAgaXNCbG9ja2VkOiBmYWxzZSxcbiAgICAgICAgICAgICAgaXNSZXN0cmljdGVkOiBmYWxzZSxcbiAgICAgICAgICAgICAgdmlzaXRTdGFydGVkQXQ6IDAsXG4gICAgICAgICAgICAgIGRvbWFpblN0YXJ0ZWRBdDogMCxcbiAgICAgICAgICAgICAgZG9tYWluU3BhblN0YXJ0ZWRBdDogMCxcbiAgICAgICAgICAgICAgYmFzZVNpdGVVc2FnZTogMCxcbiAgICAgICAgICAgICAgYmFzZVNpdGVVc2FnZU1zOiAwLFxuICAgICAgICAgICAgICBiYXNlU2l0ZVVzYWdlU2VjOiAwLFxuICAgICAgICAgICAgICB0b3RhbFNpdGVVc2FnZVNlYzogMCxcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgZm9yIChjb25zdCBbaywgdl0gb2YgT2JqZWN0LmVudHJpZXMoYWN0aXZlVmlzaXRzKSkge1xuICAgICAgICAgICAgY29uc3QgdlRhYklkID0gdi50YWJJZCAhPT0gdW5kZWZpbmVkID8gU3RyaW5nKHYudGFiSWQpIDogaztcbiAgICAgICAgICAgIGlmIChrICE9PSB0YWJLZXkgJiYgdi50YWJJZCAhPT0gdW5kZWZpbmVkICYmICFvcGVuVGFiSWRzLmhhcyh2VGFiSWQpKSB7XG4gICAgICAgICAgICAgIGZpbmFsaXplVmlzaXQoXG4gICAgICAgICAgICAgICAgYWN0aXZlVmlzaXRzLFxuICAgICAgICAgICAgICAgIGRvbWFpblNwYW5zLFxuICAgICAgICAgICAgICAgIHVzYWdlLFxuICAgICAgICAgICAgICAgIGssXG4gICAgICAgICAgICAgICAgdi5sYXN0SGVhcnRiZWF0IHx8IG5vdyxcbiAgICAgICAgICAgICAgICBvcGVuVGFiSWRzLFxuICAgICAgICAgICAgICAgIHNlc3Npb25TdGFydCxcbiAgICAgICAgICAgICAgICBvcGVuRG9tYWlucyxcbiAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgaGFzU3RhdGVDaGFuZ2UgPSB0cnVlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfSBjYXRjaCB7fVxuXG4gICAgICAgIC8vIFBydW5lIG9ubHkgY2xvc2VkIC8gbm9uLXRhYiB2aXNpdHMgd2l0aCBzdGFsZSBoZWFydGJlYXRzLlxuICAgICAgICAvLyBPcGVuIHRhYnMgcmVtYWluIGVsaWdpYmxlIGV2ZW4gd2hlbiBDaHJvbWUgdGhyb3R0bGVzIGJhY2tncm91bmQgdGltZXJzLlxuICAgICAgICBmb3IgKGNvbnN0IFtrLCB2XSBvZiBPYmplY3QuZW50cmllcyhhY3RpdmVWaXNpdHMpKSB7XG4gICAgICAgICAgaWYgKGsgPT09IHRhYktleSkgY29udGludWU7XG4gICAgICAgICAgY29uc3QgdlRhYklkID0gdi50YWJJZCAhPT0gdW5kZWZpbmVkID8gU3RyaW5nKHYudGFiSWQpIDogaztcbiAgICAgICAgICBjb25zdCBpc09wZW5UYWIgPSB2LnRhYklkICE9PSB1bmRlZmluZWQgJiYgb3BlblRhYklkcy5oYXModlRhYklkKTtcbiAgICAgICAgICBpZiAoIWlzT3BlblRhYiAmJiBub3cgLSB2Lmxhc3RIZWFydGJlYXQgPiBIRUFSVEJFQVRfVElNRU9VVF9NUykge1xuICAgICAgICAgICAgZmluYWxpemVWaXNpdChcbiAgICAgICAgICAgICAgYWN0aXZlVmlzaXRzLFxuICAgICAgICAgICAgICBkb21haW5TcGFucyxcbiAgICAgICAgICAgICAgdXNhZ2UsXG4gICAgICAgICAgICAgIGssXG4gICAgICAgICAgICAgIHYubGFzdEhlYXJ0YmVhdCB8fCBub3csXG4gICAgICAgICAgICAgIG9wZW5UYWJJZHMsXG4gICAgICAgICAgICAgIHNlc3Npb25TdGFydCxcbiAgICAgICAgICAgICAgb3BlbkRvbWFpbnMsXG4gICAgICAgICAgICApO1xuICAgICAgICAgICAgaGFzU3RhdGVDaGFuZ2UgPSB0cnVlO1xuICAgICAgICAgIH0gZWxzZSBpZiAoaXNPcGVuVGFiICYmIG5vdyAtIHYubGFzdEhlYXJ0YmVhdCA+IEhFQVJUQkVBVF9USU1FT1VUX01TKSB7XG4gICAgICAgICAgICBpZiAodi5pc1Zpc2libGUpIHtcbiAgICAgICAgICAgICAgdi5pc1Zpc2libGUgPSBmYWxzZTtcbiAgICAgICAgICAgICAgaGFzU3RhdGVDaGFuZ2UgPSB0cnVlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIC8vIERvbWFpbiBzcGFucyBzdGF5IG9wZW4gd2hpbGUgYW55IGVsaWdpYmxlIHRhYiBvZiB0aGUgZG9tYWluIHJlbWFpbnMgb3BlblxuICAgICAgICBmb3IgKGNvbnN0IFtkb21haW4sIHNwYW5dIG9mIE9iamVjdC5lbnRyaWVzKGRvbWFpblNwYW5zKSkge1xuICAgICAgICAgIGlmICghaGFzRWxpZ2libGVWaXNpdEZvckRvbWFpbihhY3RpdmVWaXNpdHMsIGRvbWFpbiwgbm93LCBvcGVuVGFiSWRzLCBvcGVuRG9tYWlucykpIHtcbiAgICAgICAgICAgIGZpbmFsaXplRG9tYWluU3BhbihcbiAgICAgICAgICAgICAgZG9tYWluU3BhbnMsXG4gICAgICAgICAgICAgIHVzYWdlLFxuICAgICAgICAgICAgICBkb21haW4sXG4gICAgICAgICAgICAgIG5vdyxcbiAgICAgICAgICAgICAgc3Bhbi5sYXN0SGVhcnRiZWF0LFxuICAgICAgICAgICAgICBzZXNzaW9uU3RhcnQsXG4gICAgICAgICAgICApO1xuICAgICAgICAgICAgaGFzU3RhdGVDaGFuZ2UgPSB0cnVlO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIGxldCBleGlzdGluZyA9IGFjdGl2ZVZpc2l0c1t0YWJLZXldO1xuXG4gICAgICAgIC8vIERyb3AgdmlzaXQgYW5jaG9ycyBmcm9tIGEgcHJpb3Igc2Vzc2lvbiAoZG8gbm90IGNvdW50IHByZS1zZXNzaW9uIHRpbWUpXG4gICAgICAgIGlmIChleGlzdGluZyAmJiBleGlzdGluZy5zdGFydGVkQXQgPCBzZXNzaW9uU3RhcnQpIHtcbiAgICAgICAgICBkZWxldGUgYWN0aXZlVmlzaXRzW3RhYktleV07XG4gICAgICAgICAgZXhpc3RpbmcgPSB1bmRlZmluZWQ7XG4gICAgICAgIH1cblxuICAgICAgICAvLyBEcm9wIGFueSBzdGFsZSBkb21haW4gc3BhbiBmcm9tIGEgcHJpb3Igc2Vzc2lvbiAobmV2ZXIgYWRkIHN0YWxlIHByZS1zZXNzaW9uIHN0YXRlIHRvIGN1cnJlbnQgc2Vzc2lvbiB1c2FnZSlcbiAgICAgICAgaWYgKHJlc3RyaWN0ZWREb21haW4pIHtcbiAgICAgICAgICBjb25zdCBzdGFsZVNwYW4gPSBkb21haW5TcGFuc1tyZXN0cmljdGVkRG9tYWluXTtcbiAgICAgICAgICBpZiAoc3RhbGVTcGFuICYmIHN0YWxlU3Bhbi5zdGFydGVkQXQgPCBzZXNzaW9uU3RhcnQpIHtcbiAgICAgICAgICAgIGRlbGV0ZSBkb21haW5TcGFuc1tyZXN0cmljdGVkRG9tYWluXTtcbiAgICAgICAgICAgIGhhc1N0YXRlQ2hhbmdlID0gdHJ1ZTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICAvLyBPbmx5IGZpbmFsaXplIHRoZSB2aXNpdCBpZiB0aGUgdGFiIG5hdmlnYXRlZCBhd2F5IHRvIGEgZGlmZmVyZW50IGRvbWFpbiBvciBhbiB1bnJlc3RyaWN0ZWQgc2l0ZVxuICAgICAgICBpZiAoZXhpc3RpbmcgJiYgZXhpc3RpbmcuZG9tYWluICE9PSByZXN0cmljdGVkRG9tYWluKSB7XG4gICAgICAgICAgY29uc3QgY2hhbmdlZCA9IGZpbmFsaXplVmlzaXQoXG4gICAgICAgICAgICBhY3RpdmVWaXNpdHMsXG4gICAgICAgICAgICBkb21haW5TcGFucyxcbiAgICAgICAgICAgIHVzYWdlLFxuICAgICAgICAgICAgdGFiS2V5LFxuICAgICAgICAgICAgbm93LFxuICAgICAgICAgICAgb3BlblRhYklkcyxcbiAgICAgICAgICAgIHNlc3Npb25TdGFydCxcbiAgICAgICAgICAgIG9wZW5Eb21haW5zLFxuICAgICAgICAgICk7XG4gICAgICAgICAgaWYgKGNoYW5nZWQpIGhhc1N0YXRlQ2hhbmdlID0gdHJ1ZTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChyZXN0cmljdGVkRG9tYWluKSB7XG4gICAgICAgICAgLy8gQ2hlY2sgaWYgdGhpcyBzcGVjaWZpYyB0YWIgd2FzIGFscmVhZHkgYWN0aXZlIG9uIHRoaXMgZG9tYWluIGluIHRoaXMgc2Vzc2lvblxuICAgICAgICAgIGNvbnN0IGlzVGFiQ29udGludWluZyA9XG4gICAgICAgICAgICBleGlzdGluZyAhPT0gdW5kZWZpbmVkICYmXG4gICAgICAgICAgICBleGlzdGluZy5kb21haW4gPT09IHJlc3RyaWN0ZWREb21haW4gJiZcbiAgICAgICAgICAgIGV4aXN0aW5nLnN0YXJ0ZWRBdCA+PSBzZXNzaW9uU3RhcnQ7XG5cbiAgICAgICAgICBsZXQgY3VycmVudFZpc2l0OiBBY3RpdmVWaXNpdDtcbiAgICAgICAgICBpZiAoIWlzVGFiQ29udGludWluZyB8fCAhZXhpc3RpbmcpIHtcbiAgICAgICAgICAgIC8vIEZpbmFsaXplIHByaW9yIHZpc2l0IG9uIHRoaXMgdGFiIGlmIGl0IGJlbG9uZ2VkIHRvIGEgZGlmZmVyZW50IGRvbWFpblxuICAgICAgICAgICAgaWYgKGV4aXN0aW5nKSB7XG4gICAgICAgICAgICAgIGZpbmFsaXplVmlzaXQoXG4gICAgICAgICAgICAgICAgYWN0aXZlVmlzaXRzLFxuICAgICAgICAgICAgICAgIGRvbWFpblNwYW5zLFxuICAgICAgICAgICAgICAgIHVzYWdlLFxuICAgICAgICAgICAgICAgIHRhYktleSxcbiAgICAgICAgICAgICAgICBleGlzdGluZy5sYXN0SGVhcnRiZWF0IHx8IG5vdyxcbiAgICAgICAgICAgICAgICBvcGVuVGFiSWRzLFxuICAgICAgICAgICAgICAgIHNlc3Npb25TdGFydCxcbiAgICAgICAgICAgICAgICBvcGVuRG9tYWlucyxcbiAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC8vIEFjY2VwdCB0aGUgY29udGVudCBzY3JpcHQncyB2aXNpdCBzdGFydCB0aW1lc3RhbXAgaWYgaXQgZmFsbHMgd2l0aGluIHRoZSBjdXJyZW50IHNlc3Npb25cbiAgICAgICAgICAgIC8vIGFuZCB3YXMgbm90IGluaGVyaXRlZCBmcm9tIGFuIGV4aXN0aW5nIHNpYmxpbmcgdGFiIGluIHNlc3Npb25TdG9yYWdlLlxuICAgICAgICAgICAgY29uc3QgaXNJbmhlcml0ZWRGcm9tU2libGluZyA9XG4gICAgICAgICAgICAgIHR5cGVvZiBtc2cudGFiVmlzaXRTdGFydGVkQXQgPT09IFwibnVtYmVyXCIgJiZcbiAgICAgICAgICAgICAgT2JqZWN0LnZhbHVlcyhhY3RpdmVWaXNpdHMpLnNvbWUoXG4gICAgICAgICAgICAgICAgKHYpID0+XG4gICAgICAgICAgICAgICAgICB2LnN0YXJ0ZWRBdCA9PT0gbXNnLnRhYlZpc2l0U3RhcnRlZEF0ICYmXG4gICAgICAgICAgICAgICAgICAocmF3VGFiSWQgPT09IHVuZGVmaW5lZCB8fCB2LnRhYklkICE9PSByYXdUYWJJZCksXG4gICAgICAgICAgICAgICk7XG4gICAgICAgICAgICBjb25zdCBpc1ZhbGlkVmlzaXRTdGFydCA9XG4gICAgICAgICAgICAgIHR5cGVvZiBtc2cudGFiVmlzaXRTdGFydGVkQXQgPT09IFwibnVtYmVyXCIgJiZcbiAgICAgICAgICAgICAgbXNnLnRhYlZpc2l0U3RhcnRlZEF0ID49IHNlc3Npb25TdGFydCAmJlxuICAgICAgICAgICAgICBtc2cudGFiVmlzaXRTdGFydGVkQXQgPD0gbm93ICYmXG4gICAgICAgICAgICAgICFpc0luaGVyaXRlZEZyb21TaWJsaW5nO1xuICAgICAgICAgICAgY29uc3QgdmlzaXRTdGFydCA9XG4gICAgICAgICAgICAgIGlzVmFsaWRWaXNpdFN0YXJ0ICYmIHR5cGVvZiBtc2cudGFiVmlzaXRTdGFydGVkQXQgPT09IFwibnVtYmVyXCJcbiAgICAgICAgICAgICAgICA/IG1zZy50YWJWaXNpdFN0YXJ0ZWRBdFxuICAgICAgICAgICAgICAgIDogTWF0aC5tYXgobm93LCBzZXNzaW9uU3RhcnQpO1xuICAgICAgICAgICAgY3VycmVudFZpc2l0ID0ge1xuICAgICAgICAgICAgICBkb21haW46IHJlc3RyaWN0ZWREb21haW4sXG4gICAgICAgICAgICAgIGhvc3RuYW1lOiBob3N0LFxuICAgICAgICAgICAgICB0YWJJZDogcmF3VGFiSWQsXG4gICAgICAgICAgICAgIGluc3RhbmNlSWQsXG4gICAgICAgICAgICAgIHN0YXJ0ZWRBdDogdmlzaXRTdGFydCxcbiAgICAgICAgICAgICAgbGFzdEhlYXJ0YmVhdDogbm93LFxuICAgICAgICAgICAgICBpc1Zpc2libGUsXG4gICAgICAgICAgICB9O1xuICAgICAgICAgICAgYWN0aXZlVmlzaXRzW3RhYktleV0gPSBjdXJyZW50VmlzaXQ7XG4gICAgICAgICAgICBoYXNTdGF0ZUNoYW5nZSA9IHRydWU7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIC8vIFRhYiBpcyBjb250aW51aW5nIG9uIHRoZSBzYW1lIHJlc3RyaWN0ZWQgZG9tYWluIChlLmcuIHJlbG9hZCBvciBwZXJpb2RpYyBoZWFydGJlYXQpXG4gICAgICAgICAgICBjdXJyZW50VmlzaXQgPSBleGlzdGluZztcbiAgICAgICAgICAgIGN1cnJlbnRWaXNpdC5sYXN0SGVhcnRiZWF0ID0gbm93O1xuICAgICAgICAgICAgY3VycmVudFZpc2l0LmlzVmlzaWJsZSA9IGlzVmlzaWJsZTtcbiAgICAgICAgICAgIGlmIChpbnN0YW5jZUlkKSBjdXJyZW50VmlzaXQuaW5zdGFuY2VJZCA9IGluc3RhbmNlSWQ7XG4gICAgICAgICAgICBpZiAocmF3VGFiSWQgIT09IHVuZGVmaW5lZCAmJiBjdXJyZW50VmlzaXQudGFiSWQgPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgICBjdXJyZW50VmlzaXQudGFiSWQgPSByYXdUYWJJZDtcbiAgICAgICAgICAgICAgaGFzU3RhdGVDaGFuZ2UgPSB0cnVlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cblxuICAgICAgICAgIC8vIFNoYXJlZCBkb21haW4gc3Bhbjogb25lIHRpbWVsaW5lIHdoaWxlIGFueSBlbGlnaWJsZSB0YWIgb2YgdGhpcyBkb21haW4gaXMgb3BlblxuICAgICAgICAgIC8vIChmb3JlZ3JvdW5kIG9yIGJhY2tncm91bmQpLiBWaXNpYmlsaXR5IG11c3Qgbm90IHN0YXJ0L3N0b3AgdGhpcyBjbG9jay5cbiAgICAgICAgICBsZXQgc3BhbiA9IGRvbWFpblNwYW5zW3Jlc3RyaWN0ZWREb21haW5dO1xuICAgICAgICAgIGlmICghc3Bhbikge1xuICAgICAgICAgICAgLy8gV2hlbiBubyBsaXZlIGRvbWFpbiBzcGFuIGV4aXN0cywgb3BlbmluZyB0aGlzIGRvbWFpbiBzdGFydHMgYSBmcmVzaCBzcGFuLlxuICAgICAgICAgICAgLy8gSWYgYmFzZSB1c2FnZSBhbHJlYWR5IGFjY3VtdWxhdGVkIGZyb20gcHJpb3IgdmlzaXRzIGluIHRoaXMgc2Vzc2lvbixcbiAgICAgICAgICAgIC8vIHdlIG11c3QgYW5jaG9yIHRoZSBuZXcgc3BhbiB0byBtYXgobm93LCBzZXNzaW9uU3RhcnQpLCBOT1QgYmFja2RhdGUgdG8gY3VycmVudFZpc2l0LnN0YXJ0ZWRBdFxuICAgICAgICAgICAgLy8gYWNyb3NzIHRpbWUgYWxyZWFkeSBjb21taXR0ZWQgdG8gc2Vzc2lvblNpdGVVc2FnZSFcbiAgICAgICAgICAgIGNvbnN0IGluaXRpYWxTcGFuU3RhcnQgPVxuICAgICAgICAgICAgICAodXNhZ2VbcmVzdHJpY3RlZERvbWFpbl0gPz8gMCkgPiAwXG4gICAgICAgICAgICAgICAgPyBNYXRoLm1heChub3csIHNlc3Npb25TdGFydClcbiAgICAgICAgICAgICAgICA6IE1hdGgubWF4KHNlc3Npb25TdGFydCwgY3VycmVudFZpc2l0LnN0YXJ0ZWRBdCk7XG4gICAgICAgICAgICBzcGFuID0ge1xuICAgICAgICAgICAgICBzdGFydGVkQXQ6IGluaXRpYWxTcGFuU3RhcnQsXG4gICAgICAgICAgICAgIHRhYktleXM6IFt0YWJLZXldLFxuICAgICAgICAgICAgICBsYXN0SGVhcnRiZWF0OiBub3csXG4gICAgICAgICAgICB9O1xuICAgICAgICAgICAgZG9tYWluU3BhbnNbcmVzdHJpY3RlZERvbWFpbl0gPSBzcGFuO1xuICAgICAgICAgICAgaGFzU3RhdGVDaGFuZ2UgPSB0cnVlO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBzcGFuLmxhc3RIZWFydGJlYXQgPSBub3c7XG4gICAgICAgICAgICBpZiAoIXNwYW4udGFiS2V5cy5pbmNsdWRlcyh0YWJLZXkpKSB7XG4gICAgICAgICAgICAgIHNwYW4udGFiS2V5cy5wdXNoKHRhYktleSk7XG4gICAgICAgICAgICAgIGhhc1N0YXRlQ2hhbmdlID0gdHJ1ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG5cbiAgICAgICAgICAvLyBBbHdheXMgcGVyc2lzdCBzdGF0ZSBvbiBjaGVja19zaXRlIGZvciByZXN0cmljdGVkIHNpdGVzIHNvIGhlYXJ0YmVhdHMgYW5kIHZpc2l0IHRyYWNraW5nIGFyZSBuZXZlciBsb3N0XG4gICAgICAgICAgYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLnNldCh7XG4gICAgICAgICAgICBhY3RpdmVWaXNpdHMsXG4gICAgICAgICAgICBzZXNzaW9uU2l0ZVVzYWdlOiB1c2FnZSxcbiAgICAgICAgICAgIGRvbWFpblNwYW5zLFxuICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgY29uc3Qgc25hcHNob3ROb3cgPSBEYXRlLm5vdygpO1xuICAgICAgICAgIGN1cnJlbnRWaXNpdC5sYXN0SGVhcnRiZWF0ID0gc25hcHNob3ROb3c7XG4gICAgICAgICAgc3Bhbi5sYXN0SGVhcnRiZWF0ID0gc25hcHNob3ROb3c7XG5cbiAgICAgICAgICBjb25zdCBlZmZlY3RpdmVTcGFuU3RhcnQgPSBNYXRoLm1heChzcGFuLnN0YXJ0ZWRBdCwgc2Vzc2lvblN0YXJ0KTtcbiAgICAgICAgICBjb25zdCBhY3RpdmVEdXJhdGlvbiA9IE1hdGgubWF4KDAsIHNuYXBzaG90Tm93IC0gZWZmZWN0aXZlU3BhblN0YXJ0KTtcbiAgICAgICAgICBjb25zdCByYXdUb3RhbER1cmF0aW9uID0gKHVzYWdlW3Jlc3RyaWN0ZWREb21haW5dID8/IDApICsgYWN0aXZlRHVyYXRpb247XG4gICAgICAgICAgY29uc3QgbWF4U2Vzc2lvbk1zID0gTWF0aC5tYXgoMCwgc25hcHNob3ROb3cgLSBzZXNzaW9uU3RhcnQpO1xuICAgICAgICAgIGNvbnN0IHRvdGFsRHVyYXRpb25NcyA9IE1hdGgubWluKG1heFNlc3Npb25NcywgcmF3VG90YWxEdXJhdGlvbik7XG5cbiAgICAgICAgICBjb25zdCB0b3RhbFNpdGVVc2FnZVNlYyA9IE1hdGguZmxvb3IodG90YWxEdXJhdGlvbk1zIC8gMTAwMCk7XG4gICAgICAgICAgLy8gQ29uZmlybSBzbmFwc2hvdCB0aW1lc3RhbXAgYW5kIHVzYWdlIHZhbHVlIHJlZmVyIHRvIHRoZSBleGFjdCBzYW1lIGluc3RhbnQ6XG4gICAgICAgICAgLy8gdGhlIHByZWNpc2UgbWlsbGlzZWNvbmQgd2hlbiB0aGUgZG9tYWluIHJlYWNoZWQgdG90YWxTaXRlVXNhZ2VTZWMgd2hvbGUgc2Vjb25kcy5cbiAgICAgICAgICBjb25zdCB1c2FnZVNuYXBzaG90QXQgPSBzbmFwc2hvdE5vdyAtICh0b3RhbER1cmF0aW9uTXMgJSAxMDAwKTtcblxuICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBpc0FjdGl2ZTogdHJ1ZSxcbiAgICAgICAgICAgIG1vZGU6IGRhdGEubW9kZSA/PyBcIlwiLFxuICAgICAgICAgICAgc2Vzc2lvblN0YXJ0ZWRBdDogc2Vzc2lvblN0YXJ0LFxuICAgICAgICAgICAgaXNCbG9ja2VkOiBmYWxzZSxcbiAgICAgICAgICAgIGlzUmVzdHJpY3RlZDogdHJ1ZSxcbiAgICAgICAgICAgIGRvbWFpbjogcmVzdHJpY3RlZERvbWFpbixcbiAgICAgICAgICAgIHRhYklkOiByYXdUYWJJZCxcbiAgICAgICAgICAgIHZpc2l0U3RhcnRlZEF0OiBjdXJyZW50VmlzaXQuc3RhcnRlZEF0LFxuICAgICAgICAgICAgLy8gTmV2ZXIgc3Vic3RpdHV0ZSBhIHBlci10YWIgdmlzaXQgc3RhcnQgZm9yIGEgbWlzc2luZyBzaGFyZWQgc3BhblxuICAgICAgICAgICAgZG9tYWluU3BhblN0YXJ0ZWRBdDogc3Bhbi5zdGFydGVkQXQsXG4gICAgICAgICAgICBkb21haW5TdGFydGVkQXQ6IHNwYW4uc3RhcnRlZEF0LFxuICAgICAgICAgICAgYmFzZVNpdGVVc2FnZTogdXNhZ2VbcmVzdHJpY3RlZERvbWFpbl0gPz8gMCxcbiAgICAgICAgICAgIGJhc2VTaXRlVXNhZ2VNczogdXNhZ2VbcmVzdHJpY3RlZERvbWFpbl0gPz8gMCxcbiAgICAgICAgICAgIGJhc2VTaXRlVXNhZ2VTZWM6IE1hdGguZmxvb3IoKHVzYWdlW3Jlc3RyaWN0ZWREb21haW5dID8/IDApIC8gMTAwMCksXG4gICAgICAgICAgICB0b3RhbFNpdGVVc2FnZVNlYyxcbiAgICAgICAgICAgIHRvdGFsU2l0ZVVzYWdlTXM6IHRvdGFsRHVyYXRpb25NcyxcbiAgICAgICAgICAgIHVzYWdlU25hcHNob3RBdCxcbiAgICAgICAgICB9O1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKGhhc1N0YXRlQ2hhbmdlKSB7XG4gICAgICAgICAgYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLnNldCh7XG4gICAgICAgICAgICBhY3RpdmVWaXNpdHMsXG4gICAgICAgICAgICBzZXNzaW9uU2l0ZVVzYWdlOiB1c2FnZSxcbiAgICAgICAgICAgIGRvbWFpblNwYW5zLFxuICAgICAgICAgIH0pO1xuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICBpc0FjdGl2ZTogdHJ1ZSxcbiAgICAgICAgICBtb2RlOiBkYXRhLm1vZGUgPz8gXCJcIixcbiAgICAgICAgICBzZXNzaW9uU3RhcnRlZEF0OiBzZXNzaW9uU3RhcnQsXG4gICAgICAgICAgaXNCbG9ja2VkOiBmYWxzZSxcbiAgICAgICAgICBpc1Jlc3RyaWN0ZWQ6IGZhbHNlLFxuICAgICAgICAgIHZpc2l0U3RhcnRlZEF0OiAwLFxuICAgICAgICAgIGRvbWFpblN0YXJ0ZWRBdDogMCxcbiAgICAgICAgICBkb21haW5TcGFuU3RhcnRlZEF0OiAwLFxuICAgICAgICAgIGJhc2VTaXRlVXNhZ2U6IDAsXG4gICAgICAgICAgYmFzZVNpdGVVc2FnZU1zOiAwLFxuICAgICAgICAgIGJhc2VTaXRlVXNhZ2VTZWM6IDAsXG4gICAgICAgICAgdG90YWxTaXRlVXNhZ2VTZWM6IDAsXG4gICAgICAgIH07XG4gICAgICB9XG5cbiAgICAgIC8vIDUuIFRBQiBMRUFWSU5HIC8gVU5MT0FEXG4gICAgICBpZiAobXNnLm1lc3NhZ2UgPT09IFwidGFiX2xlYXZpbmdcIikge1xuICAgICAgICBjb25zdCByYXdUYWJJZCA9IHNlbmRlci50YWI/LmlkO1xuICAgICAgICBjb25zdCBpbnN0YW5jZUlkID0gbXNnLnRhYkluc3RhbmNlSWQgfHwgXCJcIjtcbiAgICAgICAgY29uc3QgdGFiSWRlbnRpZmllciA9XG4gICAgICAgICAgcmF3VGFiSWQgIT09IHVuZGVmaW5lZFxuICAgICAgICAgICAgPyBTdHJpbmcocmF3VGFiSWQpXG4gICAgICAgICAgICA6IGluc3RhbmNlSWQ7XG5cbiAgICAgICAgY29uc3QgZGF0YSA9IChhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuZ2V0KFtcbiAgICAgICAgICBcImFjdGl2ZVZpc2l0c1wiLFxuICAgICAgICAgIFwic2Vzc2lvblNpdGVVc2FnZVwiLFxuICAgICAgICAgIFwiZG9tYWluU3BhbnNcIixcbiAgICAgICAgICBcImlzQWN0aXZlXCIsXG4gICAgICAgICAgXCJzdGFydGVkQXRcIixcbiAgICAgICAgXSkpIGFzIEJhY2tncm91bmREYXRhO1xuXG4gICAgICAgIGlmICghZGF0YS5pc0FjdGl2ZSkgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSB9O1xuXG4gICAgICAgIGNvbnN0IGFjdGl2ZVZpc2l0cyA9IHsgLi4uKGRhdGEuYWN0aXZlVmlzaXRzID8/IHt9KSB9O1xuICAgICAgICBjb25zdCB1c2FnZSA9IHsgLi4uKGRhdGEuc2Vzc2lvblNpdGVVc2FnZSA/PyB7fSkgfTtcbiAgICAgICAgY29uc3QgZG9tYWluU3BhbnMgPSB7IC4uLihkYXRhLmRvbWFpblNwYW5zID8/IHt9KSB9O1xuICAgICAgICBjb25zdCBzZXNzaW9uU3RhcnQgPSBkYXRhLnN0YXJ0ZWRBdCAmJiBkYXRhLnN0YXJ0ZWRBdCA+IDAgPyBkYXRhLnN0YXJ0ZWRBdCA6IG5vdztcblxuICAgICAgICAvLyBDaGVjayBpZiB0YWIgaXMgYWxyZWFkeSBjbG9zZWQgaW4gYnJvd3NlclxuICAgICAgICBsZXQgaXNUYWJTdGlsbE9wZW4gPSBmYWxzZTtcbiAgICAgICAgaWYgKHJhd1RhYklkICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgY29uc3QgdGFiID0gYXdhaXQgYnJvd3Nlci50YWJzLmdldChyYXdUYWJJZCk7XG4gICAgICAgICAgICBpc1RhYlN0aWxsT3BlbiA9IEJvb2xlYW4odGFiKTtcbiAgICAgICAgICB9IGNhdGNoIHtcbiAgICAgICAgICAgIGlzVGFiU3RpbGxPcGVuID0gZmFsc2U7XG4gICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgbGV0IGNoYW5nZWQgPSBmYWxzZTtcbiAgICAgICAgbGV0IG9wZW5UYWJJZHM6IFNldDxzdHJpbmc+IHwgdW5kZWZpbmVkO1xuICAgICAgICBsZXQgb3BlbkRvbWFpbnM6IFNldDxzdHJpbmc+IHwgdW5kZWZpbmVkO1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGNvbnN0IG9wZW5UYWJzID0gYXdhaXQgYnJvd3Nlci50YWJzLnF1ZXJ5KHt9KTtcbiAgICAgICAgICBvcGVuVGFiSWRzID0gbmV3IFNldChvcGVuVGFicy5tYXAoKHQpID0+IFN0cmluZyh0LmlkKSkpO1xuICAgICAgICAgIGNvbnN0IHJlc3RyaWN0ZWRTaXRlcyA9IGRhdGEucmVzdHJpY3RlZFNpdGVzID8/IFtdO1xuICAgICAgICAgIG9wZW5Eb21haW5zID0gZXh0cmFjdE9wZW5Eb21haW5zKG9wZW5UYWJzLCByZXN0cmljdGVkU2l0ZXMpO1xuICAgICAgICB9IGNhdGNoIHt9XG5cbiAgICAgICAgaWYgKCFpc1RhYlN0aWxsT3Blbikge1xuICAgICAgICAgIC8vIFRhYiBpcyBjbG9zZWQsIGZpbmFsaXplIGltbWVkaWF0ZWx5XG4gICAgICAgICAgaWYgKHRhYklkZW50aWZpZXIpIHtcbiAgICAgICAgICAgIGNvbnN0IGMxID0gZmluYWxpemVWaXNpdChcbiAgICAgICAgICAgICAgYWN0aXZlVmlzaXRzLFxuICAgICAgICAgICAgICBkb21haW5TcGFucyxcbiAgICAgICAgICAgICAgdXNhZ2UsXG4gICAgICAgICAgICAgIHRhYklkZW50aWZpZXIsXG4gICAgICAgICAgICAgIG5vdyxcbiAgICAgICAgICAgICAgb3BlblRhYklkcyxcbiAgICAgICAgICAgICAgc2Vzc2lvblN0YXJ0LFxuICAgICAgICAgICAgICBvcGVuRG9tYWlucyxcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgICBpZiAoYzEpIGNoYW5nZWQgPSB0cnVlO1xuICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAvLyBUYWIgaXMgc3RpbGwgb3BlbiAocmVsb2FkaW5nIG9yIG5hdmlnYXRpbmcpIC0gdXBkYXRlIGhlYXJ0YmVhdCBzbyByZWxvYWQgY2FuIGNvbnRpbnVlIHNlYW1sZXNzbHlcbiAgICAgICAgICBmb3IgKGNvbnN0IFtrZXksIHZpc2l0XSBvZiBPYmplY3QuZW50cmllcyhhY3RpdmVWaXNpdHMpKSB7XG4gICAgICAgICAgICBpZiAoXG4gICAgICAgICAgICAgIGtleSA9PT0gdGFiSWRlbnRpZmllciB8fFxuICAgICAgICAgICAgICAodmlzaXQudGFiSWQgIT09IHVuZGVmaW5lZCAmJiBTdHJpbmcodmlzaXQudGFiSWQpID09PSB0YWJJZGVudGlmaWVyKVxuICAgICAgICAgICAgKSB7XG4gICAgICAgICAgICAgIHZpc2l0Lmxhc3RIZWFydGJlYXQgPSBub3c7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgLy8gQ2xlYW4gdXAgYW55IGRvbWFpbiBzcGFucyB0aGF0IGhhdmUgbm8gcmVtYWluaW5nIGVsaWdpYmxlIG9wZW4gdGFic1xuICAgICAgICBmb3IgKGNvbnN0IFtkb21haW4sIHNwYW5dIG9mIE9iamVjdC5lbnRyaWVzKGRvbWFpblNwYW5zKSkge1xuICAgICAgICAgIGlmICghaGFzRWxpZ2libGVWaXNpdEZvckRvbWFpbihhY3RpdmVWaXNpdHMsIGRvbWFpbiwgbm93LCBvcGVuVGFiSWRzLCBvcGVuRG9tYWlucykpIHtcbiAgICAgICAgICAgIGZpbmFsaXplRG9tYWluU3BhbihcbiAgICAgICAgICAgICAgZG9tYWluU3BhbnMsXG4gICAgICAgICAgICAgIHVzYWdlLFxuICAgICAgICAgICAgICBkb21haW4sXG4gICAgICAgICAgICAgIG5vdyxcbiAgICAgICAgICAgICAgc3Bhbi5sYXN0SGVhcnRiZWF0LFxuICAgICAgICAgICAgICBzZXNzaW9uU3RhcnQsXG4gICAgICAgICAgICApO1xuICAgICAgICAgICAgY2hhbmdlZCA9IHRydWU7XG4gICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgaWYgKGNoYW5nZWQpIHtcbiAgICAgICAgICBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuc2V0KHtcbiAgICAgICAgICAgIGFjdGl2ZVZpc2l0cyxcbiAgICAgICAgICAgIHNlc3Npb25TaXRlVXNhZ2U6IHVzYWdlLFxuICAgICAgICAgICAgZG9tYWluU3BhbnMsXG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4geyBzdWNjZXNzOiB0cnVlIH07XG4gICAgICB9XG5cbiAgICAgIC8vIDUuIEdFVCBTSVRFIFVTQUdFIChCQUNLV0FSRCBDT01QQVRJQklMSVRZKVxuICAgICAgaWYgKG1zZy5tZXNzYWdlID09PSBcImdldF9zaXRlX3VzYWdlXCIpIHtcbiAgICAgICAgY29uc3QgaG9zdCA9IG5vcm1hbGl6ZUhvc3QobXNnLmhvc3RuYW1lID8/IFwiXCIpO1xuICAgICAgICBjb25zdCBkYXRhID0gKGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5nZXQoW1xuICAgICAgICAgIFwicmVzdHJpY3RlZFNpdGVzXCIsXG4gICAgICAgICAgXCJzZXNzaW9uU2l0ZVVzYWdlXCIsXG4gICAgICAgICAgXCJkb21haW5TcGFuc1wiLFxuICAgICAgICBdKSkgYXMgQmFja2dyb3VuZERhdGE7XG5cbiAgICAgICAgY29uc3QgcmVzdHJpY3RlZFNpdGVzID0gZGF0YS5yZXN0cmljdGVkU2l0ZXMgPz8gW107XG4gICAgICAgIGNvbnN0IG1hdGNoZWREb21haW4gPSBmaW5kTWF0Y2hpbmdTaXRlKGhvc3QsIHJlc3RyaWN0ZWRTaXRlcykgPz8gaG9zdDtcbiAgICAgICAgY29uc3QgdXNhZ2UgPSBkYXRhLnNlc3Npb25TaXRlVXNhZ2UgPz8ge307XG4gICAgICAgIGNvbnN0IGRvbWFpblNwYW5zID0gZGF0YS5kb21haW5TcGFucyA/PyB7fTtcbiAgICAgICAgY29uc3Qgc3BhbiA9IGRvbWFpblNwYW5zW21hdGNoZWREb21haW5dO1xuICAgICAgICBjb25zdCBhY3RpdmVEdXJhdGlvbiA9IHNwYW4gPyBNYXRoLm1heCgwLCBub3cgLSBzcGFuLnN0YXJ0ZWRBdCkgOiAwO1xuXG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgdG90YWxEdXJhdGlvbjogKHVzYWdlW21hdGNoZWREb21haW5dID8/IDApICsgYWN0aXZlRHVyYXRpb24sXG4gICAgICAgIH07XG4gICAgICB9XG5cbiAgICAgIC8vIDYuIE9QRU4gREFTSEJPQVJEXG4gICAgICBpZiAobXNnLm1lc3NhZ2UgPT09IFwib3Blbl9kYXNoYm9hcmRcIikge1xuICAgICAgICBjb25zdCB1cmwgPSBicm93c2VyLnJ1bnRpbWUuZ2V0VVJMKFwiL2Rhc2hib2FyZC5odG1sXCIpO1xuICAgICAgICBhd2FpdCBicm93c2VyLnRhYnMuY3JlYXRlKHsgdXJsIH0pO1xuICAgICAgICByZXR1cm4geyBzdWNjZXNzOiB0cnVlIH07XG4gICAgICB9XG5cbiAgICAgIC8vIDcuIENMT1NFIENVUlJFTlQgVEFCXG4gICAgICBpZiAobXNnLm1lc3NhZ2UgPT09IFwiY2xvc2VfY3VycmVudF90YWJcIikge1xuICAgICAgICBpZiAoc2VuZGVyLnRhYj8uaWQgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgIGF3YWl0IGJyb3dzZXIudGFicy5yZW1vdmUoc2VuZGVyLnRhYi5pZCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSB9O1xuICAgICAgfVxuICAgIH0pLFxuICApO1xuXG4gIC8vIEZJTkFMSVpFIEEgVklTSVQgV0hFTiBBIFRBQiBOQVZJR0FURVMgQVdBWVxuICBicm93c2VyLnRhYnMub25VcGRhdGVkLmFkZExpc3RlbmVyKCh0YWJJZCwgY2hhbmdlSW5mbywgdGFiKSA9PiB7XG4gICAgY29uc3QgY2FuZGlkYXRlVXJsID0gY2hhbmdlSW5mby51cmwgfHwgdGFiLnVybDtcbiAgICBpZiAoIWNhbmRpZGF0ZVVybCkgcmV0dXJuO1xuXG4gICAgLy8gRGlzdGluZ3Vpc2ggdHJhbnNpZW50IG5hdmlnYXRpb24gc3RhdGVzIChhYm91dDpibGFuaywgZW1wdHkvbWlzc2luZyBob3N0KSBmcm9tIGNvbmZpcm1lZCBuYXZpZ2F0aW9uc1xuICAgIGNvbnN0IHRvcEhvc3QgPSBzYWZlRXh0cmFjdEhvc3QoY2FuZGlkYXRlVXJsKTtcbiAgICBpZiAoIXRvcEhvc3QpIHJldHVybjtcblxuICAgIHJ1blNlcmlhbChhc3luYyAoKSA9PiB7XG4gICAgICBjb25zdCBkYXRhID0gKGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5nZXQoW1xuICAgICAgICBcImFjdGl2ZVZpc2l0c1wiLFxuICAgICAgICBcInNlc3Npb25TaXRlVXNhZ2VcIixcbiAgICAgICAgXCJkb21haW5TcGFuc1wiLFxuICAgICAgICBcInJlc3RyaWN0ZWRTaXRlc1wiLFxuICAgICAgICBcImlzQWN0aXZlXCIsXG4gICAgICAgIFwic3RhcnRlZEF0XCIsXG4gICAgICBdKSkgYXMgQmFja2dyb3VuZERhdGE7XG5cbiAgICAgIGlmICghZGF0YS5pc0FjdGl2ZSkgcmV0dXJuO1xuXG4gICAgICBjb25zdCB0YWJLZXkgPSBTdHJpbmcodGFiSWQpO1xuICAgICAgY29uc3QgYWN0aXZlVmlzaXRzID0geyAuLi4oZGF0YS5hY3RpdmVWaXNpdHMgPz8ge30pIH07XG4gICAgICBjb25zdCB2aXNpdEtleSA9IE9iamVjdC5rZXlzKGFjdGl2ZVZpc2l0cykuZmluZChcbiAgICAgICAgKGspID0+IGsgPT09IHRhYktleSB8fCBhY3RpdmVWaXNpdHNba10/LnRhYklkID09PSB0YWJJZCxcbiAgICAgICk7XG4gICAgICBpZiAoIXZpc2l0S2V5KSByZXR1cm47XG4gICAgICBjb25zdCB2aXNpdCA9IGFjdGl2ZVZpc2l0c1t2aXNpdEtleV07XG4gICAgICBpZiAoIXZpc2l0KSByZXR1cm47XG5cbiAgICAgIGNvbnN0IHJlc3RyaWN0ZWRTaXRlcyA9IGRhdGEucmVzdHJpY3RlZFNpdGVzID8/IFtdO1xuICAgICAgY29uc3QgbmV3RG9tYWluID0gZmluZE1hdGNoaW5nU2l0ZSh0b3BIb3N0LCByZXN0cmljdGVkU2l0ZXMpO1xuXG4gICAgICAvLyBJZiB0aGUgdGFiIG5hdmlnYXRlZCBhd2F5IHRvIGFub3RoZXIgZG9tYWluIG9yIHVucmVzdHJpY3RlZCBzaXRlLCBmaW5hbGl6ZSBpdHMgdmlzaXRcbiAgICAgIGlmIChuZXdEb21haW4gIT09IHZpc2l0LmRvbWFpbikge1xuICAgICAgICBjb25zdCB1c2FnZSA9IHsgLi4uKGRhdGEuc2Vzc2lvblNpdGVVc2FnZSA/PyB7fSkgfTtcbiAgICAgICAgY29uc3QgZG9tYWluU3BhbnMgPSB7IC4uLihkYXRhLmRvbWFpblNwYW5zID8/IHt9KSB9O1xuICAgICAgICBjb25zdCBub3cgPSBEYXRlLm5vdygpO1xuICAgICAgICBjb25zdCBzZXNzaW9uU3RhcnQgPVxuICAgICAgICAgIGRhdGEuc3RhcnRlZEF0ICYmIGRhdGEuc3RhcnRlZEF0ID4gMCA/IGRhdGEuc3RhcnRlZEF0IDogbm93O1xuXG4gICAgICAgIGxldCBvcGVuVGFiSWRzOiBTZXQ8c3RyaW5nPiB8IHVuZGVmaW5lZDtcbiAgICAgICAgbGV0IG9wZW5Eb21haW5zOiBTZXQ8c3RyaW5nPiB8IHVuZGVmaW5lZDtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBjb25zdCBvcGVuVGFicyA9IGF3YWl0IGJyb3dzZXIudGFicy5xdWVyeSh7fSk7XG4gICAgICAgICAgb3BlblRhYklkcyA9IG5ldyBTZXQob3BlblRhYnMubWFwKCh0KSA9PiBTdHJpbmcodC5pZCkpKTtcbiAgICAgICAgICBvcGVuRG9tYWlucyA9IGV4dHJhY3RPcGVuRG9tYWlucyhvcGVuVGFicywgcmVzdHJpY3RlZFNpdGVzKTtcbiAgICAgICAgfSBjYXRjaCB7fVxuXG4gICAgICAgIGNvbnN0IGNoYW5nZWQgPSBmaW5hbGl6ZVZpc2l0KFxuICAgICAgICAgIGFjdGl2ZVZpc2l0cyxcbiAgICAgICAgICBkb21haW5TcGFucyxcbiAgICAgICAgICB1c2FnZSxcbiAgICAgICAgICB2aXNpdEtleSxcbiAgICAgICAgICBub3csXG4gICAgICAgICAgb3BlblRhYklkcyxcbiAgICAgICAgICBzZXNzaW9uU3RhcnQsXG4gICAgICAgICAgb3BlbkRvbWFpbnMsXG4gICAgICAgICk7XG5cbiAgICAgICAgaWYgKGNoYW5nZWQpIHtcbiAgICAgICAgICBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuc2V0KHtcbiAgICAgICAgICAgIGFjdGl2ZVZpc2l0cyxcbiAgICAgICAgICAgIHNlc3Npb25TaXRlVXNhZ2U6IHVzYWdlLFxuICAgICAgICAgICAgZG9tYWluU3BhbnMsXG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9KTtcbiAgfSk7XG5cbiAgLy8gRklOQUxJWkUgQSBWSVNJVCBXSEVOIElUUyBUQUIgQ0xPU0VTXG4gIGJyb3dzZXIudGFicy5vblJlbW92ZWQuYWRkTGlzdGVuZXIoKHRhYklkKSA9PlxuICAgIHJ1blNlcmlhbChhc3luYyAoKSA9PiB7XG4gICAgICBjb25zdCBkYXRhID0gKGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5nZXQoW1xuICAgICAgICBcImFjdGl2ZVZpc2l0c1wiLFxuICAgICAgICBcInNlc3Npb25TaXRlVXNhZ2VcIixcbiAgICAgICAgXCJkb21haW5TcGFuc1wiLFxuICAgICAgICBcImlzQWN0aXZlXCIsXG4gICAgICAgIFwic3RhcnRlZEF0XCIsXG4gICAgICAgIFwicmVzdHJpY3RlZFNpdGVzXCIsXG4gICAgICBdKSkgYXMgQmFja2dyb3VuZERhdGE7XG5cbiAgICAgIGlmICghZGF0YS5pc0FjdGl2ZSkgcmV0dXJuO1xuXG4gICAgICBjb25zdCB0YWJLZXkgPSBTdHJpbmcodGFiSWQpO1xuICAgICAgY29uc3QgYWN0aXZlVmlzaXRzID0geyAuLi4oZGF0YS5hY3RpdmVWaXNpdHMgPz8ge30pIH07XG4gICAgICBjb25zdCB1c2FnZSA9IHsgLi4uKGRhdGEuc2Vzc2lvblNpdGVVc2FnZSA/PyB7fSkgfTtcbiAgICAgIGNvbnN0IGRvbWFpblNwYW5zID0geyAuLi4oZGF0YS5kb21haW5TcGFucyA/PyB7fSkgfTtcbiAgICAgIGNvbnN0IG5vdyA9IERhdGUubm93KCk7XG4gICAgICBjb25zdCBzZXNzaW9uU3RhcnQgPSBkYXRhLnN0YXJ0ZWRBdCAmJiBkYXRhLnN0YXJ0ZWRBdCA+IDAgPyBkYXRhLnN0YXJ0ZWRBdCA6IG5vdztcblxuICAgICAgbGV0IG9wZW5UYWJJZHMgPSBuZXcgU2V0PHN0cmluZz4oKTtcbiAgICAgIGxldCBvcGVuRG9tYWlucyA9IG5ldyBTZXQ8c3RyaW5nPigpO1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3Qgb3BlblRhYnMgPSBhd2FpdCBicm93c2VyLnRhYnMucXVlcnkoe30pO1xuICAgICAgICBvcGVuVGFiSWRzID0gbmV3IFNldChvcGVuVGFicy5tYXAoKHQpID0+IFN0cmluZyh0LmlkKSkpO1xuICAgICAgICBjb25zdCByZXN0cmljdGVkU2l0ZXMgPSBkYXRhLnJlc3RyaWN0ZWRTaXRlcyA/PyBbXTtcbiAgICAgICAgb3BlbkRvbWFpbnMgPSBleHRyYWN0T3BlbkRvbWFpbnMob3BlblRhYnMsIHJlc3RyaWN0ZWRTaXRlcyk7XG4gICAgICB9IGNhdGNoIHt9XG5cbiAgICAgIGxldCBjaGFuZ2VkID0gZmluYWxpemVWaXNpdChcbiAgICAgICAgYWN0aXZlVmlzaXRzLFxuICAgICAgICBkb21haW5TcGFucyxcbiAgICAgICAgdXNhZ2UsXG4gICAgICAgIHRhYktleSxcbiAgICAgICAgbm93LFxuICAgICAgICBvcGVuVGFiSWRzLFxuICAgICAgICBzZXNzaW9uU3RhcnQsXG4gICAgICAgIG9wZW5Eb21haW5zLFxuICAgICAgKTtcblxuICAgICAgLy8gUmVjb25jaWxlIHdpdGggY3VycmVudGx5IG9wZW4gYnJvd3NlciB0YWJzIHRvIGd1YXJhbnRlZSBubyBvcnBoYW5lZCB2aXNpdHMgb3Igc3BhbnNcbiAgICAgIHRyeSB7XG4gICAgICAgIGZvciAoY29uc3QgW2tleSwgdmlzaXRdIG9mIE9iamVjdC5lbnRyaWVzKGFjdGl2ZVZpc2l0cykpIHtcbiAgICAgICAgICBjb25zdCB2VGFiSWQgPSB2aXNpdC50YWJJZCAhPT0gdW5kZWZpbmVkID8gU3RyaW5nKHZpc2l0LnRhYklkKSA6IGtleTtcbiAgICAgICAgICBpZiAoIW9wZW5UYWJJZHMuaGFzKHZUYWJJZCkpIHtcbiAgICAgICAgICAgIGNvbnN0IGNsb3NlZCA9IGZpbmFsaXplVmlzaXQoXG4gICAgICAgICAgICAgIGFjdGl2ZVZpc2l0cyxcbiAgICAgICAgICAgICAgZG9tYWluU3BhbnMsXG4gICAgICAgICAgICAgIHVzYWdlLFxuICAgICAgICAgICAgICBrZXksXG4gICAgICAgICAgICAgIG5vdyxcbiAgICAgICAgICAgICAgb3BlblRhYklkcyxcbiAgICAgICAgICAgICAgc2Vzc2lvblN0YXJ0LFxuICAgICAgICAgICAgICBvcGVuRG9tYWlucyxcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgICBpZiAoY2xvc2VkKSBjaGFuZ2VkID0gdHJ1ZTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICBmb3IgKGNvbnN0IFtkb21haW4sIHNwYW5dIG9mIE9iamVjdC5lbnRyaWVzKGRvbWFpblNwYW5zKSkge1xuICAgICAgICAgIGlmICghaGFzRWxpZ2libGVWaXNpdEZvckRvbWFpbihhY3RpdmVWaXNpdHMsIGRvbWFpbiwgbm93LCBvcGVuVGFiSWRzLCBvcGVuRG9tYWlucykpIHtcbiAgICAgICAgICAgIGZpbmFsaXplRG9tYWluU3BhbihcbiAgICAgICAgICAgICAgZG9tYWluU3BhbnMsXG4gICAgICAgICAgICAgIHVzYWdlLFxuICAgICAgICAgICAgICBkb21haW4sXG4gICAgICAgICAgICAgIG5vdyxcbiAgICAgICAgICAgICAgc3Bhbi5sYXN0SGVhcnRiZWF0LFxuICAgICAgICAgICAgICBzZXNzaW9uU3RhcnQsXG4gICAgICAgICAgICApO1xuICAgICAgICAgICAgY2hhbmdlZCA9IHRydWU7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgY29uc29sZS53YXJuKFwiUmVjb25jaWxlIGVycm9yIGluIG9uUmVtb3ZlZDpcIiwgZXJyKTtcbiAgICAgIH1cblxuICAgICAgaWYgKGNoYW5nZWQpIHtcbiAgICAgICAgYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLnNldCh7XG4gICAgICAgICAgYWN0aXZlVmlzaXRzLFxuICAgICAgICAgIHNlc3Npb25TaXRlVXNhZ2U6IHVzYWdlLFxuICAgICAgICAgIGRvbWFpblNwYW5zLFxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9KSxcbiAgKTtcblxuICAvLyBUcmFjayBmb2N1cyBmbGFncyBvbmx5IOKAlCBkbyBOT1Qgc3RhcnQvc3RvcCBzaGFyZWQgZG9tYWluIHNwYW5zIG9uIHRhYiBzd2l0Y2guXG4gIC8vIERvbWFpbiB1c2FnZSBjb250aW51ZXMgd2hpbGUgYW55IGVsaWdpYmxlIHRhYiBvZiB0aGUgZG9tYWluIHJlbWFpbnMgb3Blbi5cbiAgYnJvd3Nlci50YWJzLm9uQWN0aXZhdGVkLmFkZExpc3RlbmVyKChhY3RpdmVJbmZvKSA9PlxuICAgIHJ1blNlcmlhbChhc3luYyAoKSA9PiB7XG4gICAgICBjb25zdCBkYXRhID0gKGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5nZXQoW1xuICAgICAgICBcImFjdGl2ZVZpc2l0c1wiLFxuICAgICAgICBcImlzQWN0aXZlXCIsXG4gICAgICBdKSkgYXMgQmFja2dyb3VuZERhdGE7XG5cbiAgICAgIGlmICghZGF0YS5pc0FjdGl2ZSkgcmV0dXJuO1xuXG4gICAgICBjb25zdCBhY3RpdmVWaXNpdHMgPSB7IC4uLihkYXRhLmFjdGl2ZVZpc2l0cyA/PyB7fSkgfTtcbiAgICAgIGNvbnN0IG5vdyA9IERhdGUubm93KCk7XG4gICAgICBsZXQgY2hhbmdlZCA9IGZhbHNlO1xuICAgICAgY29uc3QgYWN0aXZhdGVkVGFiS2V5ID0gU3RyaW5nKGFjdGl2ZUluZm8udGFiSWQpO1xuXG4gICAgICBmb3IgKGNvbnN0IFtrZXksIHZpc2l0XSBvZiBPYmplY3QuZW50cmllcyhhY3RpdmVWaXNpdHMpKSB7XG4gICAgICAgIGNvbnN0IGlzVGhpc1RhYiA9IGtleSA9PT0gYWN0aXZhdGVkVGFiS2V5IHx8IHZpc2l0LnRhYklkID09PSBhY3RpdmVJbmZvLnRhYklkO1xuICAgICAgICBpZiAoaXNUaGlzVGFiKSB7XG4gICAgICAgICAgaWYgKCF2aXNpdC5pc1Zpc2libGUpIHtcbiAgICAgICAgICAgIHZpc2l0LmlzVmlzaWJsZSA9IHRydWU7XG4gICAgICAgICAgICB2aXNpdC5sYXN0SGVhcnRiZWF0ID0gbm93O1xuICAgICAgICAgICAgY2hhbmdlZCA9IHRydWU7XG4gICAgICAgICAgfVxuICAgICAgICB9IGVsc2UgaWYgKHZpc2l0LmlzVmlzaWJsZSkge1xuICAgICAgICAgIHZpc2l0LmlzVmlzaWJsZSA9IGZhbHNlO1xuICAgICAgICAgIGNoYW5nZWQgPSB0cnVlO1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIGlmIChjaGFuZ2VkKSB7XG4gICAgICAgIGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5zZXQoeyBhY3RpdmVWaXNpdHMgfSk7XG4gICAgICB9XG4gICAgfSksXG4gICk7XG5cbiAgLy8gQ0xFQU4gVVAgVklTSVRTIEFORCBTUEFOUyBXSEVOIEEgU0lURSBJUyBVTlJFU1RSSUNURURcbiAgYnJvd3Nlci5zdG9yYWdlLm9uQ2hhbmdlZC5hZGRMaXN0ZW5lcigoY2hhbmdlcywgYXJlYSkgPT4ge1xuICAgIGlmIChhcmVhICE9PSBcImxvY2FsXCIpIHJldHVybjtcbiAgICBjb25zdCByZXN0cmljdGVkU2l0ZXNDaGFuZ2UgPSBjaGFuZ2VzLnJlc3RyaWN0ZWRTaXRlcztcbiAgICBpZiAocmVzdHJpY3RlZFNpdGVzQ2hhbmdlKSB7XG4gICAgICB2b2lkIHJ1blNlcmlhbChhc3luYyAoKSA9PiB7XG4gICAgICAgIGNvbnN0IGRhdGEgPSAoYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLmdldChbXG4gICAgICAgICAgXCJhY3RpdmVWaXNpdHNcIixcbiAgICAgICAgICBcInNlc3Npb25TaXRlVXNhZ2VcIixcbiAgICAgICAgICBcImRvbWFpblNwYW5zXCIsXG4gICAgICAgICAgXCJpc0FjdGl2ZVwiLFxuICAgICAgICAgIFwic3RhcnRlZEF0XCIsXG4gICAgICAgIF0pKSBhcyBCYWNrZ3JvdW5kRGF0YTtcblxuICAgICAgICBpZiAoIWRhdGEuaXNBY3RpdmUpIHJldHVybjtcblxuICAgICAgICBjb25zdCBuZXdSZXN0cmljdGVkU2l0ZXM6IHN0cmluZ1tdID0gQXJyYXkuaXNBcnJheShyZXN0cmljdGVkU2l0ZXNDaGFuZ2UubmV3VmFsdWUpXG4gICAgICAgICAgPyAocmVzdHJpY3RlZFNpdGVzQ2hhbmdlLm5ld1ZhbHVlIGFzIHN0cmluZ1tdKVxuICAgICAgICAgIDogW107XG5cbiAgICAgICAgY29uc3QgYWN0aXZlVmlzaXRzID0geyAuLi4oZGF0YS5hY3RpdmVWaXNpdHMgPz8ge30pIH07XG4gICAgICAgIGNvbnN0IHVzYWdlID0geyAuLi4oZGF0YS5zZXNzaW9uU2l0ZVVzYWdlID8/IHt9KSB9O1xuICAgICAgICBjb25zdCBkb21haW5TcGFucyA9IHsgLi4uKGRhdGEuZG9tYWluU3BhbnMgPz8ge30pIH07XG4gICAgICAgIGNvbnN0IG5vdyA9IERhdGUubm93KCk7XG4gICAgICAgIGNvbnN0IHNlc3Npb25TdGFydCA9IGRhdGEuc3RhcnRlZEF0ICYmIGRhdGEuc3RhcnRlZEF0ID4gMCA/IGRhdGEuc3RhcnRlZEF0IDogbm93O1xuICAgICAgICBsZXQgY2hhbmdlZCA9IGZhbHNlO1xuXG4gICAgICAgIC8vIEZpbmFsaXplIHZpc2l0cyBmb3IgZG9tYWlucyBubyBsb25nZXIgaW4gcmVzdHJpY3RlZFNpdGVzXG4gICAgICAgIGZvciAoY29uc3QgW2tleSwgdmlzaXRdIG9mIE9iamVjdC5lbnRyaWVzKGFjdGl2ZVZpc2l0cykpIHtcbiAgICAgICAgICBjb25zdCBtYXRjaGVkID0gZmluZE1hdGNoaW5nU2l0ZSh2aXNpdC5kb21haW4sIG5ld1Jlc3RyaWN0ZWRTaXRlcyk7XG4gICAgICAgICAgaWYgKCFtYXRjaGVkKSB7XG4gICAgICAgICAgICBmaW5hbGl6ZVZpc2l0KGFjdGl2ZVZpc2l0cywgZG9tYWluU3BhbnMsIHVzYWdlLCBrZXksIG5vdyk7XG4gICAgICAgICAgICBjaGFuZ2VkID0gdHJ1ZTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICAvLyBGaW5hbGl6ZSBkb21haW4gc3BhbnMgZm9yIGRvbWFpbnMgbm8gbG9uZ2VyIGluIHJlc3RyaWN0ZWRTaXRlc1xuICAgICAgICBmb3IgKGNvbnN0IFtkb21haW4sIHNwYW5dIG9mIE9iamVjdC5lbnRyaWVzKGRvbWFpblNwYW5zKSkge1xuICAgICAgICAgIGNvbnN0IG1hdGNoZWQgPSBmaW5kTWF0Y2hpbmdTaXRlKGRvbWFpbiwgbmV3UmVzdHJpY3RlZFNpdGVzKTtcbiAgICAgICAgICBpZiAoIW1hdGNoZWQpIHtcbiAgICAgICAgICAgIGZpbmFsaXplRG9tYWluU3Bhbihkb21haW5TcGFucywgdXNhZ2UsIGRvbWFpbiwgbm93LCBub3csIHNlc3Npb25TdGFydCk7XG4gICAgICAgICAgICBjaGFuZ2VkID0gdHJ1ZTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICBpZiAoY2hhbmdlZCkge1xuICAgICAgICAgIGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5zZXQoe1xuICAgICAgICAgICAgYWN0aXZlVmlzaXRzLFxuICAgICAgICAgICAgc2Vzc2lvblNpdGVVc2FnZTogdXNhZ2UsXG4gICAgICAgICAgICBkb21haW5TcGFucyxcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfVxuICB9KTtcbn0pOyIsIi8vI3JlZ2lvbiBzcmMvaW5kZXgudHNcbi8qKlxuKiBDbGFzcyBmb3IgcGFyc2luZyBhbmQgcGVyZm9ybWluZyBvcGVyYXRpb25zIG9uIG1hdGNoIHBhdHRlcm5zLlxuKlxuKiBAZXhhbXBsZVxuKiAgIGNvbnN0IHBhdHRlcm4gPSBuZXcgTWF0Y2hQYXR0ZXJuKCcqOi8vZ29vZ2xlLmNvbS8qJyk7XG4qXG4qICAgcGF0dGVybi5pbmNsdWRlcygnaHR0cHM6Ly9nb29nbGUuY29tJyk7IC8vIHRydWVcbiogICBwYXR0ZXJuLmluY2x1ZGVzKCdodHRwOi8veW91dHViZS5jb20vd2F0Y2g/dj0xMjMnKTsgLy8gZmFsc2VcbiovXG52YXIgTWF0Y2hQYXR0ZXJuID0gY2xhc3MgTWF0Y2hQYXR0ZXJuIHtcblx0c3RhdGljIHtcblx0XHR0aGlzLlBST1RPQ09MUyA9IFtcblx0XHRcdFwiaHR0cFwiLFxuXHRcdFx0XCJodHRwc1wiLFxuXHRcdFx0XCJmaWxlXCIsXG5cdFx0XHRcImZ0cFwiLFxuXHRcdFx0XCJ1cm5cIixcblx0XHRcdFwid3NcIixcblx0XHRcdFwid3NzXCJcblx0XHRdO1xuXHR9XG5cdC8qKlxuXHQqIFBhcnNlIGEgbWF0Y2ggcGF0dGVybiBzdHJpbmcuIElmIGl0IGlzIGludmFsaWQsIHRoZSBjb25zdHJ1Y3RvciB3aWxsIHRocm93IGFuXG5cdCogYEludmFsaWRNYXRjaFBhdHRlcm5gIGVycm9yLlxuXHQqXG5cdCogQHBhcmFtIG1hdGNoUGF0dGVybiBUaGUgbWF0Y2ggcGF0dGVybiB0byBwYXJzZS5cblx0Ki9cblx0Y29uc3RydWN0b3IobWF0Y2hQYXR0ZXJuKSB7XG5cdFx0aWYgKG1hdGNoUGF0dGVybiA9PT0gXCI8YWxsX3VybHM+XCIpIHtcblx0XHRcdHRoaXMuaXNBbGxVcmxzID0gdHJ1ZTtcblx0XHRcdHRoaXMucHJvdG9jb2xNYXRjaGVzID0gWy4uLk1hdGNoUGF0dGVybi5QUk9UT0NPTFNdO1xuXHRcdFx0dGhpcy5ob3N0bmFtZU1hdGNoID0gXCIqXCI7XG5cdFx0XHR0aGlzLnBhdGhuYW1lTWF0Y2ggPSBcIipcIjtcblx0XHR9IGVsc2Uge1xuXHRcdFx0Y29uc3QgZ3JvdXBzID0gLyguKik6XFwvXFwvKC4qPykoXFwvLiopLy5leGVjKG1hdGNoUGF0dGVybik7XG5cdFx0XHRpZiAoZ3JvdXBzID09IG51bGwpIHRocm93IG5ldyBJbnZhbGlkTWF0Y2hQYXR0ZXJuKG1hdGNoUGF0dGVybiwgXCJJbmNvcnJlY3QgZm9ybWF0XCIpO1xuXHRcdFx0Y29uc3QgW18sIHByb3RvY29sLCBob3N0bmFtZSwgcGF0aG5hbWVdID0gZ3JvdXBzO1xuXHRcdFx0dmFsaWRhdGVQcm90b2NvbChtYXRjaFBhdHRlcm4sIHByb3RvY29sKTtcblx0XHRcdHZhbGlkYXRlSG9zdG5hbWUobWF0Y2hQYXR0ZXJuLCBob3N0bmFtZSk7XG5cdFx0XHR0aGlzLnByb3RvY29sTWF0Y2hlcyA9IHByb3RvY29sID09PSBcIipcIiA/IFtcImh0dHBcIiwgXCJodHRwc1wiXSA6IFtwcm90b2NvbF07XG5cdFx0XHR0aGlzLmhvc3RuYW1lTWF0Y2ggPSBob3N0bmFtZTtcblx0XHRcdHRoaXMucGF0aG5hbWVNYXRjaCA9IHBhdGhuYW1lO1xuXHRcdH1cblx0fVxuXHQvKiogQ2hlY2sgaWYgYSBVUkwgaXMgaW5jbHVkZWQgaW4gYSBwYXR0ZXJuLiAqL1xuXHRpbmNsdWRlcyh1cmwpIHtcblx0XHRjb25zdCB1ID0gdHlwZW9mIHVybCA9PT0gXCJzdHJpbmdcIiA/IG5ldyBVUkwodXJsKSA6IHVybCBpbnN0YW5jZW9mIExvY2F0aW9uID8gbmV3IFVSTCh1cmwuaHJlZikgOiB1cmw7XG5cdFx0aWYgKHRoaXMuaXNBbGxVcmxzKSByZXR1cm4gIXRoaXMuaXNVbmtub3duUHJvdG9jb2wodSk7XG5cdFx0cmV0dXJuICEhdGhpcy5wcm90b2NvbE1hdGNoZXMuZmluZCgocHJvdG9jb2wpID0+IHtcblx0XHRcdGlmIChwcm90b2NvbCA9PT0gXCJodHRwXCIpIHJldHVybiB0aGlzLmlzSHR0cE1hdGNoKHUpO1xuXHRcdFx0aWYgKHByb3RvY29sID09PSBcImh0dHBzXCIpIHJldHVybiB0aGlzLmlzSHR0cHNNYXRjaCh1KTtcblx0XHRcdGlmIChwcm90b2NvbCA9PT0gXCJmaWxlXCIpIHJldHVybiB0aGlzLmlzRmlsZU1hdGNoKHUpO1xuXHRcdFx0aWYgKHByb3RvY29sID09PSBcImZ0cFwiKSByZXR1cm4gdGhpcy5pc0Z0cE1hdGNoKHUpO1xuXHRcdFx0aWYgKHByb3RvY29sID09PSBcInVyblwiKSByZXR1cm4gdGhpcy5pc1Vybk1hdGNoKHUpO1xuXHRcdH0pO1xuXHR9XG5cdGlzSHR0cE1hdGNoKHVybCkge1xuXHRcdHJldHVybiB1cmwucHJvdG9jb2wgPT09IFwiaHR0cDpcIiAmJiB0aGlzLmlzSG9zdFBhdGhNYXRjaCh1cmwpO1xuXHR9XG5cdGlzSHR0cHNNYXRjaCh1cmwpIHtcblx0XHRyZXR1cm4gdXJsLnByb3RvY29sID09PSBcImh0dHBzOlwiICYmIHRoaXMuaXNIb3N0UGF0aE1hdGNoKHVybCk7XG5cdH1cblx0aXNIb3N0UGF0aE1hdGNoKHVybCkge1xuXHRcdGlmICghdGhpcy5ob3N0bmFtZU1hdGNoIHx8ICF0aGlzLnBhdGhuYW1lTWF0Y2gpIHJldHVybiBmYWxzZTtcblx0XHRjb25zdCBob3N0bmFtZU1hdGNoUmVnZXhzID0gW3RoaXMuY29udmVydFBhdHRlcm5Ub1JlZ2V4KHRoaXMuaG9zdG5hbWVNYXRjaCksIHRoaXMuY29udmVydFBhdHRlcm5Ub1JlZ2V4KHRoaXMuaG9zdG5hbWVNYXRjaC5yZXBsYWNlKC9eXFwqXFwuLywgXCJcIikpXTtcblx0XHRjb25zdCBwYXRobmFtZU1hdGNoUmVnZXggPSB0aGlzLmNvbnZlcnRQYXR0ZXJuVG9SZWdleCh0aGlzLnBhdGhuYW1lTWF0Y2gpO1xuXHRcdHJldHVybiAhIWhvc3RuYW1lTWF0Y2hSZWdleHMuZmluZCgocmVnZXgpID0+IHJlZ2V4LnRlc3QodXJsLmhvc3RuYW1lKSkgJiYgcGF0aG5hbWVNYXRjaFJlZ2V4LnRlc3QodXJsLnBhdGhuYW1lKTtcblx0fVxuXHRpc1Vua25vd25Qcm90b2NvbCh1cmwpIHtcblx0XHRyZXR1cm4gIXRoaXMucHJvdG9jb2xNYXRjaGVzLmluY2x1ZGVzKHVybC5wcm90b2NvbC5zbGljZSgwLCAtMSkpO1xuXHR9XG5cdGlzUGF0aE1hdGNoKHVybCkge1xuXHRcdGlmICghdGhpcy5wYXRobmFtZU1hdGNoKSByZXR1cm4gZmFsc2U7XG5cdFx0cmV0dXJuIHRoaXMuY29udmVydFBhdHRlcm5Ub1JlZ2V4KHRoaXMucGF0aG5hbWVNYXRjaCkudGVzdCh1cmwucGF0aG5hbWUpO1xuXHR9XG5cdGlzRmlsZU1hdGNoKHVybCkge1xuXHRcdHJldHVybiB1cmwucHJvdG9jb2wgPT09IFwiZmlsZTpcIiAmJiB0aGlzLmlzUGF0aE1hdGNoKHVybCk7XG5cdH1cblx0aXNGdHBNYXRjaChfdXJsKSB7XG5cdFx0dGhyb3cgRXJyb3IoXCJOb3QgaW1wbGVtZW50ZWQ6IGZ0cDovLyBwYXR0ZXJuIG1hdGNoaW5nLiBPcGVuIGEgUFIgdG8gYWRkIHN1cHBvcnRcIik7XG5cdH1cblx0aXNVcm5NYXRjaChfdXJsKSB7XG5cdFx0dGhyb3cgRXJyb3IoXCJOb3QgaW1wbGVtZW50ZWQ6IHVybjovLyBwYXR0ZXJuIG1hdGNoaW5nLiBPcGVuIGEgUFIgdG8gYWRkIHN1cHBvcnRcIik7XG5cdH1cblx0Y29udmVydFBhdHRlcm5Ub1JlZ2V4KHBhdHRlcm4pIHtcblx0XHRjb25zdCBzdGFyc1JlcGxhY2VkID0gdGhpcy5lc2NhcGVGb3JSZWdleChwYXR0ZXJuKS5yZXBsYWNlKC9cXFxcXFwqL2csIFwiLipcIik7XG5cdFx0cmV0dXJuIFJlZ0V4cChgXiR7c3RhcnNSZXBsYWNlZH0kYCk7XG5cdH1cblx0ZXNjYXBlRm9yUmVnZXgoc3RyaW5nKSB7XG5cdFx0cmV0dXJuIHN0cmluZy5yZXBsYWNlKC9bLiorP14ke30oKXxbXFxdXFxcXF0vZywgXCJcXFxcJCZcIik7XG5cdH1cbn07XG52YXIgSW52YWxpZE1hdGNoUGF0dGVybiA9IGNsYXNzIGV4dGVuZHMgRXJyb3Ige1xuXHRjb25zdHJ1Y3RvcihtYXRjaFBhdHRlcm4sIHJlYXNvbikge1xuXHRcdHN1cGVyKGBJbnZhbGlkIG1hdGNoIHBhdHRlcm4gXCIke21hdGNoUGF0dGVybn1cIjogJHtyZWFzb259YCk7XG5cdH1cbn07XG5mdW5jdGlvbiB2YWxpZGF0ZVByb3RvY29sKG1hdGNoUGF0dGVybiwgcHJvdG9jb2wpIHtcblx0aWYgKCFNYXRjaFBhdHRlcm4uUFJPVE9DT0xTLmluY2x1ZGVzKHByb3RvY29sKSAmJiBwcm90b2NvbCAhPT0gXCIqXCIpIHRocm93IG5ldyBJbnZhbGlkTWF0Y2hQYXR0ZXJuKG1hdGNoUGF0dGVybiwgYCR7cHJvdG9jb2x9IG5vdCBhIHZhbGlkIHByb3RvY29sICgke01hdGNoUGF0dGVybi5QUk9UT0NPTFMuam9pbihcIiwgXCIpfSlgKTtcbn1cbmZ1bmN0aW9uIHZhbGlkYXRlSG9zdG5hbWUobWF0Y2hQYXR0ZXJuLCBob3N0bmFtZSkge1xuXHRpZiAoaG9zdG5hbWUuaW5jbHVkZXMoXCI6XCIpKSB0aHJvdyBuZXcgSW52YWxpZE1hdGNoUGF0dGVybihtYXRjaFBhdHRlcm4sIGBIb3N0bmFtZSBjYW5ub3QgaW5jbHVkZSBhIHBvcnRgKTtcblx0aWYgKGhvc3RuYW1lLmluY2x1ZGVzKFwiKlwiKSAmJiBob3N0bmFtZS5sZW5ndGggPiAxICYmICFob3N0bmFtZS5zdGFydHNXaXRoKFwiKi5cIikpIHRocm93IG5ldyBJbnZhbGlkTWF0Y2hQYXR0ZXJuKG1hdGNoUGF0dGVybiwgYElmIHVzaW5nIGEgd2lsZGNhcmQgKCopLCBpdCBtdXN0IGdvIGF0IHRoZSBzdGFydCBvZiB0aGUgaG9zdG5hbWVgKTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgSW52YWxpZE1hdGNoUGF0dGVybiwgTWF0Y2hQYXR0ZXJuIH07XG4iXSwieF9nb29nbGVfaWdub3JlTGlzdCI6WzAsMSwyLDRdLCJtYXBwaW5ncyI6Ijs7Q0FDQSxTQUFTLGlCQUFpQixLQUFLO0VBQzlCLElBQUksT0FBTyxRQUFRLE9BQU8sUUFBUSxZQUFZLE9BQU8sRUFBRSxNQUFNLElBQUk7RUFDakUsT0FBTztDQUNSOzs7Ozs7Ozs7Ozs7Ozs7OztDRVlBLElBQU0sVURmaUIsV0FBVyxTQUFTLFNBQVMsS0FDaEQsV0FBVyxVQUNYLFdBQVc7OztDRTJDZixJQUFNLHdCQUFrQyxDQUFDO0NBQ3pDLElBQU0sMkJBQXFDLENBQUM7Q0FDNUMsSUFBYSxpQkFBaUI7Q0FDOUIsSUFBYSx1QkFBdUI7Q0FFcEMsU0FBZ0IsY0FBYyxNQUFzQjtFQUNsRCxJQUFJLENBQUMsTUFBTSxPQUFPO0VBQ2xCLE9BQU8sS0FDSixLQUFLLENBQUMsQ0FDTixZQUFZLENBQUMsQ0FDYixRQUFRLGdCQUFnQixFQUFFLENBQUMsQ0FDM0IsUUFBUSxVQUFVLEVBQUUsQ0FBQyxDQUNyQixRQUFRLFlBQVksRUFBRSxDQUFDLENBQ3ZCLEtBQUs7Q0FDVjtDQUVBLFNBQWdCLGlCQUFpQixVQUFrQixPQUFnQztFQUNqRixNQUFNLE9BQU8sY0FBYyxRQUFRO0VBQ25DLElBQUksQ0FBQyxNQUFNLE9BQU87RUFFbEIsTUFBTSxrQkFBa0IsTUFBTSxLQUFLLE1BQU0sY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sT0FBTztFQUN6RSxNQUFNLHlCQUF5QixnQkFBZ0IsTUFBTSxNQUFNLE1BQU0saUJBQWlCLE1BQU0sT0FBTztFQUUvRixLQUFLLE1BQU0sVUFBVSxpQkFBaUI7R0FDcEMsSUFBSSxDQUFDLFFBQVE7R0FDYixJQUFJLFNBQVMsVUFBVSxLQUFLLFNBQVMsSUFBSSxRQUFRLEdBQUc7SUFFbEQsS0FBSyxXQUFXLGlCQUFpQixXQUFXLFlBQVksd0JBQ3RELE9BQU87SUFFVCxPQUFPO0dBQ1Q7RUFDRjtFQUdBLElBQUksd0JBQ0U7T0FBQSxTQUFTLGlCQUFpQixLQUFLLFNBQVMsY0FBYyxLQUFLLFNBQVMsV0FBVyxLQUFLLFNBQVMsUUFBUSxHQUN2RyxPQUFPO0VBQUE7RUFJWCxPQUFPO0NBQ1Q7Q0FFQSxTQUFnQixnQkFBZ0IsUUFBZ0M7RUFDOUQsSUFBSSxDQUFDLFFBQVEsT0FBTztFQUNwQixJQUFJO0dBQ0YsTUFBTSxTQUFTLElBQUksSUFBSSxNQUFNO0dBQzdCLElBQUksT0FBTyxhQUFhLFdBQVcsT0FBTyxhQUFhLFVBQVUsT0FBTztHQUN4RSxJQUFJLENBQUMsT0FBTyxVQUFVLE9BQU87R0FDN0IsT0FBTyxjQUFjLE9BQU8sUUFBUTtFQUN0QyxRQUFRO0dBQ04sT0FBTztFQUNUO0NBQ0Y7Q0FFQSxTQUFnQixtQkFDZCxNQUNBLE9BQ2E7RUFDYixNQUFNLDBCQUFVLElBQUksSUFBWTtFQUNoQyxJQUFJLENBQUMsTUFBTSxRQUFRLElBQUksS0FBSyxDQUFDLE1BQU0sUUFBUSxLQUFLLEdBQUcsT0FBTztFQUMxRCxLQUFLLE1BQU0sT0FBTyxNQUFNO0dBQ3RCLE1BQU0sT0FBTyxnQkFBZ0IsSUFBSSxHQUFHO0dBQ3BDLElBQUksTUFBTTtJQUNSLE1BQU0sUUFBUSxpQkFBaUIsTUFBTSxLQUFLO0lBQzFDLElBQUksT0FDRixRQUFRLElBQUksS0FBSztHQUVyQjtFQUNGO0VBQ0EsT0FBTztDQUNUO0NBRUEsU0FBZ0IsZ0JBQ2QsT0FDQSxLQUNBLFlBQ1M7RUFFVCxJQUFJLE1BQU0sVUFBVSxLQUFBLEtBQWEsWUFDL0IsT0FBTyxXQUFXLElBQUksT0FBTyxNQUFNLEtBQUssQ0FBQztFQUUzQyxJQUFJLE1BQU0sVUFBVSxLQUFBLEtBQWEsQ0FBQyxZQUVoQyxPQUFPLE1BQU0sTUFBTSxpQkFBaUI7RUFFdEMsT0FBTyxNQUFNLE1BQU0saUJBQWlCO0NBQ3RDO0NBRUEsU0FBZ0IsMEJBQ2QsY0FDQSxRQUNBLEtBQ0EsWUFDQSxhQUNTO0VBQ1QsSUFBSSxlQUFlLFlBQVksSUFBSSxNQUFNLEdBQ3ZDLE9BQU87RUFFVCxPQUFPLE9BQU8sT0FBTyxZQUFZLENBQUMsQ0FBQyxNQUNoQyxNQUFNLEVBQUUsV0FBVyxVQUFVLGdCQUFnQixHQUFHLEtBQUssVUFBVSxDQUNsRTtDQUNGO0NBRUEsU0FBZ0IsbUJBQ2QsYUFDQSxPQUNBLFFBQ0EsS0FDQSxjQUNBLGNBQ1M7RUFDVCxNQUFNLE9BQU8sWUFBWTtFQUN6QixJQUFJLENBQUMsTUFBTSxPQUFPO0VBR2xCLE1BQU0sVUFDSixpQkFBaUIsS0FBQSxJQUFZLEtBQUssSUFBSSxLQUFLLFdBQVcsWUFBWSxJQUFJO0VBQ3hFLE1BQU0saUJBQ0osZ0JBQWdCLGVBQWUsSUFDM0IsS0FBSyxJQUFJLEtBQUssV0FBVyxZQUFZLElBQ3JDLEtBQUs7RUFDWCxNQUFNLFdBQVcsS0FBSyxJQUFJLEdBQUcsVUFBVSxjQUFjO0VBQ3JELElBQUksV0FBVyxHQUNiLE1BQU0sV0FBVyxNQUFNLFdBQVcsS0FBSztFQUV6QyxPQUFPLFlBQVk7RUFDbkIsT0FBTztDQUNUO0NBRUEsU0FBZ0IsY0FDZCxjQUNBLGFBQ0EsT0FDQSxlQUNBLEtBQ0EsWUFDQSxjQUNBLGFBQ1M7RUFDVCxJQUFJLENBQUMsZUFBZSxPQUFPO0VBQzNCLElBQUksVUFBVTtFQUNkLE1BQU0sbUNBQW1CLElBQUksSUFBWTtFQUV6QyxLQUFLLE1BQU0sQ0FBQyxLQUFLLFVBQVUsT0FBTyxRQUFRLFlBQVksR0FDcEQsSUFDRSxRQUFRLGlCQUNSLE1BQU0sZUFBZSxpQkFDcEIsTUFBTSxVQUFVLEtBQUEsS0FBYSxPQUFPLE1BQU0sS0FBSyxNQUFNLGVBQ3REO0dBQ0EsaUJBQWlCLElBQUksTUFBTSxNQUFNO0dBQ2pDLE9BQU8sYUFBYTtHQUNwQixVQUFVO0VBQ1o7RUFHRixLQUFLLE1BQU0sVUFBVSxrQkFBa0I7R0FDckMsTUFBTSxPQUFPLFlBQVk7R0FDekIsSUFBSSxNQUFNO0lBVVIsSUFBSSxDQVI2QiwwQkFDL0IsY0FDQSxRQUNBLEtBQ0EsWUFDQSxXQUdHLEdBQTBCO0tBQzdCLG1CQUNFLGFBQ0EsT0FDQSxRQUNBLEtBQ0EsS0FBQSxHQUNBLFlBQ0Y7S0FDQSxVQUFVO0lBQ1osT0FFRSxLQUFLLFVBQVUsT0FBTyxLQUFLLFlBQVksQ0FBQyxDQUFDLFFBQVEsTUFBTTtLQUNyRCxNQUFNLElBQUksYUFBYTtLQUN2QixPQUNFLE1BQU0sS0FBQSxLQUNOLEVBQUUsV0FBVyxVQUNiLGdCQUFnQixHQUFHLEtBQUssVUFBVTtJQUV0QyxDQUFDO0dBRUw7RUFDRjtFQUVBLE9BQU87Q0FDVDtDQUdBLElBQUksYUFBNEIsUUFBUSxRQUFRO0NBRWhELFNBQVMsVUFBYSxNQUFvQztFQUN4RCxNQUFNLFNBQVMsV0FBVyxXQUNsQixLQUFLLFNBQ0wsS0FBSyxDQUNiO0VBRUEsYUFBYSxPQUFPLFdBQ1osS0FBQSxTQUNBLEtBQUEsQ0FDUjtFQUVBLE9BQU87Q0FDVDtDQUVBLElBQUEscUJBQWUsdUJBQXVCO0VBRXBDLFVBQVUsWUFBWTtHQUNwQixJQUFJO0lBQ0YsTUFBTSxPQUFRLE1BQU0sUUFBUSxRQUFRLE1BQU0sSUFBSTtLQUM1QztLQUNBO0tBQ0E7S0FDQTtLQUNBO0tBQ0E7SUFDRixDQUFDO0lBRUQsTUFBTSxVQUErQixDQUFDO0lBRXRDLElBQUksS0FBSyxpQkFBaUIsS0FBQSxHQUN4QixRQUFRLGVBQWUsQ0FBQztTQUNuQixJQUNMLE1BQU0sUUFBUSxLQUFLLFlBQVksS0FDL0IsS0FBSyxhQUFhLFdBQVcsS0FDN0IsS0FBSyxhQUFhLFNBQVMsT0FBTyxLQUNsQyxLQUFLLGFBQWEsU0FBUyxhQUFhLEdBRXhDLFFBQVEsZUFBZSxDQUFDO0lBRzFCLElBQUksS0FBSyxvQkFBb0IsS0FBQSxHQUMzQixRQUFRLGtCQUFrQixDQUFDO1NBQ3RCLElBQ0wsTUFBTSxRQUFRLEtBQUssZUFBZSxLQUNsQyxLQUFLLGdCQUFnQixXQUFXLEtBQ2hDLEtBQUssZ0JBQWdCLFNBQVMsYUFBYSxLQUMzQyxLQUFLLGdCQUFnQixTQUFTLGVBQWUsR0FFN0MsUUFBUSxrQkFBa0IsQ0FBQztJQUc3QixJQUFJLEtBQUssZ0JBQWdCLE9BQU8sS0FBSyxLQUFLLFlBQVksQ0FBQyxDQUFDLFNBQVMsR0FBRztLQUNsRSxNQUFNLFdBQVcsTUFBTSxRQUFRLEtBQUssTUFBTSxDQUFDLENBQUM7S0FDNUMsTUFBTSxhQUFhLElBQUksSUFBSSxTQUFTLEtBQUssTUFBTSxPQUFPLEVBQUUsRUFBRSxDQUFDLENBQUM7S0FFNUQsTUFBTSxjQUFjLG1CQUFtQixVQURmLEtBQUssbUJBQW1CLENBQUMsQ0FDZTtLQUNoRSxNQUFNLGVBQWUsRUFBRSxHQUFJLEtBQUssZ0JBQWdCLENBQUMsRUFBRztLQUNwRCxNQUFNLFFBQVEsRUFBRSxHQUFJLEtBQUssb0JBQW9CLENBQUMsRUFBRztLQUNqRCxNQUFNLGNBQWMsRUFBRSxHQUFJLEtBQUssZUFBZSxDQUFDLEVBQUc7S0FDbEQsTUFBTSxNQUFNLEtBQUssSUFBSTtLQUNyQixJQUFJLFVBQVU7S0FFZCxLQUFLLE1BQU0sQ0FBQyxRQUFRLFVBQVUsT0FBTyxRQUFRLFlBQVksR0FBRztNQUMxRCxNQUFNLFdBQVcsTUFBTSxVQUFVLEtBQUEsSUFBWSxPQUFPLE1BQU0sS0FBSyxJQUFJO01BQ25FLElBQUksQ0FBQyxXQUFXLElBQUksUUFBUSxHQUFHO09BQzdCLGNBQ0UsY0FDQSxhQUNBLE9BQ0EsUUFDQSxNQUFNLGlCQUFpQixLQUN2QixZQUNBLEtBQUEsR0FDQSxXQUNGO09BQ0EsVUFBVTtNQUNaO0tBQ0Y7S0FFQSxLQUFLLE1BQU0sQ0FBQyxRQUFRLFNBQVMsT0FBTyxRQUFRLFdBQVcsR0FDckQsSUFBSSxDQUFDLDBCQUEwQixjQUFjLFFBQVEsS0FBSyxZQUFZLFdBQVcsR0FBRztNQUNsRixtQkFBbUIsYUFBYSxPQUFPLFFBQVEsS0FBSyxLQUFLLGFBQWE7TUFDdEUsVUFBVTtLQUNaO0tBR0YsSUFBSSxTQUFTO01BQ1gsUUFBUSxlQUFlO01BQ3ZCLFFBQVEsbUJBQW1CO01BQzNCLFFBQVEsY0FBYztLQUN4QjtJQUNGO0lBRUEsSUFBSSxPQUFPLEtBQUssT0FBTyxDQUFDLENBQUMsU0FBUyxHQUNoQyxNQUFNLFFBQVEsUUFBUSxNQUFNLElBQUksT0FBTztHQUUzQyxTQUFTLEdBQUc7SUFDVixRQUFRLEtBQUssdUNBQXVDLENBQUM7R0FDdkQ7RUFDRixDQUFDO0VBRUQsUUFBUSxRQUFRLFVBQVUsYUFBYSxLQUFjLFdBQ25ELFVBQVUsWUFBWTtHQUNwQixNQUFNLE1BQU0sS0FBSyxJQUFJO0dBR3JCLElBQUksSUFBSSxZQUFZLGlCQUFpQjtJQUNuQyxJQUFJLElBQUksU0FBUyxXQUFXLElBQUksU0FBUyxZQUN2QyxPQUFPO0tBQUUsU0FBUztLQUFPLE9BQU87SUFBdUI7SUFHekQsTUFBTSxTQUFVLE1BQU0sUUFBUSxRQUFRLE1BQU0sSUFBSTtLQUM5QztLQUNBO0tBQ0E7S0FDQTtJQUNGLENBQUM7SUFFRCxJQUFJLE9BQU8sVUFDVCxPQUFPO0tBQUUsU0FBUztLQUFPLE9BQU87SUFBOEI7SUFHaEUsTUFBTSxpQkFBc0M7S0FDMUMsVUFBVTtLQUNWLE1BQU0sSUFBSTtLQUNWLFdBQVc7S0FDWCxjQUFjLENBQUM7S0FDZixrQkFBa0IsQ0FBQztLQUNuQixhQUFhLENBQUM7SUFDaEI7SUFDQSxJQUFJLE9BQU8saUJBQWlCLEtBQUEsR0FDMUIsZUFBZSxlQUFlO0lBRWhDLElBQUksT0FBTyxvQkFBb0IsS0FBQSxHQUM3QixlQUFlLGtCQUFrQjtJQUVuQyxNQUFNLFFBQVEsUUFBUSxNQUFNLElBQUksY0FBYztJQUU5QyxPQUFPO0tBQUUsU0FBUztLQUFNLFdBQVc7SUFBSTtHQUN6QztHQUdBLElBQUksSUFBSSxZQUFZLGdCQUFnQjtJQUNsQyxNQUFNLE9BQVEsTUFBTSxRQUFRLFFBQVEsTUFBTSxJQUFJO0tBQzVDO0tBQ0E7S0FDQTtLQUNBO0tBQ0E7S0FDQTtLQUNBO0lBQ0YsQ0FBQztJQUVELElBQUksQ0FBQyxLQUFLLFlBQVksQ0FBQyxLQUFLLFdBQzFCLE9BQU87S0FBRSxTQUFTO0tBQU8sT0FBTztJQUFvQjtJQUd0RCxNQUFNLFFBQVEsRUFBRSxHQUFJLEtBQUssb0JBQW9CLENBQUMsRUFBRztJQUNqRCxNQUFNLGNBQWMsRUFBRSxHQUFJLEtBQUssZUFBZSxDQUFDLEVBQUc7SUFHbEQsS0FBSyxNQUFNLFVBQVUsT0FBTyxLQUFLLFdBQVcsR0FDMUMsbUJBQ0UsYUFDQSxPQUNBLFFBQ0EsS0FDQSxLQUNBLEtBQUssU0FDUDtJQUdGLE1BQU0sU0FBd0I7S0FDNUIsTUFBTSxLQUFLLFFBQVE7S0FDbkIsV0FBVyxLQUFLO0tBQ2hCLFNBQVM7S0FDVCxVQUFVLE1BQU0sS0FBSztLQUNyQixXQUFXO0lBQ2I7SUFFQSxNQUFNLFNBQVMsTUFBTTtJQUdyQixNQUFNLFdBQVcsQ0FGSSxHQUFJLEtBQUssWUFBWSxDQUFDLEdBQUksTUFFOUIsQ0FBQSxDQUFZLFFBQVEsTUFBTSxFQUFFLGFBQWEsTUFBTTtJQUVoRSxNQUFNLFFBQVEsUUFBUSxNQUFNLElBQUk7S0FDOUIsVUFBVTtLQUNWLFdBQVc7S0FDWCxNQUFNO0tBQ047S0FDQSxjQUFjLENBQUM7S0FDZixrQkFBa0IsQ0FBQztLQUNuQixhQUFhLENBQUM7SUFDaEIsQ0FBQztJQUVELE9BQU8sRUFBRSxTQUFTLEtBQUs7R0FDekI7R0FHQSxJQUFJLElBQUksWUFBWSxlQUFlO0lBQ2pDLE1BQU0sT0FBUSxNQUFNLFFBQVEsUUFBUSxNQUFNLElBQUk7S0FDNUM7S0FDQTtLQUNBO0lBQ0YsQ0FBQztJQUVELE9BQU87S0FDTCxVQUFVLFFBQVEsS0FBSyxRQUFRO0tBQy9CLFdBQVcsS0FBSyxZQUFZLEtBQUssWUFBWSxLQUFLLFlBQVk7S0FDOUQsYUFDRSxLQUFLLFlBQVksS0FBSyxZQUFZLEtBQUssSUFBSSxHQUFHLE1BQU0sS0FBSyxTQUFTLElBQUk7S0FDeEUsTUFBTSxLQUFLLFFBQVE7SUFDckI7R0FDRjtHQUdBLElBQUksSUFBSSxZQUFZLGNBQWM7SUFDbEIsT0FBTyxLQUFLO0lBRTFCLE1BQU0sT0FBTyxjQURPLElBQUksWUFBWSxFQUNFO0lBRXRDLE1BQU0sT0FBUSxNQUFNLFFBQVEsUUFBUSxNQUFNLElBQUk7S0FDNUM7S0FDQTtLQUNBO0tBQ0E7S0FDQTtLQUNBO0tBQ0E7S0FDQTtJQUNGLENBQUM7SUFFRCxJQUFJLENBQUMsS0FBSyxVQUNSLE9BQU87S0FDTCxVQUFVO0tBQ1YsTUFBTTtLQUNOLGtCQUFrQjtLQUNsQixXQUFXO0tBQ1gsY0FBYztLQUNkLGdCQUFnQjtLQUNoQixpQkFBaUI7S0FDakIscUJBQXFCO0tBQ3JCLGVBQWU7S0FDZixpQkFBaUI7S0FDakIsa0JBQWtCO0tBQ2xCLG1CQUFtQjtJQUNyQjtJQUdGLE1BQU0sZUFDSixPQUFPLEtBQUssY0FBYyxZQUFZLEtBQUssWUFBWSxJQUNuRCxLQUFLLFlBQ0w7SUFFTixJQUFJLENBQUMsS0FBSyxXQUNSLE1BQU0sUUFBUSxRQUFRLE1BQU0sSUFBSSxFQUFFLFdBQVcsYUFBYSxDQUFDO0lBRzdELE1BQU0sZUFBZSxLQUFLLGdCQUFnQixDQUFDO0lBQzNDLE1BQU0sa0JBQWtCLEtBQUssbUJBQW1CLENBQUM7SUFFakQsTUFBTSxnQkFDSixLQUFLLFNBQVMsVUFBVSxpQkFBaUIsTUFBTSxZQUFZLElBQUk7SUFDakUsTUFBTSxtQkFDSixDQUFDLGdCQUFnQixpQkFBaUIsTUFBTSxlQUFlLElBQUk7SUFFN0QsSUFBSSxlQUNGLE9BQU87S0FDTCxVQUFVO0tBQ1YsTUFBTSxLQUFLLFFBQVE7S0FDbkIsa0JBQWtCO0tBQ2xCLFdBQVc7S0FDWCxjQUFjO0tBQ2QsZ0JBQWdCO0tBQ2hCLGlCQUFpQjtLQUNqQixxQkFBcUI7S0FDckIsZUFBZTtLQUNmLGlCQUFpQjtLQUNqQixrQkFBa0I7S0FDbEIsbUJBQW1CO0lBQ3JCO0lBR0YsTUFBTSxlQUFlLEVBQUUsR0FBSSxLQUFLLGdCQUFnQixDQUFDLEVBQUc7SUFDcEQsTUFBTSxRQUFRLEVBQUUsR0FBSSxLQUFLLG9CQUFvQixDQUFDLEVBQUc7SUFDakQsTUFBTSxjQUFjLEVBQUUsR0FBSSxLQUFLLGVBQWUsQ0FBQyxFQUFHO0lBQ2xELE1BQU0sV0FBVyxPQUFPLEtBQUs7SUFDN0IsTUFBTSxhQUFhLElBQUksaUJBQWlCO0lBQ3hDLE1BQU0sWUFBWSxJQUFJLGNBQWM7SUFDcEMsTUFBTSxTQUNKLGFBQWEsS0FBQSxJQUNULE9BQU8sUUFBUSxJQUNkLGVBQWUsT0FBTyxPQUFPLFNBQVM7SUFDN0MsSUFBSSxpQkFBaUI7SUFHckIsSUFBSSxhQUFhLEtBQUEsS0FBYSxZQUN2QjtVQUFBLE1BQU0sQ0FBQyxHQUFHLE1BQU0sT0FBTyxRQUFRLFlBQVksR0FDOUMsSUFBSSxNQUFNLFdBQVcsTUFBTSxjQUFjLEVBQUUsVUFBVSxLQUFBLE1BQWMsRUFBRSxlQUFlLFlBQVk7TUFDOUYsT0FBTyxhQUFhO01BQ3BCLGlCQUFpQjtLQUNuQjs7SUFLSixJQUFJLDZCQUFhLElBQUksSUFBWTtJQUNqQyxJQUFJLDhCQUFjLElBQUksSUFBWTtJQUNsQyxJQUFJO0tBQ0YsTUFBTSxXQUFXLE1BQU0sUUFBUSxLQUFLLE1BQU0sQ0FBQyxDQUFDO0tBQzVDLGFBQWEsSUFBSSxJQUFJLFNBQVMsS0FBSyxNQUFNLE9BQU8sRUFBRSxFQUFFLENBQUMsQ0FBQztLQUN0RCxjQUFjLG1CQUFtQixVQUFVLGVBQWU7S0FHMUQsSUFBSSxhQUFhLEtBQUEsS0FBYSxXQUFXLE9BQU8sS0FBSyxDQUFDLFdBQVcsSUFBSSxPQUFPLFFBQVEsQ0FBQyxHQUNuRixPQUFPO01BQ0wsVUFBVTtNQUNWLE1BQU0sS0FBSyxRQUFRO01BQ25CLGtCQUFrQjtNQUNsQixXQUFXO01BQ1gsY0FBYztNQUNkLGdCQUFnQjtNQUNoQixpQkFBaUI7TUFDakIscUJBQXFCO01BQ3JCLGVBQWU7TUFDZixpQkFBaUI7TUFDakIsa0JBQWtCO01BQ2xCLG1CQUFtQjtLQUNyQjtLQUdGLEtBQUssTUFBTSxDQUFDLEdBQUcsTUFBTSxPQUFPLFFBQVEsWUFBWSxHQUFHO01BQ2pELE1BQU0sU0FBUyxFQUFFLFVBQVUsS0FBQSxJQUFZLE9BQU8sRUFBRSxLQUFLLElBQUk7TUFDekQsSUFBSSxNQUFNLFVBQVUsRUFBRSxVQUFVLEtBQUEsS0FBYSxDQUFDLFdBQVcsSUFBSSxNQUFNLEdBQUc7T0FDcEUsY0FDRSxjQUNBLGFBQ0EsT0FDQSxHQUNBLEVBQUUsaUJBQWlCLEtBQ25CLFlBQ0EsY0FDQSxXQUNGO09BQ0EsaUJBQWlCO01BQ25CO0tBQ0Y7SUFDRixRQUFRLENBQUM7SUFJVCxLQUFLLE1BQU0sQ0FBQyxHQUFHLE1BQU0sT0FBTyxRQUFRLFlBQVksR0FBRztLQUNqRCxJQUFJLE1BQU0sUUFBUTtLQUNsQixNQUFNLFNBQVMsRUFBRSxVQUFVLEtBQUEsSUFBWSxPQUFPLEVBQUUsS0FBSyxJQUFJO0tBQ3pELE1BQU0sWUFBWSxFQUFFLFVBQVUsS0FBQSxLQUFhLFdBQVcsSUFBSSxNQUFNO0tBQ2hFLElBQUksQ0FBQyxhQUFhLE1BQU0sRUFBRSxnQkFBQSxLQUFzQztNQUM5RCxjQUNFLGNBQ0EsYUFDQSxPQUNBLEdBQ0EsRUFBRSxpQkFBaUIsS0FDbkIsWUFDQSxjQUNBLFdBQ0Y7TUFDQSxpQkFBaUI7S0FDbkIsT0FBTyxJQUFJLGFBQWEsTUFBTSxFQUFFLGdCQUFBLEtBQzFCO1VBQUEsRUFBRSxXQUFXO09BQ2YsRUFBRSxZQUFZO09BQ2QsaUJBQWlCO01BQ25COztJQUVKO0lBR0EsS0FBSyxNQUFNLENBQUMsUUFBUSxTQUFTLE9BQU8sUUFBUSxXQUFXLEdBQ3JELElBQUksQ0FBQywwQkFBMEIsY0FBYyxRQUFRLEtBQUssWUFBWSxXQUFXLEdBQUc7S0FDbEYsbUJBQ0UsYUFDQSxPQUNBLFFBQ0EsS0FDQSxLQUFLLGVBQ0wsWUFDRjtLQUNBLGlCQUFpQjtJQUNuQjtJQUdGLElBQUksV0FBVyxhQUFhO0lBRzVCLElBQUksWUFBWSxTQUFTLFlBQVksY0FBYztLQUNqRCxPQUFPLGFBQWE7S0FDcEIsV0FBVyxLQUFBO0lBQ2I7SUFHQSxJQUFJLGtCQUFrQjtLQUNwQixNQUFNLFlBQVksWUFBWTtLQUM5QixJQUFJLGFBQWEsVUFBVSxZQUFZLGNBQWM7TUFDbkQsT0FBTyxZQUFZO01BQ25CLGlCQUFpQjtLQUNuQjtJQUNGO0lBR0EsSUFBSSxZQUFZLFNBQVMsV0FBVyxrQkFDbEI7U0FBQSxjQUNkLGNBQ0EsYUFDQSxPQUNBLFFBQ0EsS0FDQSxZQUNBLGNBQ0EsV0FFRSxHQUFTLGlCQUFpQjtJQUFBO0lBR2hDLElBQUksa0JBQWtCO0tBRXBCLE1BQU0sa0JBQ0osYUFBYSxLQUFBLEtBQ2IsU0FBUyxXQUFXLG9CQUNwQixTQUFTLGFBQWE7S0FFeEIsSUFBSTtLQUNKLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxVQUFVO01BRWpDLElBQUksVUFDRixjQUNFLGNBQ0EsYUFDQSxPQUNBLFFBQ0EsU0FBUyxpQkFBaUIsS0FDMUIsWUFDQSxjQUNBLFdBQ0Y7TUFJRixNQUFNLHlCQUNKLE9BQU8sSUFBSSxzQkFBc0IsWUFDakMsT0FBTyxPQUFPLFlBQVksQ0FBQyxDQUFDLE1BQ3pCLE1BQ0MsRUFBRSxjQUFjLElBQUksc0JBQ25CLGFBQWEsS0FBQSxLQUFhLEVBQUUsVUFBVSxTQUMzQztNQVVGLGVBQWU7T0FDYixRQUFRO09BQ1IsVUFBVTtPQUNWLE9BQU87T0FDUDtPQUNBLFdBYkEsT0FBTyxJQUFJLHNCQUFzQixZQUNqQyxJQUFJLHFCQUFxQixnQkFDekIsSUFBSSxxQkFBcUIsT0FDekIsQ0FBQywwQkFFb0IsT0FBTyxJQUFJLHNCQUFzQixXQUNsRCxJQUFJLG9CQUNKLEtBQUssSUFBSSxLQUFLLFlBQVk7T0FPOUIsZUFBZTtPQUNmO01BQ0Y7TUFDQSxhQUFhLFVBQVU7TUFDdkIsaUJBQWlCO0tBQ25CLE9BQU87TUFFTCxlQUFlO01BQ2YsYUFBYSxnQkFBZ0I7TUFDN0IsYUFBYSxZQUFZO01BQ3pCLElBQUksWUFBWSxhQUFhLGFBQWE7TUFDMUMsSUFBSSxhQUFhLEtBQUEsS0FBYSxhQUFhLFVBQVUsS0FBQSxHQUFXO09BQzlELGFBQWEsUUFBUTtPQUNyQixpQkFBaUI7TUFDbkI7S0FDRjtLQUlBLElBQUksT0FBTyxZQUFZO0tBQ3ZCLElBQUksQ0FBQyxNQUFNO01BU1QsT0FBTztPQUNMLFlBSkMsTUFBTSxxQkFBcUIsS0FBSyxJQUM3QixLQUFLLElBQUksS0FBSyxZQUFZLElBQzFCLEtBQUssSUFBSSxjQUFjLGFBQWEsU0FBUztPQUdqRCxTQUFTLENBQUMsTUFBTTtPQUNoQixlQUFlO01BQ2pCO01BQ0EsWUFBWSxvQkFBb0I7TUFDaEMsaUJBQWlCO0tBQ25CLE9BQU87TUFDTCxLQUFLLGdCQUFnQjtNQUNyQixJQUFJLENBQUMsS0FBSyxRQUFRLFNBQVMsTUFBTSxHQUFHO09BQ2xDLEtBQUssUUFBUSxLQUFLLE1BQU07T0FDeEIsaUJBQWlCO01BQ25CO0tBQ0Y7S0FHQSxNQUFNLFFBQVEsUUFBUSxNQUFNLElBQUk7TUFDOUI7TUFDQSxrQkFBa0I7TUFDbEI7S0FDRixDQUFDO0tBRUQsTUFBTSxjQUFjLEtBQUssSUFBSTtLQUM3QixhQUFhLGdCQUFnQjtLQUM3QixLQUFLLGdCQUFnQjtLQUVyQixNQUFNLHFCQUFxQixLQUFLLElBQUksS0FBSyxXQUFXLFlBQVk7S0FDaEUsTUFBTSxpQkFBaUIsS0FBSyxJQUFJLEdBQUcsY0FBYyxrQkFBa0I7S0FDbkUsTUFBTSxvQkFBb0IsTUFBTSxxQkFBcUIsS0FBSztLQUMxRCxNQUFNLGVBQWUsS0FBSyxJQUFJLEdBQUcsY0FBYyxZQUFZO0tBQzNELE1BQU0sa0JBQWtCLEtBQUssSUFBSSxjQUFjLGdCQUFnQjtLQUUvRCxNQUFNLG9CQUFvQixLQUFLLE1BQU0sa0JBQWtCLEdBQUk7S0FHM0QsTUFBTSxrQkFBa0IsY0FBZSxrQkFBa0I7S0FFekQsT0FBTztNQUNMLFVBQVU7TUFDVixNQUFNLEtBQUssUUFBUTtNQUNuQixrQkFBa0I7TUFDbEIsV0FBVztNQUNYLGNBQWM7TUFDZCxRQUFRO01BQ1IsT0FBTztNQUNQLGdCQUFnQixhQUFhO01BRTdCLHFCQUFxQixLQUFLO01BQzFCLGlCQUFpQixLQUFLO01BQ3RCLGVBQWUsTUFBTSxxQkFBcUI7TUFDMUMsaUJBQWlCLE1BQU0scUJBQXFCO01BQzVDLGtCQUFrQixLQUFLLE9BQU8sTUFBTSxxQkFBcUIsS0FBSyxHQUFJO01BQ2xFO01BQ0Esa0JBQWtCO01BQ2xCO0tBQ0Y7SUFDRjtJQUVBLElBQUksZ0JBQ0YsTUFBTSxRQUFRLFFBQVEsTUFBTSxJQUFJO0tBQzlCO0tBQ0Esa0JBQWtCO0tBQ2xCO0lBQ0YsQ0FBQztJQUdILE9BQU87S0FDTCxVQUFVO0tBQ1YsTUFBTSxLQUFLLFFBQVE7S0FDbkIsa0JBQWtCO0tBQ2xCLFdBQVc7S0FDWCxjQUFjO0tBQ2QsZ0JBQWdCO0tBQ2hCLGlCQUFpQjtLQUNqQixxQkFBcUI7S0FDckIsZUFBZTtLQUNmLGlCQUFpQjtLQUNqQixrQkFBa0I7S0FDbEIsbUJBQW1CO0lBQ3JCO0dBQ0Y7R0FHQSxJQUFJLElBQUksWUFBWSxlQUFlO0lBQ2pDLE1BQU0sV0FBVyxPQUFPLEtBQUs7SUFDN0IsTUFBTSxhQUFhLElBQUksaUJBQWlCO0lBQ3hDLE1BQU0sZ0JBQ0osYUFBYSxLQUFBLElBQ1QsT0FBTyxRQUFRLElBQ2Y7SUFFTixNQUFNLE9BQVEsTUFBTSxRQUFRLFFBQVEsTUFBTSxJQUFJO0tBQzVDO0tBQ0E7S0FDQTtLQUNBO0tBQ0E7SUFDRixDQUFDO0lBRUQsSUFBSSxDQUFDLEtBQUssVUFBVSxPQUFPLEVBQUUsU0FBUyxLQUFLO0lBRTNDLE1BQU0sZUFBZSxFQUFFLEdBQUksS0FBSyxnQkFBZ0IsQ0FBQyxFQUFHO0lBQ3BELE1BQU0sUUFBUSxFQUFFLEdBQUksS0FBSyxvQkFBb0IsQ0FBQyxFQUFHO0lBQ2pELE1BQU0sY0FBYyxFQUFFLEdBQUksS0FBSyxlQUFlLENBQUMsRUFBRztJQUNsRCxNQUFNLGVBQWUsS0FBSyxhQUFhLEtBQUssWUFBWSxJQUFJLEtBQUssWUFBWTtJQUc3RSxJQUFJLGlCQUFpQjtJQUNyQixJQUFJLGFBQWEsS0FBQSxHQUNmLElBQUk7S0FDRixNQUFNLE1BQU0sTUFBTSxRQUFRLEtBQUssSUFBSSxRQUFRO0tBQzNDLGlCQUFpQixRQUFRLEdBQUc7SUFDOUIsUUFBUTtLQUNOLGlCQUFpQjtJQUNuQjtJQUdGLElBQUksVUFBVTtJQUNkLElBQUk7SUFDSixJQUFJO0lBQ0osSUFBSTtLQUNGLE1BQU0sV0FBVyxNQUFNLFFBQVEsS0FBSyxNQUFNLENBQUMsQ0FBQztLQUM1QyxhQUFhLElBQUksSUFBSSxTQUFTLEtBQUssTUFBTSxPQUFPLEVBQUUsRUFBRSxDQUFDLENBQUM7S0FFdEQsY0FBYyxtQkFBbUIsVUFEVCxLQUFLLG1CQUFtQixDQUFDLENBQ1M7SUFDNUQsUUFBUSxDQUFDO0lBRVQsSUFBSSxDQUFDLGdCQUVDO1NBQUEsZUFDUztVQUFBLGNBQ1QsY0FDQSxhQUNBLE9BQ0EsZUFDQSxLQUNBLFlBQ0EsY0FDQSxXQUVFLEdBQUksVUFBVTtLQUFBO0lBQUEsT0FJcEIsS0FBSyxNQUFNLENBQUMsS0FBSyxVQUFVLE9BQU8sUUFBUSxZQUFZLEdBQ3BELElBQ0UsUUFBUSxpQkFDUCxNQUFNLFVBQVUsS0FBQSxLQUFhLE9BQU8sTUFBTSxLQUFLLE1BQU0sZUFFdEQsTUFBTSxnQkFBZ0I7SUFNNUIsS0FBSyxNQUFNLENBQUMsUUFBUSxTQUFTLE9BQU8sUUFBUSxXQUFXLEdBQ3JELElBQUksQ0FBQywwQkFBMEIsY0FBYyxRQUFRLEtBQUssWUFBWSxXQUFXLEdBQUc7S0FDbEYsbUJBQ0UsYUFDQSxPQUNBLFFBQ0EsS0FDQSxLQUFLLGVBQ0wsWUFDRjtLQUNBLFVBQVU7SUFDWjtJQUdGLElBQUksU0FDRixNQUFNLFFBQVEsUUFBUSxNQUFNLElBQUk7S0FDOUI7S0FDQSxrQkFBa0I7S0FDbEI7SUFDRixDQUFDO0lBR0gsT0FBTyxFQUFFLFNBQVMsS0FBSztHQUN6QjtHQUdBLElBQUksSUFBSSxZQUFZLGtCQUFrQjtJQUNwQyxNQUFNLE9BQU8sY0FBYyxJQUFJLFlBQVksRUFBRTtJQUM3QyxNQUFNLE9BQVEsTUFBTSxRQUFRLFFBQVEsTUFBTSxJQUFJO0tBQzVDO0tBQ0E7S0FDQTtJQUNGLENBQUM7SUFHRCxNQUFNLGdCQUFnQixpQkFBaUIsTUFEZixLQUFLLG1CQUFtQixDQUFDLENBQ1csS0FBSztJQUNqRSxNQUFNLFFBQVEsS0FBSyxvQkFBb0IsQ0FBQztJQUV4QyxNQUFNLFFBRGMsS0FBSyxlQUFlLENBQUMsRUFBQSxDQUNoQjtJQUN6QixNQUFNLGlCQUFpQixPQUFPLEtBQUssSUFBSSxHQUFHLE1BQU0sS0FBSyxTQUFTLElBQUk7SUFFbEUsT0FBTyxFQUNMLGdCQUFnQixNQUFNLGtCQUFrQixLQUFLLGVBQy9DO0dBQ0Y7R0FHQSxJQUFJLElBQUksWUFBWSxrQkFBa0I7SUFDcEMsTUFBTSxNQUFNLFFBQVEsUUFBUSxPQUFPLGlCQUFpQjtJQUNwRCxNQUFNLFFBQVEsS0FBSyxPQUFPLEVBQUUsSUFBSSxDQUFDO0lBQ2pDLE9BQU8sRUFBRSxTQUFTLEtBQUs7R0FDekI7R0FHQSxJQUFJLElBQUksWUFBWSxxQkFBcUI7SUFDdkMsSUFBSSxPQUFPLEtBQUssT0FBTyxLQUFBLEdBQ3JCLE1BQU0sUUFBUSxLQUFLLE9BQU8sT0FBTyxJQUFJLEVBQUU7SUFFekMsT0FBTyxFQUFFLFNBQVMsS0FBSztHQUN6QjtFQUNGLENBQUMsQ0FDSDtFQUdBLFFBQVEsS0FBSyxVQUFVLGFBQWEsT0FBTyxZQUFZLFFBQVE7R0FDN0QsTUFBTSxlQUFlLFdBQVcsT0FBTyxJQUFJO0dBQzNDLElBQUksQ0FBQyxjQUFjO0dBR25CLE1BQU0sVUFBVSxnQkFBZ0IsWUFBWTtHQUM1QyxJQUFJLENBQUMsU0FBUztHQUVkLFVBQVUsWUFBWTtJQUNwQixNQUFNLE9BQVEsTUFBTSxRQUFRLFFBQVEsTUFBTSxJQUFJO0tBQzVDO0tBQ0E7S0FDQTtLQUNBO0tBQ0E7S0FDQTtJQUNGLENBQUM7SUFFRCxJQUFJLENBQUMsS0FBSyxVQUFVO0lBRXBCLE1BQU0sU0FBUyxPQUFPLEtBQUs7SUFDM0IsTUFBTSxlQUFlLEVBQUUsR0FBSSxLQUFLLGdCQUFnQixDQUFDLEVBQUc7SUFDcEQsTUFBTSxXQUFXLE9BQU8sS0FBSyxZQUFZLENBQUMsQ0FBQyxNQUN4QyxNQUFNLE1BQU0sVUFBVSxhQUFhLEVBQUUsRUFBRSxVQUFVLEtBQ3BEO0lBQ0EsSUFBSSxDQUFDLFVBQVU7SUFDZixNQUFNLFFBQVEsYUFBYTtJQUMzQixJQUFJLENBQUMsT0FBTztJQUVaLE1BQU0sa0JBQWtCLEtBQUssbUJBQW1CLENBQUM7SUFJakQsSUFIa0IsaUJBQWlCLFNBQVMsZUFHeEMsTUFBYyxNQUFNLFFBQVE7S0FDOUIsTUFBTSxRQUFRLEVBQUUsR0FBSSxLQUFLLG9CQUFvQixDQUFDLEVBQUc7S0FDakQsTUFBTSxjQUFjLEVBQUUsR0FBSSxLQUFLLGVBQWUsQ0FBQyxFQUFHO0tBQ2xELE1BQU0sTUFBTSxLQUFLLElBQUk7S0FDckIsTUFBTSxlQUNKLEtBQUssYUFBYSxLQUFLLFlBQVksSUFBSSxLQUFLLFlBQVk7S0FFMUQsSUFBSTtLQUNKLElBQUk7S0FDSixJQUFJO01BQ0YsTUFBTSxXQUFXLE1BQU0sUUFBUSxLQUFLLE1BQU0sQ0FBQyxDQUFDO01BQzVDLGFBQWEsSUFBSSxJQUFJLFNBQVMsS0FBSyxNQUFNLE9BQU8sRUFBRSxFQUFFLENBQUMsQ0FBQztNQUN0RCxjQUFjLG1CQUFtQixVQUFVLGVBQWU7S0FDNUQsUUFBUSxDQUFDO0tBYVQsSUFYZ0IsY0FDZCxjQUNBLGFBQ0EsT0FDQSxVQUNBLEtBQ0EsWUFDQSxjQUNBLFdBR0UsR0FDRixNQUFNLFFBQVEsUUFBUSxNQUFNLElBQUk7TUFDOUI7TUFDQSxrQkFBa0I7TUFDbEI7S0FDRixDQUFDO0lBRUw7R0FDRixDQUFDO0VBQ0gsQ0FBQztFQUdELFFBQVEsS0FBSyxVQUFVLGFBQWEsVUFDbEMsVUFBVSxZQUFZO0dBQ3BCLE1BQU0sT0FBUSxNQUFNLFFBQVEsUUFBUSxNQUFNLElBQUk7SUFDNUM7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0dBQ0YsQ0FBQztHQUVELElBQUksQ0FBQyxLQUFLLFVBQVU7R0FFcEIsTUFBTSxTQUFTLE9BQU8sS0FBSztHQUMzQixNQUFNLGVBQWUsRUFBRSxHQUFJLEtBQUssZ0JBQWdCLENBQUMsRUFBRztHQUNwRCxNQUFNLFFBQVEsRUFBRSxHQUFJLEtBQUssb0JBQW9CLENBQUMsRUFBRztHQUNqRCxNQUFNLGNBQWMsRUFBRSxHQUFJLEtBQUssZUFBZSxDQUFDLEVBQUc7R0FDbEQsTUFBTSxNQUFNLEtBQUssSUFBSTtHQUNyQixNQUFNLGVBQWUsS0FBSyxhQUFhLEtBQUssWUFBWSxJQUFJLEtBQUssWUFBWTtHQUU3RSxJQUFJLDZCQUFhLElBQUksSUFBWTtHQUNqQyxJQUFJLDhCQUFjLElBQUksSUFBWTtHQUNsQyxJQUFJO0lBQ0YsTUFBTSxXQUFXLE1BQU0sUUFBUSxLQUFLLE1BQU0sQ0FBQyxDQUFDO0lBQzVDLGFBQWEsSUFBSSxJQUFJLFNBQVMsS0FBSyxNQUFNLE9BQU8sRUFBRSxFQUFFLENBQUMsQ0FBQztJQUV0RCxjQUFjLG1CQUFtQixVQURULEtBQUssbUJBQW1CLENBQUMsQ0FDUztHQUM1RCxRQUFRLENBQUM7R0FFVCxJQUFJLFVBQVUsY0FDWixjQUNBLGFBQ0EsT0FDQSxRQUNBLEtBQ0EsWUFDQSxjQUNBLFdBQ0Y7R0FHQSxJQUFJO0lBQ0YsS0FBSyxNQUFNLENBQUMsS0FBSyxVQUFVLE9BQU8sUUFBUSxZQUFZLEdBQUc7S0FDdkQsTUFBTSxTQUFTLE1BQU0sVUFBVSxLQUFBLElBQVksT0FBTyxNQUFNLEtBQUssSUFBSTtLQUNqRSxJQUFJLENBQUMsV0FBVyxJQUFJLE1BQU0sR0FDVDtVQUFBLGNBQ2IsY0FDQSxhQUNBLE9BQ0EsS0FDQSxLQUNBLFlBQ0EsY0FDQSxXQUVFLEdBQVEsVUFBVTtLQUFBO0lBRTFCO0lBRUEsS0FBSyxNQUFNLENBQUMsUUFBUSxTQUFTLE9BQU8sUUFBUSxXQUFXLEdBQ3JELElBQUksQ0FBQywwQkFBMEIsY0FBYyxRQUFRLEtBQUssWUFBWSxXQUFXLEdBQUc7S0FDbEYsbUJBQ0UsYUFDQSxPQUNBLFFBQ0EsS0FDQSxLQUFLLGVBQ0wsWUFDRjtLQUNBLFVBQVU7SUFDWjtHQUVKLFNBQVMsS0FBSztJQUNaLFFBQVEsS0FBSyxpQ0FBaUMsR0FBRztHQUNuRDtHQUVBLElBQUksU0FDRixNQUFNLFFBQVEsUUFBUSxNQUFNLElBQUk7SUFDOUI7SUFDQSxrQkFBa0I7SUFDbEI7R0FDRixDQUFDO0VBRUwsQ0FBQyxDQUNIO0VBSUEsUUFBUSxLQUFLLFlBQVksYUFBYSxlQUNwQyxVQUFVLFlBQVk7R0FDcEIsTUFBTSxPQUFRLE1BQU0sUUFBUSxRQUFRLE1BQU0sSUFBSSxDQUM1QyxnQkFDQSxVQUNGLENBQUM7R0FFRCxJQUFJLENBQUMsS0FBSyxVQUFVO0dBRXBCLE1BQU0sZUFBZSxFQUFFLEdBQUksS0FBSyxnQkFBZ0IsQ0FBQyxFQUFHO0dBQ3BELE1BQU0sTUFBTSxLQUFLLElBQUk7R0FDckIsSUFBSSxVQUFVO0dBQ2QsTUFBTSxrQkFBa0IsT0FBTyxXQUFXLEtBQUs7R0FFL0MsS0FBSyxNQUFNLENBQUMsS0FBSyxVQUFVLE9BQU8sUUFBUSxZQUFZLEdBRXBELElBRGtCLFFBQVEsbUJBQW1CLE1BQU0sVUFBVSxXQUFXLE9BRWxFO1FBQUEsQ0FBQyxNQUFNLFdBQVc7S0FDcEIsTUFBTSxZQUFZO0tBQ2xCLE1BQU0sZ0JBQWdCO0tBQ3RCLFVBQVU7SUFDWjtVQUNLLElBQUksTUFBTSxXQUFXO0lBQzFCLE1BQU0sWUFBWTtJQUNsQixVQUFVO0dBQ1o7R0FHRixJQUFJLFNBQ0YsTUFBTSxRQUFRLFFBQVEsTUFBTSxJQUFJLEVBQUUsYUFBYSxDQUFDO0VBRXBELENBQUMsQ0FDSDtFQUdBLFFBQVEsUUFBUSxVQUFVLGFBQWEsU0FBUyxTQUFTO0dBQ3ZELElBQUksU0FBUyxTQUFTO0dBQ3RCLE1BQU0sd0JBQXdCLFFBQVE7R0FDdEMsSUFBSSx1QkFDRixVQUFlLFlBQVk7SUFDekIsTUFBTSxPQUFRLE1BQU0sUUFBUSxRQUFRLE1BQU0sSUFBSTtLQUM1QztLQUNBO0tBQ0E7S0FDQTtLQUNBO0lBQ0YsQ0FBQztJQUVELElBQUksQ0FBQyxLQUFLLFVBQVU7SUFFcEIsTUFBTSxxQkFBK0IsTUFBTSxRQUFRLHNCQUFzQixRQUFRLElBQzVFLHNCQUFzQixXQUN2QixDQUFDO0lBRUwsTUFBTSxlQUFlLEVBQUUsR0FBSSxLQUFLLGdCQUFnQixDQUFDLEVBQUc7SUFDcEQsTUFBTSxRQUFRLEVBQUUsR0FBSSxLQUFLLG9CQUFvQixDQUFDLEVBQUc7SUFDakQsTUFBTSxjQUFjLEVBQUUsR0FBSSxLQUFLLGVBQWUsQ0FBQyxFQUFHO0lBQ2xELE1BQU0sTUFBTSxLQUFLLElBQUk7SUFDckIsTUFBTSxlQUFlLEtBQUssYUFBYSxLQUFLLFlBQVksSUFBSSxLQUFLLFlBQVk7SUFDN0UsSUFBSSxVQUFVO0lBR2QsS0FBSyxNQUFNLENBQUMsS0FBSyxVQUFVLE9BQU8sUUFBUSxZQUFZLEdBRXBELElBQUksQ0FEWSxpQkFBaUIsTUFBTSxRQUFRLGtCQUMxQyxHQUFTO0tBQ1osY0FBYyxjQUFjLGFBQWEsT0FBTyxLQUFLLEdBQUc7S0FDeEQsVUFBVTtJQUNaO0lBSUYsS0FBSyxNQUFNLENBQUMsUUFBUSxTQUFTLE9BQU8sUUFBUSxXQUFXLEdBRXJELElBQUksQ0FEWSxpQkFBaUIsUUFBUSxrQkFDcEMsR0FBUztLQUNaLG1CQUFtQixhQUFhLE9BQU8sUUFBUSxLQUFLLEtBQUssWUFBWTtLQUNyRSxVQUFVO0lBQ1o7SUFHRixJQUFJLFNBQ0YsTUFBTSxRQUFRLFFBQVEsTUFBTSxJQUFJO0tBQzlCO0tBQ0Esa0JBQWtCO0tBQ2xCO0lBQ0YsQ0FBQztHQUVMLENBQUM7RUFFTCxDQUFDO0NBQ0gsQ0FBQzs7Ozs7Ozs7Ozs7O0NDL3FDRCxJQUFJLGVBQWUsTUFBTSxhQUFhO0VBQ3JDO0dBQ0MsS0FBSyxZQUFZO0lBQ2hCO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0dBQ0Q7RUFDRDs7Ozs7OztFQU9BLFlBQVksY0FBYztHQUN6QixJQUFJLGlCQUFpQixjQUFjO0lBQ2xDLEtBQUssWUFBWTtJQUNqQixLQUFLLGtCQUFrQixDQUFDLEdBQUcsYUFBYSxTQUFTO0lBQ2pELEtBQUssZ0JBQWdCO0lBQ3JCLEtBQUssZ0JBQWdCO0dBQ3RCLE9BQU87SUFDTixNQUFNLFNBQVMsdUJBQXVCLEtBQUssWUFBWTtJQUN2RCxJQUFJLFVBQVUsTUFBTSxNQUFNLElBQUksb0JBQW9CLGNBQWMsa0JBQWtCO0lBQ2xGLE1BQU0sQ0FBQyxHQUFHLFVBQVUsVUFBVSxZQUFZO0lBQzFDLGlCQUFpQixjQUFjLFFBQVE7SUFDdkMsaUJBQWlCLGNBQWMsUUFBUTtJQUN2QyxLQUFLLGtCQUFrQixhQUFhLE1BQU0sQ0FBQyxRQUFRLE9BQU8sSUFBSSxDQUFDLFFBQVE7SUFDdkUsS0FBSyxnQkFBZ0I7SUFDckIsS0FBSyxnQkFBZ0I7R0FDdEI7RUFDRDs7RUFFQSxTQUFTLEtBQUs7R0FDYixNQUFNLElBQUksT0FBTyxRQUFRLFdBQVcsSUFBSSxJQUFJLEdBQUcsSUFBSSxlQUFlLFdBQVcsSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJO0dBQ2pHLElBQUksS0FBSyxXQUFXLE9BQU8sQ0FBQyxLQUFLLGtCQUFrQixDQUFDO0dBQ3BELE9BQU8sQ0FBQyxDQUFDLEtBQUssZ0JBQWdCLE1BQU0sYUFBYTtJQUNoRCxJQUFJLGFBQWEsUUFBUSxPQUFPLEtBQUssWUFBWSxDQUFDO0lBQ2xELElBQUksYUFBYSxTQUFTLE9BQU8sS0FBSyxhQUFhLENBQUM7SUFDcEQsSUFBSSxhQUFhLFFBQVEsT0FBTyxLQUFLLFlBQVksQ0FBQztJQUNsRCxJQUFJLGFBQWEsT0FBTyxPQUFPLEtBQUssV0FBVyxDQUFDO0lBQ2hELElBQUksYUFBYSxPQUFPLE9BQU8sS0FBSyxXQUFXLENBQUM7R0FDakQsQ0FBQztFQUNGO0VBQ0EsWUFBWSxLQUFLO0dBQ2hCLE9BQU8sSUFBSSxhQUFhLFdBQVcsS0FBSyxnQkFBZ0IsR0FBRztFQUM1RDtFQUNBLGFBQWEsS0FBSztHQUNqQixPQUFPLElBQUksYUFBYSxZQUFZLEtBQUssZ0JBQWdCLEdBQUc7RUFDN0Q7RUFDQSxnQkFBZ0IsS0FBSztHQUNwQixJQUFJLENBQUMsS0FBSyxpQkFBaUIsQ0FBQyxLQUFLLGVBQWUsT0FBTztHQUN2RCxNQUFNLHNCQUFzQixDQUFDLEtBQUssc0JBQXNCLEtBQUssYUFBYSxHQUFHLEtBQUssc0JBQXNCLEtBQUssY0FBYyxRQUFRLFNBQVMsRUFBRSxDQUFDLENBQUM7R0FDaEosTUFBTSxxQkFBcUIsS0FBSyxzQkFBc0IsS0FBSyxhQUFhO0dBQ3hFLE9BQU8sQ0FBQyxDQUFDLG9CQUFvQixNQUFNLFVBQVUsTUFBTSxLQUFLLElBQUksUUFBUSxDQUFDLEtBQUssbUJBQW1CLEtBQUssSUFBSSxRQUFRO0VBQy9HO0VBQ0Esa0JBQWtCLEtBQUs7R0FDdEIsT0FBTyxDQUFDLEtBQUssZ0JBQWdCLFNBQVMsSUFBSSxTQUFTLE1BQU0sR0FBRyxFQUFFLENBQUM7RUFDaEU7RUFDQSxZQUFZLEtBQUs7R0FDaEIsSUFBSSxDQUFDLEtBQUssZUFBZSxPQUFPO0dBQ2hDLE9BQU8sS0FBSyxzQkFBc0IsS0FBSyxhQUFhLENBQUMsQ0FBQyxLQUFLLElBQUksUUFBUTtFQUN4RTtFQUNBLFlBQVksS0FBSztHQUNoQixPQUFPLElBQUksYUFBYSxXQUFXLEtBQUssWUFBWSxHQUFHO0VBQ3hEO0VBQ0EsV0FBVyxNQUFNO0dBQ2hCLE1BQU0sTUFBTSxvRUFBb0U7RUFDakY7RUFDQSxXQUFXLE1BQU07R0FDaEIsTUFBTSxNQUFNLG9FQUFvRTtFQUNqRjtFQUNBLHNCQUFzQixTQUFTO0dBQzlCLE1BQU0sZ0JBQWdCLEtBQUssZUFBZSxPQUFPLENBQUMsQ0FBQyxRQUFRLFNBQVMsSUFBSTtHQUN4RSxPQUFPLE9BQU8sSUFBSSxjQUFjLEVBQUU7RUFDbkM7RUFDQSxlQUFlLFFBQVE7R0FDdEIsT0FBTyxPQUFPLFFBQVEsdUJBQXVCLE1BQU07RUFDcEQ7Q0FDRDtDQUNBLElBQUksc0JBQXNCLGNBQWMsTUFBTTtFQUM3QyxZQUFZLGNBQWMsUUFBUTtHQUNqQyxNQUFNLDBCQUEwQixhQUFhLEtBQUssUUFBUTtFQUMzRDtDQUNEO0NBQ0EsU0FBUyxpQkFBaUIsY0FBYyxVQUFVO0VBQ2pELElBQUksQ0FBQyxhQUFhLFVBQVUsU0FBUyxRQUFRLEtBQUssYUFBYSxLQUFLLE1BQU0sSUFBSSxvQkFBb0IsY0FBYyxHQUFHLFNBQVMseUJBQXlCLGFBQWEsVUFBVSxLQUFLLElBQUksRUFBRSxFQUFFO0NBQzFMO0NBQ0EsU0FBUyxpQkFBaUIsY0FBYyxVQUFVO0VBQ2pELElBQUksU0FBUyxTQUFTLEdBQUcsR0FBRyxNQUFNLElBQUksb0JBQW9CLGNBQWMsZ0NBQWdDO0VBQ3hHLElBQUksU0FBUyxTQUFTLEdBQUcsS0FBSyxTQUFTLFNBQVMsS0FBSyxDQUFDLFNBQVMsV0FBVyxJQUFJLEdBQUcsTUFBTSxJQUFJLG9CQUFvQixjQUFjLGtFQUFrRTtDQUNoTSJ9