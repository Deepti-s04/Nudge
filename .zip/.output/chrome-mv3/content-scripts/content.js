(function(){function e(e){return e}var t=globalThis.browser?.runtime?.id?globalThis.browser:globalThis.chrome,n=e({matches:[`<all_urls>`],runAt:`document_start`,main(){if(window.top!==window.self)return;function e(e){let t=Math.max(0,e),n=t%60,r=Math.floor(t/60)%60,i=Math.floor(t/3600);return`${String(i).padStart(2,`0`)}:${String(r).padStart(2,`0`)}:${String(n).padStart(2,`0`)}`}let n=window.location.hostname.replace(/^www\./,``),r=document.createElement(`div`),i=document.createElement(`h1`),a=document.createElement(`p`),o=document.createElement(`p`);r.appendChild(i),r.appendChild(a),r.appendChild(o),r.style.position=`fixed`,r.style.top=`0`,r.style.left=`0`,r.style.width=`100%`,r.style.height=`50px`,r.style.backgroundColor=`#be123c`,r.style.color=`white`,r.style.display=`none`,r.style.alignItems=`center`,r.style.justifyContent=`space-between`,r.style.gap=`16px`,r.style.padding=`0 24px`,r.style.boxSizing=`border-box`,r.style.zIndex=`2147483647`,r.style.fontFamily=`system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif`,i.textContent=`You've been distracted`,i.style.fontSize=`16px`,i.style.fontWeight=`600`,i.style.margin=`0`,i.style.padding=`0`,i.style.whiteSpace=`nowrap`,i.style.flex=`1`,i.style.textAlign=`left`,a.textContent=`00:00:00`,a.style.fontSize=`18px`,a.style.fontWeight=`bold`,a.style.margin=`0`,a.style.padding=`0`,a.style.textAlign=`center`,a.style.whiteSpace=`nowrap`,a.style.letterSpacing=`0.5px`,a.style.fontVariantNumeric=`tabular-nums`,a.style.minWidth=`110px`,a.style.flex=`1`,o.textContent=`(This session: 00:00:00)`,o.style.fontSize=`13px`,o.style.margin=`0`,o.style.padding=`0`,o.style.whiteSpace=`nowrap`,o.style.opacity=`0.9`,o.style.fontVariantNumeric=`tabular-nums`,o.style.minWidth=`170px`,o.style.flex=`1`,o.style.textAlign=`right`;let s=document.createElement(`div`);s.style.position=`fixed`,s.style.bottom=`20px`,s.style.right=`20px`,s.style.zIndex=`2147483647`,s.style.fontFamily=`system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif`,s.style.userSelect=`none`;let c=document.createElement(`div`);c.style.position=`absolute`,c.style.bottom=`58px`,c.style.right=`0`,c.style.width=`220px`,c.style.background=`rgba(18, 18, 24, 0.94)`,c.style.backdropFilter=`blur(20px)`,c.style.webkitBackdropFilter=`blur(20px)`,c.style.color=`white`,c.style.borderRadius=`18px`,c.style.padding=`16px`,c.style.border=`1px solid rgba(255, 255, 255, 0.12)`,c.style.boxShadow=`0 20px 40px -8px rgba(0, 0, 0, 0.7), 0 0 1px 1px rgba(255, 255, 255, 0.08)`,c.style.boxSizing=`border-box`,c.style.opacity=`0`,c.style.transform=`translateY(10px) scale(0.96)`,c.style.pointerEvents=`none`,c.style.transition=`opacity 0.22s cubic-bezier(0.16, 1, 0.3, 1), transform 0.22s cubic-bezier(0.16, 1, 0.3, 1)`;let l=document.createElement(`div`);l.style.display=`flex`,l.style.alignItems=`center`,l.style.justifyContent=`space-between`,l.style.marginBottom=`10px`;let u=document.createElement(`span`);u.textContent=`NUDGE FOCUS`,u.style.fontSize=`11px`,u.style.fontWeight=`800`,u.style.letterSpacing=`0.06em`,u.style.color=`#a1a1aa`;let d=document.createElement(`span`);d.textContent=`Idle`,d.style.fontSize=`10px`,d.style.fontWeight=`600`,d.style.padding=`2px 8px`,d.style.borderRadius=`999px`,d.style.background=`rgba(255, 255, 255, 0.08)`,d.style.color=`#a1a1aa`,d.style.border=`1px solid rgba(255, 255, 255, 0.08)`,d.style.textTransform=`capitalize`,l.appendChild(u),l.appendChild(d);let f=document.createElement(`div`);f.textContent=`SESSION TIME`,f.style.fontSize=`9px`,f.style.fontWeight=`700`,f.style.letterSpacing=`0.08em`,f.style.color=`#71717a`,f.style.marginBottom=`2px`;let p=document.createElement(`div`);p.textContent=`00:00:00`,p.style.fontSize=`24px`,p.style.fontFamily=`system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif`,p.style.fontVariantNumeric=`tabular-nums`,p.style.color=`#ffffff`,p.style.letterSpacing=`-0.02em`,p.style.marginBottom=`12px`;let m=document.createElement(`div`);m.style.height=`1px`,m.style.background=`rgba(255, 255, 255, 0.08)`,m.style.margin=`8px 0 12px 0`;let h=document.createElement(`button`);h.innerHTML=`
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="margin-right: 6px;">
        <rect x="3" y="3" width="18" height="18" rx="2"></rect>
        <path d="M7 16h2"></path>
        <path d="M11 12h2"></path>
        <path d="M15 8h2"></path>
      </svg>
      <span>View Dashboard</span>
    `,h.style.width=`100%`,h.style.padding=`9px 12px`,h.style.display=`flex`,h.style.alignItems=`center`,h.style.justifyContent=`center`,h.style.background=`linear-gradient(135deg, #4f46e5 0%, #6366f1 100%)`,h.style.color=`#ffffff`,h.style.fontSize=`12px`,h.style.fontWeight=`600`,h.style.borderRadius=`10px`,h.style.border=`none`,h.style.cursor=`pointer`,h.style.boxShadow=`0 4px 14px rgba(79, 70, 229, 0.4)`,h.style.transition=`all 0.2s cubic-bezier(0.16, 1, 0.3, 1)`,h.style.outline=`none`,h.addEventListener(`mouseenter`,()=>{h.style.transform=`translateY(-1px)`,h.style.filter=`brightness(1.1)`,h.style.boxShadow=`0 6px 20px rgba(79, 70, 229, 0.55)`}),h.addEventListener(`mouseleave`,()=>{h.style.transform=`translateY(0)`,h.style.filter=`brightness(1)`,h.style.boxShadow=`0 4px 14px rgba(79, 70, 229, 0.4)`}),h.addEventListener(`click`,async e=>{e.stopPropagation();try{await t.runtime.sendMessage({message:`open_dashboard`})}catch(e){console.error(`Could not open dashboard:`,e)}}),c.appendChild(l),c.appendChild(f),c.appendChild(p),c.appendChild(m),c.appendChild(h);let g=document.createElement(`div`);g.style.position=`relative`,g.style.width=`48px`,g.style.height=`48px`,g.style.borderRadius=`50%`,g.style.background=`linear-gradient(135deg, #18181b 0%, #09090b 100%)`,g.style.border=`1px solid rgba(255, 255, 255, 0.16)`,g.style.boxShadow=`0 6px 18px -4px rgba(0, 0, 0, 0.7)`,g.style.display=`flex`,g.style.alignItems=`center`,g.style.justifyContent=`center`,g.style.cursor=`pointer`,g.style.transition=`all 0.25s cubic-bezier(0.16, 1, 0.3, 1)`;let _=document.createElement(`span`);_.textContent=`N`,_.style.fontSize=`18px`,_.style.fontWeight=`700`,_.style.color=`#f4f4f5`;let v=document.createElement(`div`);v.style.position=`absolute`,v.style.top=`1px`,v.style.right=`1px`,v.style.width=`10px`,v.style.height=`10px`,v.style.borderRadius=`50%`,v.style.background=`#71717a`,v.style.border=`2px solid #09090b`,v.style.boxShadow=`0 0 6px rgba(0, 0, 0, 0.5)`,v.style.transition=`all 0.3s ease`,g.appendChild(_),g.appendChild(v),s.appendChild(c),s.appendChild(g);let y=!1,b=null,ee=()=>{b&&clearTimeout(b),y=!0,c.style.opacity=`1`,c.style.transform=`translateY(0) scale(1)`,c.style.pointerEvents=`auto`,g.style.transform=`scale(1.05)`,g.style.boxShadow=`0 10px 24px -4px rgba(0, 0, 0, 0.8)`},te=()=>{y=!1,c.style.opacity=`0`,c.style.transform=`translateY(10px) scale(0.96)`,c.style.pointerEvents=`none`,g.style.transform=`scale(1)`,g.style.boxShadow=`0 6px 18px -4px rgba(0, 0, 0, 0.7)`};s.addEventListener(`mouseenter`,()=>{ee()}),s.addEventListener(`mouseleave`,()=>{b=setTimeout(()=>{te()},150)}),g.addEventListener(`click`,e=>{e.stopPropagation(),y?te():ee()});let x=Date.now(),ne=(typeof performance<`u`&&typeof performance.getEntriesByType==`function`?performance.getEntriesByType(`navigation`):[])[0]?.type===`reload`,S=`nudge_tab_visit_start_${n}`,C=`nudge_tab_instance_${n}`,w=`nudge_tab_domain_span_start_${n}`,T=`nudge_tab_base_usage_${n}`,re=`nudge_tab_last_tick_${n}`,ie=`nudge_tab_id_${n}`,ae=`nudge_tab_active_ms_${n}`,E=e=>{try{e>=0?sessionStorage.setItem(ae,String(e)):sessionStorage.removeItem(ae)}catch{}},oe=()=>{try{sessionStorage.setItem(re,String(Date.now()))}catch{}},se=()=>{try{let e=sessionStorage.getItem(S);if(e){let t=parseInt(e,10);if(!isNaN(t)&&t>0)return t}}catch{}return 0},D=e=>{try{e>0?sessionStorage.setItem(S,String(e)):sessionStorage.removeItem(S)}catch{}},ce=()=>{try{let e=sessionStorage.getItem(w);if(e){let t=parseInt(e,10);if(!isNaN(t)&&t>0)return t}}catch{}return 0},O=e=>{try{e>0?sessionStorage.setItem(w,String(e)):sessionStorage.removeItem(w)}catch{}},le=()=>{try{let e=sessionStorage.getItem(T);if(e){let t=parseInt(e,10);if(!isNaN(t)&&t>=0)return t}}catch{}return 0},k=e=>{try{e>=0?sessionStorage.setItem(T,String(e)):sessionStorage.removeItem(T)}catch{}},ue=()=>`tab_`+Date.now()+`_`+Math.random().toString(36).slice(2,9),de=()=>{try{let e=sessionStorage.getItem(C);if(e)return e}catch{}return``},A=``,j=0,M=0,N=0,P=0,F=se(),fe=de(),pe=ne&&F>0;pe?(A=fe||ue(),j=F>0?F:x,M=ce(),N=le(),P=0):(A=ue(),j=x,M=0,N=0,P=0,D(j),O(0),k(0),E(0));try{sessionStorage.setItem(C,A)}catch{}let I=0,L=!1,R=!1,z=!1,me=0,B=`nudge_tab_blocked_${n}`,he=()=>{try{return sessionStorage.getItem(B)===`true`}catch{return!1}},V=e=>{try{e?sessionStorage.setItem(B,`true`):sessionStorage.removeItem(B)}catch{}},H=-1,U=-1,W=-1;function G(e,t){if(!e)return!1;let n=e.trim().toLowerCase().replace(/^www\./,``),r=t.map(e=>e.trim().toLowerCase().replace(/^https?:\/\//,``).replace(/^www\./,``).replace(/[/?#].*$/,``)).filter(Boolean);r.includes(`twitter.com`)&&!r.includes(`x.com`)&&r.push(`x.com`),r.includes(`x.com`)&&!r.includes(`twitter.com`)&&r.push(`twitter.com`);for(let e of r)if(n===e||n.endsWith(`.${e}`))return!0;return!1}function ge(e,t){if(!e)return null;let n=e.trim().toLowerCase().replace(/^www\./,``),r=t.map(e=>e.trim().toLowerCase().replace(/^https?:\/\//,``).replace(/^www\./,``).replace(/[/?#].*$/,``)).filter(Boolean);r.includes(`twitter.com`)&&!r.includes(`x.com`)&&r.push(`x.com`),r.includes(`x.com`)&&!r.includes(`twitter.com`)&&r.push(`twitter.com`);for(let e of r)if(n===e||n.endsWith(`.${e}`))return e;return null}let K=()=>{if(R)return;let e=document.body;if(!e){document.readyState===`loading`&&document.addEventListener(`DOMContentLoaded`,()=>{K()},{once:!0});return}e.contains(r)||e.appendChild(r),e.contains(s)||e.appendChild(s)},q=null,J=()=>{V(!1),q&&=(q.disconnect(),null)},Y=n=>{R=!0,L=!1,V(!0);try{window.stop()}catch{}try{document.querySelectorAll(`video, audio`).forEach(e=>{try{let t=e;t.pause(),t.muted=!0,t.removeAttribute(`src`),t.load()}catch{}})}catch{}r.style.display=`none`,s.style.display=`none`,document.title=`Blocked • Nudge Focus (${n})`;let i=`
        <div id="nudge-blocked-container" style="
          position: fixed !important;
          inset: 0 !important;
          top: 0 !important;
          left: 0 !important;
          width: 100vw !important;
          height: 100vh !important;
          background: #09090b !important;
          display: flex !important;
          align-items: center !important;
          justify-content: center !important;
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif !important;
          color: #f4f4f5 !important;
          box-sizing: border-box !important;
          padding: 24px !important;
          user-select: none !important;
          z-index: 2147483647 !important;
        ">
          <div style="
            max-width: 380px;
            width: 100%;
            text-align: center;
            box-sizing: border-box;
          ">
            <!-- Subtle status mark -->
            <div style="
              display: inline-flex;
              align-items: center;
              gap: 6px;
              font-size: 11px;
              font-weight: 600;
              letter-spacing: 0.06em;
              text-transform: uppercase;
              color: #71717a;
              margin-bottom: 20px;
            ">
              <span style="
                width: 6px;
                height: 6px;
                border-radius: 50%;
                background: #a1a1aa;
                display: inline-block;
              "></span>
              Nudge Focus
            </div>

            <!-- Clean Direct Title -->
            <h1 style="
              font-size: 22px;
              font-weight: 600;
              color: #fafafa;
              letter-spacing: -0.02em;
              margin: 0 0 8px 0;
              line-height: 1.3;
            ">${n} is blocked</h1>

            <!-- Understated Subtitle -->
            <p style="
              font-size: 13px;
              color: #71717a;
              line-height: 1.5;
              margin: 0 0 24px 0;
            ">
              This site is blocked during your active focus sprint.
            </p>

            <!-- Quiet Session Duration -->
            <div style="
              display: flex;
              align-items: center;
              justify-content: space-between;
              padding: 12px 16px;
              background: rgba(255, 255, 255, 0.03);
              border: 1px solid rgba(255, 255, 255, 0.08);
              border-radius: 12px;
              margin-bottom: 24px;
            ">
              <span style="font-size: 12px; color: #71717a;">Focus elapsed</span>
              <span id="nudge-blocked-timer" style="
                font-size: 14px;
                font-weight: 600;
                color: #e4e4e7;
                font-variant-numeric: tabular-nums;
                font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
              ">${I>0?e(Math.max(0,Math.floor((Date.now()-I)/1e3))):`00:00:00`}</span>
            </div>

            <!-- Clean Action Buttons -->
            <div style="
              display: flex;
              gap: 10px;
              justify-content: center;
            ">
              <button id="nudge-block-back-btn" style="
                flex: 1;
                background: #27272a;
                color: #f4f4f5;
                border: 1px solid rgba(255, 255, 255, 0.1);
                border-radius: 10px;
                padding: 9px 16px;
                font-size: 13px;
                font-weight: 500;
                cursor: pointer;
                transition: background 0.15s ease, border-color 0.15s ease;
                outline: none;
              ">Go back</button>

              <button id="nudge-block-dash-btn" style="
                background: transparent;
                color: #a1a1aa;
                border: 1px solid rgba(255, 255, 255, 0.08);
                border-radius: 10px;
                padding: 9px 16px;
                font-size: 13px;
                font-weight: 500;
                cursor: pointer;
                transition: background 0.15s ease, color 0.15s ease;
                outline: none;
              ">Dashboard</button>
            </div>

            <!-- Quiet Hint -->
            <div style="
              margin-top: 24px;
              font-size: 11px;
              color: #52525b;
              letter-spacing: 0.02em;
            ">Alt + ← to return</div>
          </div>
        </div>
      `;document.documentElement?document.documentElement.innerHTML=`
          <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Blocked • Nudge Focus (${n})</title>
            <style>
              html, body {
                margin: 0 !important;
                padding: 0 !important;
                background: #09090b !important;
                overflow: hidden !important;
                width: 100vw !important;
                height: 100vh !important;
              }
            </style>
          </head>
          <body>${i}</body>
        `:document.body&&(document.body.innerHTML=i,document.body.style.cssText=`margin:0!important;padding:0!important;background:#09090b!important;overflow:hidden!important;`);let a=document.getElementById(`nudge-block-back-btn`);a&&(a.onmouseenter=()=>{a.style.background=`#3f3f46`,a.style.borderColor=`rgba(255, 255, 255, 0.18)`},a.onmouseleave=()=>{a.style.background=`#27272a`,a.style.borderColor=`rgba(255, 255, 255, 0.1)`},a.onclick=async()=>{if(window.history.length>1)window.history.back();else try{await t.runtime.sendMessage({message:`close_current_tab`})}catch{window.close()}});let o=document.getElementById(`nudge-block-dash-btn`);o&&(o.onmouseenter=()=>{o.style.background=`rgba(255, 255, 255, 0.05)`,o.style.color=`#f4f4f5`},o.onmouseleave=()=>{o.style.background=`transparent`,o.style.color=`#a1a1aa`},o.onclick=async()=>{try{await t.runtime.sendMessage({message:`open_dashboard`})}catch(e){console.error(`Dashboard error:`,e)}}),!q&&document.documentElement&&(q=new MutationObserver(()=>{R&&(document.getElementById(`nudge-blocked-container`)||Y(n))}),q.observe(document.documentElement,{childList:!0,subtree:!0})),document.readyState===`loading`&&document.addEventListener(`DOMContentLoaded`,()=>{R&&!document.getElementById(`nudge-blocked-container`)&&Y(n)},{once:!0})};he()&&(R=!0,Y(n));let X=async()=>{try{let e=await t.storage.local.get([`isActive`,`mode`,`blockedSites`,`startedAt`]);if(e.isActive&&e.mode===`block`){let t=Array.isArray(e.blockedSites)?e.blockedSites:[];if(G(n,t))return typeof e.startedAt==`number`&&e.startedAt>0&&(I=e.startedAt),R=!0,L=!1,V(!0),Y(n),!0;if(R)return R=!1,J(),window.location.reload(),!1}else if(R)return R=!1,J(),window.location.reload(),!1}catch(e){console.warn(`Immediate block check:`,e)}return!1},Z=async()=>{try{let e=await t.storage.local.get([`isActive`,`mode`,`restrictedSites`,`startedAt`,`sessionSiteUsage`,`domainSpans`,`activeVisits`]);if(e.isActive&&(e.mode===`restrict`||e.mode===`block`)){let t=Array.isArray(e.restrictedSites)?e.restrictedSites:[];if(G(n,t)){let a=typeof e.startedAt==`number`&&e.startedAt>0?e.startedAt:0;I=a,L=!0;let o=ge(n,t)||n,s=e.sessionSiteUsage??{};typeof s[o]==`number`&&(N=s[o],k(N));let c=e.domainSpans?.[o];M=c?.startedAt&&(a===0||c.startedAt>=a)?c.startedAt:0,O(M);let l=Date.now(),u=M>0?M:j,d=u>0&&a>0?Math.max(u,a):u,f=M===0&&N>0?Math.max(d,x):d,p=f>0?Math.max(0,l-f):0,m=N+p;if(Math.floor(m/1e3),P=l-m%1e3,pe){let e=se();e>0&&(a===0||e>=a)&&(j=e)}else(!j||j===0)&&(j=x,D(j));e.mode===`block`?(i.textContent=`Focus Sprint Active (Block Mode)`,r.style.backgroundColor=`#e11d48`):(i.textContent=`You've been distracted`,r.style.backgroundColor=`#be123c`),K(),r.style.display=`flex`,Q()}else L=!1,r.style.display=`none`}else L=!1,r.style.display=`none`}catch(e){console.warn(`Immediate restricted check:`,e)}},Q=()=>{let t=Date.now();if(I>0){let r=Math.max(0,Math.floor((t-I)/1e3));if(r!==W&&(W=r,p.textContent=e(r),R)){let t=document.getElementById(`nudge-blocked-timer`);t?t.textContent=e(r):Y(n)}}if(L&&j>0){let n=M>0?M:j,r=I>0?Math.max(n,I):n,i=M===0&&N>0?Math.max(r,x):r,s=i>0?Math.max(0,t-i):0,c=N+s;if(I>0){let e=Math.max(0,t-I);c>e&&(c=e)}let l=Math.floor(c/1e3);U>=0&&l<U&&(l=U);let u=Math.max(0,Math.floor((t-(I>0?Math.max(j,I):j))/1e3));H>=0&&u<H&&(u=H),u!==H&&(H=u,a.textContent=e(u)),l!==U&&(U=l,o.textContent=`(This session: ${e(l)})`),oe()}},$=async()=>{if(z)return;z=!0;let e=++me;try{let a=document.visibilityState===`visible`,o=await t.runtime.sendMessage({message:`check_site`,hostname:n,tabInstanceId:A,tabVisitStartedAt:j,isVisible:a});if(!o||e!==me)return;if(!o.isActive){if(V(!1),R){R=!1,J(),window.location.reload();return}D(0),O(0),k(0),E(0),L=!1,j=0,M=0,N=0,P=0,I=0,H=-1,U=-1,W=-1,r.style.display=`none`,p.textContent=`00:00:00`,d.textContent=`Idle`,d.style.background=`rgba(255, 255, 255, 0.08)`,d.style.color=`#a1a1aa`,d.style.border=`1px solid rgba(255, 255, 255, 0.08)`,v.style.background=`#71717a`,v.style.boxShadow=`none`;return}if(I=o.sessionStartedAt??0,o.tabId!==void 0)try{let e=sessionStorage.getItem(ie);e&&e!==String(o.tabId)&&(A=ue(),sessionStorage.setItem(C,A),D(o.visitStartedAt||x)),sessionStorage.setItem(ie,String(o.tabId))}catch{}v.style.background=`#22c55e`,v.style.boxShadow=`0 0 8px #22c55e`;let c=o.mode||``;if(d.textContent=c?c.charAt(0).toUpperCase()+c.slice(1):`Active`,c===`restrict`?(d.style.background=`rgba(168, 85, 247, 0.15)`,d.style.color=`#c084fc`,d.style.border=`1px solid rgba(168, 85, 247, 0.3)`):c===`block`&&(d.style.background=`rgba(244, 63, 94, 0.15)`,d.style.color=`#fb7185`,d.style.border=`1px solid rgba(244, 63, 94, 0.3)`),o.isBlocked){R=!0,L=!1,o.sessionStartedAt&&(I=o.sessionStartedAt),r.style.display=`none`,s.style.display=`none`,Y(n);return}if(R&&(!o.isActive||o.mode!==`block`)){R=!1,J(),window.location.reload();return}if(R){Y(n);return}if(o.isRestricted){L=!0;let e=o.sessionStartedAt??I;I=e,typeof o.visitStartedAt==`number`&&o.visitStartedAt>0&&(j===0||o.visitStartedAt<=j)&&(j=o.visitStartedAt,D(j)),M=typeof o.domainSpanStartedAt==`number`&&o.domainSpanStartedAt>0?o.domainSpanStartedAt:typeof o.domainStartedAt==`number`&&o.domainStartedAt>0?o.domainStartedAt:0,O(M),N=typeof o.baseSiteUsageMs==`number`?o.baseSiteUsageMs:typeof o.baseSiteUsage==`number`?o.baseSiteUsage:0,k(N);let t=typeof o.usageSnapshotAt==`number`&&o.usageSnapshotAt>0?o.usageSnapshotAt:Date.now();if(typeof o.totalSiteUsageSec==`number`&&o.totalSiteUsageSec>=0)t>=P&&(o.totalSiteUsageSec,P=t);else{let n=M>0&&e>0?Math.max(M,e):M,r=n>0?Math.max(0,t-n):0,i=N+r;Math.floor(i/1e3),P=t-i%1e3}o.mode===`block`?(i.textContent=`Focus Sprint Active (Block Mode)`,r.style.backgroundColor=`#e11d48`):(i.textContent=`You've been distracted`,r.style.backgroundColor=`#be123c`),K(),r.style.display=`flex`,Q()}else L=!1,j=0,M=0,N=0,P=0,D(0),O(0),k(0),E(0),H=-1,U=-1,r.style.display=`none`,Q()}catch(e){console.error(`Nudge sync error:`,e)}finally{z=!1}};X(),Z(),$(),setInterval(Q,250),setInterval(()=>{$()},3e3),document.addEventListener(`visibilitychange`,()=>{$()});let _e=()=>{$()};window.addEventListener(`popstate`,_e),window.addEventListener(`pageshow`,e=>{ve=!1,e.persisted&&(X(),Z(),$())});try{let e=history.pushState;history.pushState=function(...t){let n=e.apply(this,t);return window.dispatchEvent(new Event(`nudge_location_change`)),n};let t=history.replaceState;history.replaceState=function(...e){let n=t.apply(this,e);return window.dispatchEvent(new Event(`nudge_location_change`)),n},window.addEventListener(`nudge_location_change`,_e)}catch{}let ve=!1,ye=()=>{if(L&&!ve){ve=!0;try{t.runtime.sendMessage({message:`tab_leaving`,tabInstanceId:A,hostname:n})}catch{}}};window.addEventListener(`pagehide`,ye),window.addEventListener(`beforeunload`,ye),t.storage.onChanged.addListener((e,t)=>{if(t===`local`&&(e.isActive||e.mode||e.blockedSites||e.restrictedSites||e.startedAt||e.domainSpans||e.sessionSiteUsage)){if(R&&(e.isActive?.newValue===!1||e.mode?.newValue!==`block`)){R=!1,J(),window.location.reload();return}if(e.startedAt&&typeof e.startedAt.newValue==`number`){let t=e.startedAt.newValue>0?e.startedAt.newValue:0;t!==I&&(I=t,t>0&&(N=0,k(0),E(0),j=x>=t?x:t,D(j),M=0,O(0),P=0,H=-1,U=-1,W=-1))}if(e.restrictedSites&&Array.isArray(e.restrictedSites.newValue)){let t=e.restrictedSites.newValue;G(n,t)||(L=!1,j=0,M=0,N=0,P=0,D(0),O(0),k(0),E(0),H=-1,U=-1,r.style.display=`none`)}X(),Z(),e.isActive?.newValue===!1&&(D(0),O(0),k(0),E(0),L=!1,j=0,M=0,N=0,P=0,I=0,H=-1,U=-1,W=-1,r.style.display=`none`),$()}})}}),r={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)},i=class e extends Event{static EVENT_NAME=a(`wxt:locationchange`);constructor(t,n){super(e.EVENT_NAME,{}),this.newUrl=t,this.oldUrl=n}};function a(e){return`${t?.runtime?.id}:content:${e}`}var o=typeof globalThis.navigation?.addEventListener==`function`;function s(e){let t,n=!1;return{run(){n||(n=!0,t=new URL(location.href),o?globalThis.navigation.addEventListener(`navigate`,e=>{let n=new URL(e.destination.url);n.href!==t.href&&(window.dispatchEvent(new i(n,t)),t=n)},{signal:e.signal}):e.setInterval(()=>{let e=new URL(location.href);e.href!==t.href&&(window.dispatchEvent(new i(e,t)),t=e)},1e3))}}}var c=class e{static SCRIPT_STARTED_MESSAGE_TYPE=a(`wxt:content-script-started`);id;abortController;locationWatcher=s(this);constructor(e,t){this.contentScriptName=e,this.options=t,this.id=Math.random().toString(36).slice(2),this.abortController=new AbortController,this.stopOldScripts(),this.listenForNewerScripts()}get signal(){return this.abortController.signal}abort(e){return this.abortController.abort(e)}get isInvalid(){return t.runtime?.id??this.notifyInvalidated(),this.signal.aborted}get isValid(){return!this.isInvalid}onInvalidated(e){return this.signal.addEventListener(`abort`,e),()=>this.signal.removeEventListener(`abort`,e)}block(){return new Promise(()=>{})}setInterval(e,t){let n=setInterval(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearInterval(n)),n}setTimeout(e,t){let n=setTimeout(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearTimeout(n)),n}requestAnimationFrame(e){let t=requestAnimationFrame((...t)=>{this.isValid&&e(...t)});return this.onInvalidated(()=>cancelAnimationFrame(t)),t}requestIdleCallback(e,t){let n=requestIdleCallback((...t)=>{this.signal.aborted||e(...t)},t);return this.onInvalidated(()=>cancelIdleCallback(n)),n}addEventListener(e,t,n,r){t===`wxt:locationchange`&&this.isValid&&this.locationWatcher.run(),e.addEventListener?.(t.startsWith(`wxt:`)?a(t):t,n,{...r,signal:this.signal})}notifyInvalidated(){this.abort(`Content script context invalidated`),r.debug(`Content script "${this.contentScriptName}" context invalidated`)}stopOldScripts(){document.dispatchEvent(new CustomEvent(e.SCRIPT_STARTED_MESSAGE_TYPE,{detail:{contentScriptName:this.contentScriptName,messageId:this.id}})),this.options?.noScriptStartedPostMessage||window.postMessage({type:e.SCRIPT_STARTED_MESSAGE_TYPE,contentScriptName:this.contentScriptName,messageId:this.id},`*`)}verifyScriptStartedEvent(e){let t=e.detail?.contentScriptName===this.contentScriptName,n=e.detail?.messageId===this.id;return t&&!n}listenForNewerScripts(){let t=e=>{e instanceof CustomEvent&&this.verifyScriptStartedEvent(e)&&this.notifyInvalidated()};document.addEventListener(e.SCRIPT_STARTED_MESSAGE_TYPE,t),this.onInvalidated(()=>document.removeEventListener(e.SCRIPT_STARTED_MESSAGE_TYPE,t))}},l={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)};return(async()=>{try{let{main:e,...t}=n;return await e(new c(`content`,t))}catch(e){throw l.error(`The content script "content" crashed on startup!`,e),e}})()})();