export function generateAllIcons(): void;
